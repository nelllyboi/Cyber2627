package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.partial.intake;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DigitalChannel;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Transfer;

@TeleOp(name = "IntakeBeamTest", group = "Test")
@Disabled

public class IntakeBeamTest extends LinearOpMode {

    private DigitalChannel laserInput;
    private DigitalChannel laserInput1;
    private Transfer transfer;

    private int ballDetectCounter = 0;
    private static final int BALL_DETECT_THRESHOLD = 10;

    @Override
    public void runOpMode() {

        laserInput  = hardwareMap.get(DigitalChannel.class, "laserDigitalInput");
        laserInput1 = hardwareMap.get(DigitalChannel.class, "laserDigitalInput1");
        laserInput.setMode(DigitalChannel.Mode.INPUT);
        laserInput1.setMode(DigitalChannel.Mode.INPUT);

        transfer = new Transfer(hardwareMap);

        waitForStart();

        while (opModeIsActive()) {

            boolean sensor0 = laserInput.getState();
            boolean sensor1 = laserInput1.getState();
            boolean ballDetected = sensor0 && sensor1;

            if (ballDetected) {
                ballDetectCounter++;
            } else {
                ballDetectCounter = 0;
            }

            boolean ballHeld = ballDetectCounter >= BALL_DETECT_THRESHOLD;

            if (!ballHeld) {
                transfer.intakeForward();
            } else {
                transfer.intakeOff();
            }

            telemetry.addData("Sensor 0",     sensor0);
            telemetry.addData("Sensor 1",     sensor1);
            telemetry.addData("Ball Counter", ballDetectCounter);
            telemetry.addData("Ball Held",    ballHeld);
            telemetry.update();
        }
    }
}