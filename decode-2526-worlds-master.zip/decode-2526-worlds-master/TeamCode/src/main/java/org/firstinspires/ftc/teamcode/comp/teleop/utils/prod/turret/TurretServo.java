package org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.teamcode.globals.Constants;

@Configurable
public class TurretServo {
    ServoImplEx axon_rf, axon_rr, axon_lf;
    AnalogInput axon_pos0, axon_pos1, axon_pos2;

    static double targetAngle = 0.0;
    double targetPosition;

    public TurretServo(HardwareMap hardwareMap) {
        axon_rf = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_RIGHT_FRONT);
        axon_rr = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_RIGHT_REAR);
        axon_lf = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_LEFT_FRONT);

        /*
         * There is a known issue with Axon servo's if setDirection or setPosition is called before
         * Axon is completely initialized, the servo could be hung or behave unpredictably.
         * Recommendation is to wait for 400 milli seconds
         */
        try {
            Thread.sleep(400);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        axon_rf.setDirection(Servo.Direction.FORWARD);
        axon_rr.setDirection(Servo.Direction.FORWARD);
        axon_lf.setDirection(Servo.Direction.FORWARD);

        axon_rf.setPwmRange(new PwmControl.PwmRange(500, 2500));
        axon_rr.setPwmRange(new PwmControl.PwmRange(500, 2500));
        axon_lf.setPwmRange(new PwmControl.PwmRange(500, 2500));

        axon_rf.setPosition(Constants.TURRET_INIT_POS);
        axon_rr.setPosition(Constants.TURRET_INIT_POS);
        axon_lf.setPosition(Constants.TURRET_INIT_POS);

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }

    public TurretServo(HardwareMap hardwareMap, boolean noInit) {
        axon_rf = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_RIGHT_FRONT);
        axon_rr = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_RIGHT_REAR);
        axon_lf = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_LEFT_FRONT);

        /*
         * There is a known issue with Axon servo's if setDirection or setPosition is called before
         * Axon is completely initialized, the servo could be hung or behave unpredictably.
         * Recommendation is to wait for 400 milli seconds
         */
        try {
            Thread.sleep(400);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        axon_rf.setDirection(Servo.Direction.FORWARD);
        axon_rr.setDirection(Servo.Direction.FORWARD);
        axon_lf.setDirection(Servo.Direction.FORWARD);

        axon_rf.setPwmRange(new PwmControl.PwmRange(500, 2500));
        axon_rr.setPwmRange(new PwmControl.PwmRange(500, 2500));
        axon_lf.setPwmRange(new PwmControl.PwmRange(500, 2500));

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }

    public double getVoltage0() {
        return axon_pos0.getVoltage();
    }

    public double getNormalizedVoltage0() {
        return axon_pos0.getVoltage()/axon_pos0.getMaxVoltage();
    }
    public double getNormalizedVoltage1() {
        return axon_pos1.getVoltage()/axon_pos1.getMaxVoltage();
    }
    public double getVoltage1() {
        return axon_pos1.getVoltage();
    }

    public double setTargetAngleInDegrees(double angle) {
        // Find the new angle
        targetAngle = TurretServo.wrapAngleDeg(angle);
        targetPosition = TurretServo.AngleInDegreesToPos(targetAngle);
        setPosition(targetPosition);
        return targetAngle;
    }

    public double setTargetAngleInPosition(double pos) {
        // Find the new angle
        targetAngle = TurretServo.wrapAnglePos(pos);
        targetPosition = TurretServo.AngleInDegreesToPos(targetAngle);
        setPosition(targetPosition);
        return targetPosition;
    }

    public double getServoPosition() {
        return targetPosition;
    }
    public static void setTargetAngle(double angle) {
        targetAngle = angle;
    }
    public double getTargetAngle() {
        return targetAngle;
    }
    public void setPosition(double pos) {
        axon_rf.setPosition(pos);
        axon_rr.setPosition(pos);
        axon_lf.setPosition(pos);
    }

    public static double wrapAngleDeg(double angle) {

        double sign = Math.signum(angle);
        if (Math.signum(targetAngle) != sign) {
            if (sign == -1.0) {
                angle = angle + 360.00;
            } else if (sign == 1.0) {
                angle = angle - 360.00;
            }
        }

        double deltaAngle = normalizeDegrees(angle - targetAngle);
        angle = targetAngle + deltaAngle;
        if ((angle < Constants.TURRET_MIN_ANGLE) ||
                (angle > Constants.TURRET_MAX_ANGLE)) {
            angle = normalizeDegrees(angle);
        }
        return angle;
    }

    public static double wrapAnglePos(double pos) {
        double angle = PosToAngleInDegrees(pos);

        double sign = Math.signum(angle);
        if (Math.signum(targetAngle) != sign) {
            if (sign == -1.0) {
                angle = angle + 360.00;
            } else if (sign == 1.0) {
                angle = angle - 360.00;
            }
        }

        double deltaAngle = normalizeDegrees(angle - targetAngle);
        angle = targetAngle + deltaAngle;
        if ((angle < Constants.TURRET_MIN_ANGLE) ||
                (angle > Constants.TURRET_MAX_ANGLE)) {
            angle = normalizeDegrees(angle);
        }
        return angle;
    }

    public static double AngleInDegreesToPos(double angleInDegrees) {
        return ((angleInDegrees - Constants.TURRET_MIN_ANGLE) *
                (Constants.TURRET_MAX_POS - Constants.TURRET_MIN_POS) /
                (Constants.TURRET_MAX_ANGLE - Constants.TURRET_MIN_ANGLE)) +
                Constants.TURRET_MIN_POS;
    }

    public static double PosToAngleInDegrees(double pos) {
        pos = Range.clip(pos, Constants.TURRET_MIN_POS, Constants.TURRET_MAX_POS);
        return ((pos - Constants.TURRET_MIN_POS) *
                (Constants.TURRET_MAX_ANGLE - Constants.TURRET_MIN_ANGLE) /
                (Constants.TURRET_MAX_POS - Constants.TURRET_MIN_POS)) +
                Constants.TURRET_MIN_ANGLE;
    }
    public static double normalizeDegrees(double degrees) {
        return (((degrees + 180.00) % 360.00 + 360.00) % 360.00 - 180.00);
    }

    public static double normalizeRadians(double radians) {
        return (((radians + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI);
    }

    public double calculateTurretAngle(double robot_x, double robot_y, double goal_x, double goal_y, double robot_heading) {
        double delta_x = goal_x - robot_x;
        double delta_y = goal_y - robot_y;

        double delta_field_heading = Math.toDegrees(Math.atan2(delta_y, delta_x));
        return (delta_field_heading - robot_heading);
    }

}
