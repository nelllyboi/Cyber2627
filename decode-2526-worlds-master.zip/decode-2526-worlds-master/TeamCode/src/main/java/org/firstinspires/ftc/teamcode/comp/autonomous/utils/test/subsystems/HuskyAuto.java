package org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems;

import android.util.Log;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.qualcomm.hardware.dfrobot.HuskyLens;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.internal.system.Deadline;

import java.util.concurrent.TimeUnit;

public class HuskyAuto {
    private HuskyLens huskyLens;
    private final int READ_PERIOD = 1;
    Deadline rateLimit = new Deadline(READ_PERIOD, TimeUnit.SECONDS);
    private boolean right = false;
    public HuskyAuto(HardwareMap hardwareMap) {
        huskyLens = hardwareMap.get(HuskyLens.class, "husky");
        rateLimit.expire();

        if (!huskyLens.knock()) {
            Log.v("Problem", "Husky no esta aqui!");
        } else {
            Log.v("Ok", "Husky es aqui!");
        }

        huskyLens.selectAlgorithm(HuskyLens.Algorithm.COLOR_RECOGNITION);

    }

    public boolean readHusky() {
        if (rateLimit.hasExpired()) {
            HuskyLens.Block[] blocks = huskyLens.blocks();

            int left = 0;
            int right = 0;

            for (HuskyLens.Block block : blocks) {
                if (block.y < 150) {
                    left++;
                } else if (block.y > 170) {
                    right++;
                }
            }

            if (left > right) {
                this.right = true;
            } else {
                this.right = false;
            }
        }
        return this.right;
    }
}
