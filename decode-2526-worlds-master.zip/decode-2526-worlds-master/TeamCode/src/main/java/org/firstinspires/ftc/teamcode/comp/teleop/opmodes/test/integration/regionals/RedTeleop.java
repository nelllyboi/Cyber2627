package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.regionals;

import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.regressRed;

import com.acmerobotics.roadrunner.Pose2d;
import com.bylazar.configurables.annotations.Configurable;
import com.bylazar.field.CanvasRotation;
import com.bylazar.field.FieldPresetParams;
import com.bylazar.field.PanelsField;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.RobotLog;

import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.globals.Globals;
import org.firstinspires.ftc.teamcode.development.roadrunner.PinpointLocalizer;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.prod.limelight.RedATE;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Drive;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Lift;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Shooter;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Transfer;

import java.util.concurrent.TimeUnit;

@Configurable
@Disabled
@TeleOp(name = "TeleOp: Red", group = "TeleOp")
public class RedTeleop extends LinearOpMode {

    PanelsField dashboard = PanelsField.INSTANCE;

    FieldPresetParams params = new FieldPresetParams(
            "aman",
            0,
            0,
            CanvasRotation.DEG_90,
            false,
            false,
            true
    );

    private ElapsedTime shootSequenceTimer = new ElapsedTime();

    public RedATE redATE;

    private boolean enableDrive = true;
    private boolean flywheelOn = false;
    public static double lmDegsOffset = -2;

    public static double kP = 0.09;
    public static double txOff = 69420;

    private Shooter shooter;
    private Drive drive;
    private Lift lift;
    private TurretServo turret;
    private Transfer transfer;

    Constants.ShootSequence shootSequence = Constants.ShootSequence.IDLE;

    private double turretOffset = 0;
    private double rpmOffset = 0;
    private double actual_angle = 0;
    private double startingTurret = 0;
    private ElapsedTime loopTimer = new ElapsedTime();
    PinpointLocalizer odo;

    public void runOpMode() {

        shooter = new Shooter(hardwareMap);
        turret = new TurretServo(hardwareMap, true);
        drive = new Drive(hardwareMap);
        lift = new Lift(hardwareMap);
        redATE = new RedATE(hardwareMap, 6942067);
        transfer = new Transfer(hardwareMap);
        odo = new PinpointLocalizer(hardwareMap, new Pose2d(Globals.START_X, Globals.START_Y, Math.toRadians(Globals.START_THETA)));

        lift.disengageLift();
        transfer.blockOut();

        waitForStart();

        dashboard.getField().setOffsets(params);

        boolean regressionActive = true;

        while (opModeIsActive()) {
            loopTimer.reset();

            odo.update();
            Pose2d retPose = odo.getPose();
            double[] rets = new double[] {retPose.position.x, retPose.position.y, retPose.heading.toDouble()};

            double x = rets[0];
            double y = rets[1];
            double theta = rets[2];

            if (x >= 16 && shootSequence != Constants.ShootSequence.IDLE) {
                transfer.intakeLoop(true);
            } else {
                transfer.intakeLoop(false);
            }

            telemetry.addData("x", x);
            telemetry.addData("y", y);
            telemetry.addData("t", theta);

            Globals.START_X = x;
            Globals.START_Y = y;
            Globals.START_THETA = Math.toDegrees(theta);

            // Turret angle from odometry
            double odo_turret_angle =
                    turret.calculateTurretAngle(
                            -x,
                            y,
                            72,
                            72,
                            Math.toDegrees(-theta)
                    );

            double normalized_odo_turret_angle =
                    TurretServo.normalizeDegrees(odo_turret_angle + turretOffset);
            // Regression-based RPM targeting (NO hood, NO projectile physics)

            double targetRPM = regressRed(x, y);

            if (targetRPM > 3600) {
                targetRPM = 3600;
            }

            if (gamepad1.psWasPressed()) {
                odo.setPose(new Pose2d(63, -64, Math.toRadians(180)));
            }

            // Drive control
            if (shootSequence == Constants.ShootSequence.IDLE && enableDrive) {
                drive.driveLoop(
                        gamepad1.right_stick_y,
                        0.8 * gamepad1.left_stick_x
                );
            } else {
                drive.driveLoop(
                        gamepad1.right_stick_y,
                        0
                );
            }

            // Intake controls
            if (gamepad1.squareWasPressed()) {
                transfer.intakeForward();
            }
            else if (gamepad1.circleWasPressed()) {
                transfer.intakeBackward();
            }

            // Turret offset tuning
            if (gamepad1.dpadLeftWasPressed()) {
                turretOffset -= 2;
                gamepad1.rumble(300);
            }
            else if (gamepad1.dpadRightWasPressed()) {
                turretOffset += 2;
                gamepad1.rumble(300);
            }

            // RPM offset tuning
            if (gamepad1.dpadUpWasPressed()) {
                rpmOffset += 50;
                gamepad1.rumble(300);
            }
            else if (gamepad1.dpadDownWasPressed()) {
                rpmOffset -= 50;
                gamepad1.rumble(300);
            }

            // Flywheel control (REGRESSION MODEL)
            if (flywheelOn) {
                shooter.setRPM(targetRPM + rpmOffset);
            }
            else {
                shooter.setRPM(targetRPM + rpmOffset);
            }

            if (gamepad1.crossWasPressed()) {
                regressionActive = !regressionActive;
            }

            // Shoot sequence start
            if (gamepad1.rightBumperWasPressed()
                    && shootSequence == Constants.ShootSequence.IDLE) {

                telemetry.addLine("RB Pressed!!!");
                flywheelOn = true;

                transfer.blockOut();
                transfer.intakeForward();
                transfer.transferForward();

                shootSequence = Constants.ShootSequence.SPIN_UP;
                shootSequenceTimer.reset();

                Object[] ll_rets = redATE.retLoopMT1();

                double errorInDegs = 0;

                if ((boolean) ll_rets[0]) {
                    errorInDegs = (double) ll_rets[1];
                    errorInDegs -= turretOffset;
                    Pose2d poseUnmodded = (Pose2d) ll_rets[2];

                    if (x < 16) {
                        odo.setPose(new Pose2d(poseUnmodded.position.x * 39.37, poseUnmodded.position.y * 39.37, theta));
                    }
                }

                startingTurret =
                        turret.getTargetAngle()
                                + errorInDegs * kP;
            }

            // Spin-up complete → shoot
            if (shootSequence == Constants.ShootSequence.SPIN_UP && (shootSequenceTimer.milliseconds() > 500 || (shooter.isAtSpeed(targetRPM + rpmOffset) && Math.abs(txOff + turretOffset) < 1))) {

                transfer.blockIn();

                shootSequence = Constants.ShootSequence.SHOOTING;

                RobotLog.vv(
                        "Bot",
                        "Shootsequence set to %s, Timer %.3f",
                        shootSequence,
                        shootSequenceTimer.milliseconds()
                );

                shootSequenceTimer.reset();
            }

            // Shooting finished
            else if (shootSequence == Constants.ShootSequence.SHOOTING
                    && shootSequenceTimer.milliseconds() > 500) {

                transfer.intakeForward();
                transfer.blockOut();
                transfer.transferOff();

                shootSequence = Constants.ShootSequence.IDLE;

                flywheelOn = false;
                RobotLog.vv(
                        "Bot",
                        "Shootsequence set to %s, Timer %.3f",
                        shootSequence,
                        shootSequenceTimer.milliseconds()
                );
            }

            // Turret control
            if (shootSequence == Constants.ShootSequence.IDLE) {
                turret.setTargetAngleInDegrees(
                        normalized_odo_turret_angle
                );
            } else {
                Object[] ll_rets = redATE.retLoopMT1();

                double errorInDegs = 0;

                if ((boolean) ll_rets[0]) {
                    errorInDegs = (double) ll_rets[1] - lmDegsOffset;
                    txOff = errorInDegs;

                }

                double angle =
                        turret.getTargetAngle()
                                + errorInDegs * kP;

                angle =
                        TurretServo.normalizeDegrees(angle);

                actual_angle = angle;

                turret.setTargetAngleInDegrees(angle);
            }

            // Lift engage
            if (shootSequence == Constants.ShootSequence.IDLE
                    && gamepad1.triangleWasPressed()) {

                enableDrive = false;
                lift.engageLift();
            }

            if (gamepad1.leftBumperWasPressed()) {
                shootSequence = Constants.ShootSequence.IDLE;
            }

            // Dashboard field visualization
            dashboard.getField().moveCursor(x, y);
            dashboard.getField().circle(3.0);
            dashboard.getField().update();

            telemetry.addData("Current RPM", shooter.getRPM());
            telemetry.addData("Shoot time", shootSequenceTimer.time(TimeUnit.SECONDS));
            telemetry.addData("Loop Time (Hz)", 1.0 / loopTimer.seconds() );
            if (shootSequence.equals(Constants.ShootSequence.IDLE)) {
                telemetry.addLine("IDLE!!!");
            }
            telemetry.update();

        }
    }
}