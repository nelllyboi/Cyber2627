
// IntelliJ API Decompiler stub source generated from a class file
// Implementation of methods is not available

package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.partial.turret;


import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
@Disabled
@com.bylazar.configurables.annotations.Configurable
public class TurretLocalizationTest {

    public GoBildaPinpointDriver pinpoint;
    private Limelight3A limelight;

    public double x = 0;
    public double y = 0;
    public double heading = 0;


    public boolean localized = false;
    private double count = 0;
    public static double CAMERA_ROLL_DEG = 90.0; // try -90 if flipped
    public static double X_FLIP = 1.0;
    public static double Y_FLIP = 1.0;

    public TurretLocalizationTest(HardwareMap hardwareMap) {
        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "odo");
        pinpoint.resetPosAndIMU();
        pinpoint.setEncoderDirections(
                GoBildaPinpointDriver.EncoderDirection.REVERSED,
                GoBildaPinpointDriver.EncoderDirection.FORWARD
        );
        pinpoint.setOffsets(2.75, 3.75, DistanceUnit.INCH);

        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.pipelineSwitch(0);
        limelight.setPollRateHz(100);
        limelight.start();
    }

    public void setPosition(double s_x, double s_y, double s_t) {
        Pose2D start_pos = new Pose2D(DistanceUnit.INCH, s_x, s_y, AngleUnit.DEGREES, s_t);
        pinpoint.setPosition(start_pos);
    }

    public boolean still() {
        return pinpoint.getVelX(DistanceUnit.INCH) < 2
                && pinpoint.getVelY(DistanceUnit.INCH) < 2
                && pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES) < 5;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getTheta() {
        return heading;
    }

    public void update(Telemetry telemetry, int targetID, boolean localizing, double turretAngleDeg) {

        LLResult result = limelight.getLatestResult();

        if (result.isValid() && localizing) {

            for (LLResultTypes.FiducialResult fiducial : result.getFiducialResults()) {

                if (fiducial.getFiducialId() != targetID) continue;

                double camX = fiducial.getCameraPoseTargetSpace().getPosition().y; // right
                double camY = fiducial.getCameraPoseTargetSpace().getPosition().x; // up
                double camZ = fiducial.getCameraPoseTargetSpace().getPosition().z; // forward

                double rollRad = Math.toRadians(CAMERA_ROLL_DEG);

                double correctedRight =
                        camX * Math.cos(rollRad) - camY * Math.sin(rollRad);

                double correctedUp =
                        camX * Math.sin(rollRad) + camY * Math.cos(rollRad);

                double forward = camZ * X_FLIP;
                double side = correctedRight * Y_FLIP;
                double t = Math.toRadians(turretAngleDeg);

//                double robotX = forward * Math.cos(t) - side * Math.sin(t);
//
//                double robotY = forward * Math.sin(t) + side * Math.cos(t);
                double robotX = forward;

                double robotY = side;
                telemetry.addData("roll", fiducial.getCameraPoseTargetSpace().getOrientation().getRoll());
                double robotHeading = (fiducial.getCameraPoseTargetSpace().getOrientation().getRoll()+turretAngleDeg);
                if (robotHeading>180){robotHeading-=360;}

                if (!localized && still() && count < 1) {

                    pinpoint.setPosition(new Pose2D(
                            DistanceUnit.METER,
                            -robotX,
                            -robotY,
                            AngleUnit.DEGREES,
                            robotHeading
                    ));
                    count++;

                    localized = true;

                } else if (still()) {
                    count++;
                    double alpha = 0.05/Math.max(result.getStaleness(),1);
                    double pinpointHeading = pinpoint.getHeading(UnnormalizedAngleUnit.DEGREES);

                    telemetry.addData("pp heading", pinpointHeading);

                    double updatedRobotHeading = (robotHeading * alpha + pinpointHeading) / (1 + alpha);
                    if (updatedRobotHeading>180){updatedRobotHeading-=360;}
                    telemetry.addData("please yahu", updatedRobotHeading);


//                    pinpoint.setPosition(new Pose2D(
//                            DistanceUnit.METER,
//                            (-robotX * alpha + pinpoint.getPosX(DistanceUnit.METER)) / (1 + alpha),
//                            (-robotY * alpha + pinpoint.getPosY(DistanceUnit.METER)) / (1 + alpha),
//                            AngleUnit.DEGREES,
//                            pinpoint.getHeading(UnnormalizedAngleUnit.DEGREES)
//                    ));
                    pinpoint.setPosition(new Pose2D(
                            DistanceUnit.METER,
                            pinpoint.getPosX(DistanceUnit.METER),
                            pinpoint.getPosY(DistanceUnit.METER),
                            AngleUnit.DEGREES,
                            pinpoint.getHeading(UnnormalizedAngleUnit.DEGREES)
                    ));
                }
                telemetry.addData("count", count);
//                telemetry.addData("LL forward", forward);
//                telemetry.addData("LL side", side);
                telemetry.addData("robotX", robotX*39.37);
                telemetry.addData("robotY", robotY*39.39);
                telemetry.addData("heading", robotHeading);
                telemetry.addData("pinpoint heading blah blah blah", pinpoint.getHeading(AngleUnit.DEGREES));
                telemetry.addData("turret", turretAngleDeg);
            }
        }

        pinpoint.update();

        Pose2D pose = pinpoint.getPosition();

        x = pose.getX(DistanceUnit.INCH);
        y = pose.getY(DistanceUnit.INCH);
        heading = (pose.getHeading(AngleUnit.DEGREES)+360)%360;

        telemetry.addData("turret", turretAngleDeg);

        telemetry.addData("FINAL X", x);
        telemetry.addData("FINAL Y", y);
        telemetry.addData("FINAL H", heading);
        telemetry.update();
    }

    public static double normalizeDegrees(double degrees) {
        return (((degrees + 180.0) % 360.0 + 360.0) % 360.0 - 180.0);
    }
}
