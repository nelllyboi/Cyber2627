package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.turret;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;

@Configurable
@Disabled

@TeleOp(name = "Turret Zero", group = "Test")
public class TurretZeroTest extends OpMode {

    public static double Axon1_POS = 0.0;
    public static double Axon2_POS = 0.0;

    FtcDashboard dashboard = FtcDashboard.getInstance();

    private Servo Axon1;
    private Servo Axon2;

    @Override
    public void init() {
        Axon1  = hardwareMap.get(Servo.class, "axon1");
        Axon2 = hardwareMap.get(Servo.class, "axon2");
    }

    @Override
    public void loop() {
        TelemetryPacket packet = new TelemetryPacket();

        Axon1.setPosition(0.5);
        Axon2.setPosition(0.5);
    }
}