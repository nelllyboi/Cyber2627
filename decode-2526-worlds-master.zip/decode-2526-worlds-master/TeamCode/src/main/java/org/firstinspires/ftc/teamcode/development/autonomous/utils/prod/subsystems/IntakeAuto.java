package org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class IntakeAuto {
    public DcMotorEx intake;
    public DcMotorEx transfer;
    private boolean intakeSlow;

    public IntakeAuto(HardwareMap hardwareMap) {
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
    }

    public IntakeAuto(HardwareMap hardwareMap, boolean intakeSlow) {
        this.intakeSlow = intakeSlow;
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
    }

    public class IntakeForward implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            if (!intakeSlow) {
                intake.setPower(1);
            } else {
                intake.setPower(0.8);
            }
            return false;
        }
    }

    public class IntakeOff implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            intake.setPower(0);
            return false;
        }
    }

    public class TransferForward implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            transfer.setPower(-1);
            return false;
        }
    }

    public class TransferBackward implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            transfer.setPower(-1);
            return false;
        }
    }

    public class TransferOff implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            transfer.setPower(0);
            return false;
        }
    }

    public Action intakeForward() { return new IntakeForward(); }
    public Action intakeOff() { return new IntakeOff(); }
    public Action transferForward() { return new TransferForward(); }
    public Action transferBackward() { return new TransferBackward(); }
    public Action transferOff() { return new TransferOff(); }
}
