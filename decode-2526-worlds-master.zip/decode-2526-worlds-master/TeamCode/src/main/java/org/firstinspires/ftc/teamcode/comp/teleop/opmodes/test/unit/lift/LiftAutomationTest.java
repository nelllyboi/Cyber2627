package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.lift;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.development.roadrunner.PinpointLocalizer;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Drive;

@TeleOp
@Disabled
public class LiftAutomationTest extends LinearOpMode {
    private Drive drive;
    private PinpointLocalizer odo;
    @Override
    public void runOpMode() {
        drive = new Drive(hardwareMap);
        odo = new PinpointLocalizer(hardwareMap, new Pose2d(0, 0, 0));
        waitForStart();
        telemetry.setMsTransmissionInterval(22);
        while(opModeIsActive()) {
            odo.update();
            Pose2d pos = odo.getPose();
            double x = pos.position.x;
            double y = pos.position.y;
            double theta = pos.heading.toDouble();

            telemetry.addData("X", x);
            telemetry.addData("Y", y);
            telemetry.addData("T", theta);
            telemetry.update();
        }
    }
}
