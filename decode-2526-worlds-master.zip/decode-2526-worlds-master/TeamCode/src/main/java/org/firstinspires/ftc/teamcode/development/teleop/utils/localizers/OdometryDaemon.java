package org.firstinspires.ftc.teamcode.development.teleop.utils.localizers;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.globals.Globals;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions;

public class OdometryDaemon {
    public double x = 0;
    public double y = 0;
    public double theta_lcl = 0;
    private double delta_x = 0;
    private double delta_y = 0;
    private double delta_total = 0;
    public GoBildaPinpointDriver odo;
    public double start_x;
    public double start_y;
    private double start_theta;
    public boolean reset;

    public OdometryDaemon(HardwareMap hardwareMap, double start_x_parameter, double start_y_parameter, double start_theta_parameter, boolean setPosition) {
        start_x = start_x_parameter;
        start_y = start_y_parameter;
        start_theta = start_theta_parameter;
        odo = hardwareMap.get(GoBildaPinpointDriver.class,"odo");

        odo.setOffsets(Constants.ODOMETRY_X_OFFSET, Constants.ODOMETRY_Y_OFFSET, DistanceUnit.MM);
        odo.setEncoderResolution(GoBildaPinpointDriver.GoBildaOdometryPods.goBILDA_4_BAR_POD);
        odo.setEncoderDirections(GoBildaPinpointDriver.EncoderDirection.FORWARD, GoBildaPinpointDriver.EncoderDirection.FORWARD);
        reset = setPosition;
        if (setPosition){
            start_x = Globals.START_X;
            start_y = Globals.START_Y;
            start_theta = MathFunctions.oppositeAngle(Globals.START_THETA);
        } else {
            odo.resetPosAndIMU();
        }
    }

    public double[] retPos() {
        odo.update();
        Pose2D pos = odo.getPosition();
        if (reset) {
            x = pos.getX(DistanceUnit.INCH);
            y = pos.getY(DistanceUnit.INCH);
        } else {
            x = start_x - pos.getX(DistanceUnit.INCH);
            y = start_y - pos.getY(DistanceUnit.INCH);
        }

        delta_total = Math.sqrt(Math.pow(delta_x, 2) + Math.pow(delta_y, 2));
        theta_lcl = (Math.toRadians(start_theta + pos.getHeading(AngleUnit.DEGREES)));
        return new double[]{x, y, theta_lcl};
    }

    public double[] retVel() {
        return new double[] {odo.getVelX(DistanceUnit.INCH), odo.getVelY(DistanceUnit.INCH)};
    }

    public void setPosition(Pose2D position) {
        odo.setPosition(position);
    }

    public double[] retPosTeleOp() {
        odo.update();
        Pose2D pos = odo.getPosition();
        if (reset) {
            x = -(start_x - pos.getX(DistanceUnit.INCH));
            y = -(start_y - pos.getY(DistanceUnit.INCH));
        } else {
            x = start_x - pos.getX(DistanceUnit.INCH);
            y = start_y - pos.getY(DistanceUnit.INCH);
        }

        delta_total = Math.sqrt(Math.pow(delta_x, 2) + Math.pow(delta_y, 2));
        theta_lcl = (Math.toRadians(start_theta + pos.getHeading(AngleUnit.DEGREES)));
        return new double[]{x, y, Math.toRadians(pos.getHeading(AngleUnit.DEGREES))};
    }




}
