package org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers;

import android.util.Log;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.internal.system.Deadline;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.DriveAuto;

import java.util.concurrent.TimeUnit;

public class Drive {
    private DcMotorEx left1;
    private DcMotorEx left2;
    private DcMotorEx right1;
    private DcMotorEx right2;
    double txRed = 30;
    double tyRed = 32;

    public ElapsedTime liftCorrectionTimer = new ElapsedTime();
    boolean runningDeadline = false;

    private double left1Old;
    private double left2Old;
    private double right1Old;
    private double right2Old;
    private double threshold = 0.05;
    private enum LiftState {
        IDLE,
        FIRST_TURN,
        TO_POINT,
        LAST_TURN
    }
    private LiftState liftState = LiftState.IDLE;
    private Pose2d redGoal = new Pose2d(-33, 39, 0);
    private double TURN_THRESH = Math.toRadians(5);
    private double VEL_THRESH = 0.5;

    private ElapsedTime oscTimer = new ElapsedTime();
    private boolean oscStart = false;

    public Drive(HardwareMap hardwareMap) {

        left1 = hardwareMap.get(DcMotorEx.class, "left1");
        left2 = hardwareMap.get(DcMotorEx.class, "left2");
        right1 = hardwareMap.get(DcMotorEx.class, "right1");
        right2 = hardwareMap.get(DcMotorEx.class, "right2");

        left1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        left2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        right1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        right2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        left1.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        left2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        right1.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        right2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        left1.setDirection(DcMotorSimple.Direction.REVERSE);
        left2.setDirection(DcMotorSimple.Direction.REVERSE);
        right2.setDirection(DcMotorSimple.Direction.REVERSE);
    }

    public void driveLoop(double forward, double turn) {
        double left1New = forward - turn;
        double left2New = forward - turn;
        double right1New = forward + turn;
        double right2New = forward + turn;
        if (Math.abs(left1Old - left1New) > threshold) {
            left1Old = left1New;
            left1.setPower(left1New);
        }
        if (Math.abs(left2Old - left2New) > threshold) {
            left2Old = left2New;
            left2.setPower(left2New);
        }
        if (Math.abs(right1Old - right1New) > threshold) {
            right1Old = right1New;
            right1.setPower(right1New);
        }
        if (Math.abs(right2Old - right2New) > threshold) {
            right2Old = right2New;
            right2.setPower(right2New);
        }
    }

    public boolean liftAutomationRed(Pose2D realFieldPos) {
        double x = realFieldPos.getX(DistanceUnit.INCH);
        double y = realFieldPos.getY(DistanceUnit.INCH);
        double theta = realFieldPos.getHeading(AngleUnit.RADIANS);

        Object[] rets = DriveAuto.pointPowers(txRed, tyRed, x, y, theta, 67);

        if ((boolean) rets[2]) {
            if (!runningDeadline) {
                liftCorrectionTimer.reset();
                runningDeadline = true;
            }
            left1.setPower(0);
            left2.setPower(0);
            right1.setPower(0);
            right2.setPower(0);
            if (liftCorrectionTimer.seconds() > 3 && runningDeadline) {
                runningDeadline = false;
                liftCorrectionTimer.reset();
                return false;
            }
        }

        double[] powers = DriveAuto.normalize((double) rets[0], (double) rets[1], (double) rets[3]);

        left1.setPower(powers[0]*0.7);
        left2.setPower(powers[0]*0.7);
        right1.setPower(powers[1]*0.7);
        right2.setPower(powers[1]*0.7);
        return true;
    }
}
