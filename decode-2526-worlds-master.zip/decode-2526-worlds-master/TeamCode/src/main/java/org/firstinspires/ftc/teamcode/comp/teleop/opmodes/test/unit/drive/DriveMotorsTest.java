package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.drive;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@TeleOp
@Disabled

@Configurable
public class DriveMotorsTest extends LinearOpMode {

    public DcMotorEx left1;
    public DcMotorEx left2;
    public DcMotorEx right1;
    public DcMotorEx right2;
    public static boolean enableLeft1 = true;
    public static boolean enableLeft2 = true;
    public static boolean enableRight1 = true;
    public static boolean enableRight2 = true;
    public static double speed = 1;

    @Override
    public void runOpMode() {
        
        left1 = hardwareMap.get(DcMotorEx.class, "left1");
        left2 = hardwareMap.get(DcMotorEx.class, "left2");
        right1 = hardwareMap.get(DcMotorEx.class, "right1");
        right2 = hardwareMap.get(DcMotorEx.class, "right2");

        left1.setDirection(DcMotorSimple.Direction.REVERSE);
        right2.setDirection(DcMotorSimple.Direction.REVERSE);

        waitForStart();
        while (opModeIsActive()) {
            if (enableLeft1) {left1.setPower(speed);} else {left1.setPower(0);}
            if (enableLeft2) {left2.setPower(speed);} else {left2.setPower(0);}
            if (enableRight1) {right1.setPower(speed);} else {right1.setPower(0);}
            if (enableRight2) {right2.setPower(speed);} else {right2.setPower(0);}
        }
    }
}
