package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.turret;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;

@TeleOp
@Disabled

public class TurretPositionTest extends LinearOpMode {

    private TurretServo turret;

    private double servoPos = 0;

    @Override
    public void runOpMode() {

        turret = new TurretServo(hardwareMap);

        turret.setPosition(servoPos);

        waitForStart();

        while (opModeIsActive()) {
            if (gamepad1.dpad_right) {
                servoPos += 0.002;
            }
            if (gamepad1.dpad_left) {
                servoPos -= 0.002;
            }

            servoPos += gamepad1.left_stick_x * 0.01;

            servoPos = Math.max(0.0, Math.min(1.0, servoPos));

            turret.setPosition(servoPos);

            double angle = TurretServo.PosToAngleInDegrees(servoPos);

            telemetry.addLine("=== TURTET POSITION FINDER ===");
            telemetry.addData("Servo Position", servoPos);
            telemetry.addData("Angle (deg)", angle);
            telemetry.addLine("");
            telemetry.addLine("Dpad = fine tune");
            telemetry.addLine("Left stick = coarse move");
            telemetry.addLine("Write down values at mechanical limits");
            telemetry.update();
        }
    }
}
