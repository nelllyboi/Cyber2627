package org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems;

import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.localizers.LocalizerTurret;

public class NewDriveAuto {

    public LocalizerTurret localizer;

    private double x;
    private double y;
    private double heading;

    public NewDriveAuto(HardwareMap hardwareMap) {
        localizer = new LocalizerTurret(hardwareMap);
    }

    public Pose2D updatePose(Telemetry telemetry, int targetID, boolean localizing) {

        localizer.update(telemetry, targetID, localizing);

        x = localizer.x;
        y = localizer.y;
        heading = localizer.heading;

        Pose2D pose = new Pose2D(
                DistanceUnit.INCH,
                x,
                y,
                AngleUnit.DEGREES,
                heading
        );

        telemetry.addData("==== POSE ====", "");
        telemetry.addData("x (in)", x);
        telemetry.addData("y (in)", y);
        telemetry.addData("heading (deg)", heading);

        telemetry.addData("distance from origin", localizer.distance);
        telemetry.addData("total distance traveled", localizer.totalDistance);

        telemetry.addData("localized?", localizer.localized);
        telemetry.addData("vision updating?", localizing);

        telemetry.update();

        return pose;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getHeading() { return heading; }
}