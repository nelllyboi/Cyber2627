package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.turret;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.AnalogInput;

@Configurable
@Disabled

@TeleOp(name="turret encoder test hooray!")
public class TurretEncoderTest extends LinearOpMode {
    // Hardware declaration
    private AnalogInput ma3Encoder;
    
    public static double Ratio = 2.06107;

    @Override
    public void runOpMode() {
        // Initialize hardware using the name from configuration
        ma3Encoder = hardwareMap.get(AnalogInput.class, "turretencoder");

        telemetry.addLine("Initialized. Waiting for start...");
        telemetry.update();

        waitForStart();

        while (opModeIsActive()) {
            // Get current voltage (typically 0 to 3.3V on REV Hubs)
            double currentVoltage = ma3Encoder.getVoltage();

            // Calculate degrees (0 to 360)
            double degrees = (((Ratio))*(currentVoltage / 5) * 360.0) - (180*Ratio);

            telemetry.addData("Voltage", "%.3f V", currentVoltage);
            telemetry.addData("MaxVoltage", "%.3f V", ma3Encoder.getMaxVoltage());
            telemetry.addData("Angle", "%.2f Degrees", degrees);
            telemetry.update();
        }
    }
}
