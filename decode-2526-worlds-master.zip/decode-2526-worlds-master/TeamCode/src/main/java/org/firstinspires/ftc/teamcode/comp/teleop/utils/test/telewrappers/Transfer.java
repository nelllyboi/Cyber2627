package org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers;

import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

public class Transfer {
    private DcMotorEx intake;
    private DcMotorEx transfer;
    private Servo ballBlock;
    private double intakePower;

    public Transfer(HardwareMap hardwareMap) {
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
        ballBlock = hardwareMap.get(Servo.class, "ballBlock");
    }

    public void intakeLoop(boolean low) {
        if (low) {
            intakePower = 0.8;
        } else {
            intakePower = 0.8;
        }
    }

    public void intakeForward() {
        intake.setPower(intakePower);
    }

    public void intakeBackward() {
        intake.setPower(-1);
    }

    public void intakeOff() {
        intake.setPower(0);
    }

    public void transferForward() {
        transfer.setPower(-0.62);
    }

    public void transferBackward() {
        transfer.setPower(1);
    }

    public void transferOff() {
        transfer.setPower(0);
    }

    public void blockIn() {
        ballBlock.setPosition(0.21);
    }

    public void blockOut() {
        ballBlock.setPosition(0.38);
    }
}
