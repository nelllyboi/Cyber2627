package org.firstinspires.ftc.teamcode.development.teleop.opmodes.test.unit.drive;

import com.bylazar.configurables.annotations.Configurable;
import com.bylazar.field.CanvasRotation;
import com.bylazar.field.FieldPresetParams;
import com.bylazar.field.PanelsField;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.development.teleop.utils.localizers.OdometryDaemon;

@Configurable
@Disabled

@TeleOp(name = "Test - Odometry", group = "Tests")
public class OdoTest extends LinearOpMode {

    PanelsField dashboard = PanelsField.INSTANCE;
    FieldPresetParams params = new FieldPresetParams(
            "neel",
            0,
            0,
            CanvasRotation.DEG_90,
            false,
            false,
            true
    );

    public void runOpMode() {
        OdometryDaemon odo = new OdometryDaemon(hardwareMap, 39, 33, 0, false);

        waitForStart();
        dashboard.getField().setOffsets(params);

        while (opModeIsActive()) {
            double[] rets = odo.retPos();
            double x = rets[0];
            double y = rets[1];
            double theta = rets[2];

            dashboard.getField().moveCursor(x, y);
            dashboard.getField().circle(3.0);
            dashboard.getField().update();
        }
    }
}