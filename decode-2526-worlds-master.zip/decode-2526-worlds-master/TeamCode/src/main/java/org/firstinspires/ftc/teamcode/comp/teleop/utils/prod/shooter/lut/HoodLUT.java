package org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut;
public final class HoodLUT {


    //To tune this one copy over the XS and YS values from the velo lookup table
    //it is very important that ZS is the size of XS by Ys
    //change the size, and replace the comments with the distance since thats how rows are identified
    //when tuning, make an opmode that allows you to manually set the hood angle and flywheel velo.
    // then go to each distance, and set the flywheel rpm to each one you have in YS
    //find the BEST SINGLE SHOT (not clip of 3) hood angle for spinout and other factors and put that
    //SERVO POSITION VALUE into the table(this will avoid having to do any angle conversions later on)
    //rinse and repeat, and then when the table is filled in, in your teleop code you can call this every loop
    //based on your localization and flywheel rpm it will update the hood angle position to the best measured
    //position which allows for hood comp :)

    private static final double[] XS = {
            40.0, 60.0, 80.0, 100.0, 120.0, 140.0 // can add 180, 4750
    };

    private static final double[] YS = {
            //updated 4/16
            2850.0, 3200.0, 3450.0, 3700.0, 4100.0, 4400.0
    };


    // if you are crunched for time here is a smaller ZS i would reccomend using, this is what we used up until 2 days before the scrim
    private static final double[][] ZS = {
            {0.65, 0.55, 0.45, 0.45, 0.45, 0.45}, //40
            {0.75, 0.55, 0.35, 0.3, 0.2, 0.2},//60
            {0.9, 0.65, 0.55, 0.35, 0.2, 0.2},//80
            {0.9, 0.85, 0.65, 0.45, 0.25, 0.2},//100

            //todo: 4/16
            {0.82, 0.82, 0.82, 0.6, 0.25, 0.25},//120
            {0.82, 0.82, 0.82, 0.82, 0.45, 0.25}//140
    };

    //    private static final double[][] ZS = {
//            {0.1, 0.15, 0.27, 0.28, 0.28, 0.28, 0.28, 0.28, 0.28, 0.28, 0.28, 0.28}, //30
//            {0.1, 0.2, 0.3, 0.35, 0.4, 0.5, 0.55, .55, 0.6, 0.6, .6, .6}, //40
//            {0, 0.2, 0.25, 0.34, 0.4, 0.55, 0.55, 0.62, 0.64, 0.72, 0.72, 0.72}, //50
//            {0.3, 0.3, 0.3, 0.35, 0.5, 0.59, 0.67, 0.7, 0.8, 0.85, 0.85, 0.85}, //60
//            {0.3, 0.3, 0.3, 0.45, 0.55, 0.6, 0.65, 0.7, 0.8, 0.8, 0.8, 0.8}, //70
//            {0.3, 0.3, 0.3, 0.4, 0.55, 0.56, 0.58, 0.64, 0.8, 0.8, 0.8, 0.8}, //80
//            {0.3, 0.3, 0.3, 0.3, 0.45, 0.5, 0.6, 0.63, 0.63, 0.86, 0.86, 0.86}, //90
//            {0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.35, 0.63, 0.7, 0.86, 0.86, 0.86}, //100
//            {0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.35, 0.45, 0.7, .87, 0.87}, //110
//            {0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.4, 0.55, 0.65, 0.87}, //120
//            {0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.45, 0.56, 0.87}, //130
//            {0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.5, 0.8}, //140
//    };

    // --- Bilinear interpolation lookup ---
    public static double get(double x, double y) {

        // Clamp inputs
        x = clamp(x, XS[0], XS[XS.length - 1]);
        y = clamp(y, YS[0], YS[YS.length - 1]);

        // Find x interval
        int xi = 0;
        for (int i = 0; i < XS.length - 1; i++) {
            if (x >= XS[i] && x <= XS[i + 1]) {
                xi = i;
                break;
            }
        }

        // Find y interval
        int yi = 0;
        for (int j = 0; j < YS.length - 1; j++) {
            if (y >= YS[j] && y <= YS[j + 1]) {
                yi = j;
                break;
            }
        }

        double x0 = XS[xi];
        double x1 = XS[xi + 1];
        double y0 = YS[yi];
        double y1 = YS[yi + 1];

        double tx = (x - x0) / (x1 - x0);
        double ty = (y - y0) / (y1 - y0);

        // Corner values
        double z00 = ZS[xi][yi];
        double z10 = ZS[xi + 1][yi];
        double z01 = ZS[xi][yi + 1];
        double z11 = ZS[xi + 1][yi + 1];

        // Bilinear interpolation
        double z0 = z00 + tx * (z10 - z00);
        double z1 = z01 + tx * (z11 - z01);

        return z0 + ty * (z1 - z0);
    }

    private static double clamp(double v, double min, double max) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }
}
