/* Copyright (c) 2017 FIRST. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided that
 * the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 * of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of FIRST nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
 * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.regionals;

import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.regressRed;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;

//import org.firstinspires.ftc.teamcode.development.autonomous.subsystems.ShooterAuto;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.DriveTrain;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Intake;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Lift;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Transfer;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.ShooterAuto;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Imu;
import org.firstinspires.ftc.teamcode.development.teleop.utils.localizers.OdometryDaemon;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.prod.limelight.RedATE;

import java.util.ArrayList;

@TeleOp(name="TeleOp: Red", group="TeleOp")
@Disabled
@Configurable
public class RedTeleOpArch extends LinearOpMode {


    /**
     * Teleop Timers
     */
    private ElapsedTime rightWiperTimer = new ElapsedTime();
    private boolean rightWiperOut = false;
    private ElapsedTime ballBlockTimer = new ElapsedTime();
    private ElapsedTime shootSequenceTimer = new ElapsedTime();
    public static double kP = 0.12;


    /**
     * Turret Variables
     */

    private double odo_turret_angle;
    private double normalized_odo_turret_angle;

    private double calculatedRPM;


    public static boolean startShootSequence = false;
    Constants.TransferState transferState = Constants.TransferState.STOP;


    public RedATE redATE;
    public OdometryDaemon odo;


    @Override
    public void runOpMode() {

        /**
         * Drivetrain Initializtions
         */
        DriveTrain driveTrain = new DriveTrain();
        driveTrain.init(hardwareMap);

        odo = new OdometryDaemon(hardwareMap, 67, 67, 67, true);

        redATE = new RedATE(hardwareMap, 67);

        boolean enableDrive = true;

        /**
         * Intake Initializtions
         */
        Intake intake = new Intake();
        intake.init(hardwareMap);
        Constants.intakeState = Constants.IntakeState.STOP;


        /**
         * Transfer Initializtions
         */
        Transfer transfer = new Transfer();
        transfer.init(hardwareMap);
        transferState = Constants.TransferState.STOP;


        /**
         * Shooter Initializtions
         */
        ShooterAuto shooter = new ShooterAuto(hardwareMap);
        double rpmOffset = 50;

        boolean regressionActive = true;



        /**
         * Turret Initializtions
         */
        TurretServo turret = new TurretServo(hardwareMap);

        double turretOffset = -2;


        /**
         * Limelight Initializtions are in drive init
         */

        Limelight3A limelight;

        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.setPollRateHz(100); // This sets how often we ask Limelight for data (100 times per second)
        limelight.start(); // This tells Limelight to start looking!


        ArrayList<Double> limelightOffsets = new ArrayList<Double>();

        Imu imu = new Imu();
        imu.init(hardwareMap);


        /**
         * Lift Initializations
         */
        Lift lift = new Lift();
        lift.init(hardwareMap);



        /**
         * Telemetry Initializtions
         */

        double maxLoopTime = 0;
        double loopCount = 0;
        ElapsedTime looptime = new ElapsedTime();

        ElapsedTime runtime = new ElapsedTime();
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        telemetry.addData("Status", "Initialized");
        telemetry.addData("Estimated angle", odo_turret_angle);
        telemetry.update();



        // Wait for the game to start (driver presses START)
        waitForStart();
        runtime.reset();

        // runIntake until the end of the match (driver presses STOP)
        while (opModeIsActive() && !isStopRequested()) {
            // Show the elapsed game time.
            telemetry.addData("Status", "Run Time: " + runtime);




            /**
             * Drivetrain Commands
             */

            if (Constants.shootSequence == Constants.ShootSequence.IDLE && enableDrive) {
                driveTrain.run(-gamepad1.right_stick_y, 0.7 * gamepad1.left_stick_x, telemetry);
            } else {
                driveTrain.run(0, 0, telemetry);
            }

            double[] ritz = odo.retPosTeleOp();
            double x = ritz[0];
            double y = ritz[1];
            double theta = ritz[2];


            /**
             * Odo Commands
             */
            telemetry.addData("Odometry ", "X = %.3f, Y = %.3f, Angle = %.3f",
                x, y,
                theta);

            telemetry.addData("Rev Hub IMU:", imu.currAngle());

            if (gamepad1.psWasPressed()) {
                odo.odo.resetPosAndIMU();
                odo.start_x = 63;
                odo.start_y = -64;
            }


            /**
             * Intake Commands
             */

            if (gamepad1.leftBumperWasPressed()) {
                intake.wipeRight();
                rightWiperOut = true;
                rightWiperTimer.reset();
            }

            if (rightWiperTimer.milliseconds() >= 200 && rightWiperOut) {
                intake.wipeRightreset();
                rightWiperOut = false;
            }

            if (gamepad1.squareWasPressed()) {
                Constants.intakeState = Constants.IntakeState.FORWARD;
            }

            if (gamepad1.circleWasPressed()) {
                Constants.intakeState = Constants.IntakeState.BACKWARD;
            }

            /**
             * Lift Commands
             */

            if (gamepad1.triangleWasPressed()) {
                if (lift.isEngaged()) {
                    lift.liftDisengage();
                    shooter.setIdlePower(0.6);
                    enableDrive = true;
                } else {
                    lift.liftEngage();
                    shooter.setIdlePower(0);
                    enableDrive = false;
                    Constants.intakeState = Constants.IntakeState.STOP;
                }

            }

            /**
             * Transfer Commands
             */

            //No Commands


            /**
             * Limelight Commands
             */


            LLResult limelightresults = limelight.getLatestResult();
            double tx = -100;
            if (limelightresults != null && limelightresults.isValid()) {
                Pose3D botpose = limelightresults.getBotpose();
                if (botpose != null) {
                    double mt1_x = botpose.getPosition().x;
                    double mt1_y = botpose.getPosition().y;
//                    telemetry.addData("MT1 Location", "(" + mt1_x + ", " + mt1_y + ")");
                    telemetry.addData("LL Pose", "x=%.2f y=%.2f ", mt1_x, mt1_y);
                }

                tx = limelightresults.getTx();

            }



            /**
             * Turret Commands
             */

            odo_turret_angle = 180 + turret.calculateTurretAngle(x,
                    y, 72, 72,
                    theta);

            normalized_odo_turret_angle = TurretServo.normalizeDegrees(odo_turret_angle);


            if (gamepad1.dpadLeftWasPressed()) {
                turretOffset += 2;
                gamepad1.rumble(300);
            } else if (gamepad1.dpadRightWasPressed()) {
                turretOffset -= 2;
                gamepad1.rumble(300);
            }



            /**
             * Shooter Sequence
             */

            if (gamepad1.rightBumperWasPressed() && Constants.shootSequence == Constants.ShootSequence.IDLE) {
                shootSequenceTimer.reset();
                Constants.shootSequence = Constants.ShootSequence.INITIATED;
                lift.liftSetToShoot();
                shooter.flywheelOn = true;
                intake.wipeRight();
                rightWiperOut = true;
                rightWiperTimer.reset();
            }


            if (Constants.shootSequence == Constants.ShootSequence.INITIATED) {
                Constants.intakeState = Constants.IntakeState.FORWARD;
                turret.setTargetAngleInDegrees(normalized_odo_turret_angle +  turretOffset);
                transfer.closeBallBlock();
                transferState = Constants.TransferState.FORWARD;
                Constants.shootSequence = Constants.ShootSequence.SPIN_UP;
                shootSequenceTimer.reset();
            } else if (Constants.shootSequence == Constants.ShootSequence.SPIN_UP && (shootSequenceTimer.milliseconds() > 1000 && shooter.atSpeed)) {
                intake.wipeRightreset();
                rightWiperOut = false;
                Constants.intakeState = Constants.IntakeState.FORWARD;
                transfer.openBallBlock();
                transferState = Constants.TransferState.FORWARD;
                Constants.shootSequence = Constants.ShootSequence.SHOOTING;
                shootSequenceTimer.reset();
                limelightOffsets.add(tx - turretOffset);
            } else if (Constants.shootSequence == Constants.ShootSequence.SHOOTING && shootSequenceTimer.milliseconds() > 500) {
                Constants.intakeState = Constants.IntakeState.FORWARD;
                transfer.closeBallBlock();
                transferState = Constants.TransferState.STOP;
                Constants.shootSequence = Constants.ShootSequence.IDLE;
                shootSequenceTimer.reset();
                lift.liftDisengage();
                shooter.flywheelOn = false;
            }


            transfer.runTransfer(transferState);
            intake.setIntake(Constants.intakeState);
            if (Constants.shootSequence == Constants.ShootSequence.IDLE){
                turret.setTargetAngleInDegrees(normalized_odo_turret_angle + turretOffset);
            }

            /**
             * Shooter Commands
             */

            if (Constants.shootSequence == Constants.ShootSequence.SPIN_UP) {
                Object[] rets = redATE.retLoop();
                double errorInDegs = 0;
                if ((boolean) rets[0]) {
                    errorInDegs = (double) rets[1];
                    errorInDegs -= turretOffset;
                }
                double angle = turret.getTargetAngle() - errorInDegs * kP;
                angle = TurretServo.normalizeDegrees(angle);
                turret.setTargetAngleInDegrees(angle);
            }

            if (gamepad1.dpadUpWasPressed()) {
                rpmOffset += 50;
                gamepad1.rumble(300);
            } else if (gamepad1.dpadDownWasPressed()) {
                rpmOffset -= 50;
                gamepad1.rumble(300);
            }

            if (gamepad1.crossWasPressed()) {
                regressionActive = !regressionActive;
            }

//            shooter.retLoop();

            if (regressionActive) {
                calculatedRPM = regressRed(-x, -y);
            } else {
                calculatedRPM = 2800;
            }

            shooter.setSpeedTeleop(calculatedRPM + rpmOffset);


//            if (runtime.seconds() > 150) {
//                requestOpModeStop();
//            }


            /**
             * Telemetry Commands
             */
            telemetry.addData("Shooter Stage", Constants.shootSequence);
            telemetry.addData("Regression active", regressionActive);
            telemetry.addData("Estimated angle", odo_turret_angle);
            telemetry.addData("Normalized Turret Angle", normalized_odo_turret_angle);
            telemetry.addData("Turret offset", turretOffset);
            telemetry.addData("Flyhweel at Speed", shooter.atSpeed);
            telemetry.addData("RPM offset", rpmOffset);
            telemetry.addData("Flywheel target RPM", calculatedRPM+rpmOffset);
            telemetry.addData("Curr RPM", shooter.currRPM());
            telemetry.addData("Limelight offsets", limelightOffsets);
            telemetry.update();
        }

    }
}
