package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.globals.Constants.BallblockState;

public class BallBlock {
    private Servo servo;
    private BallblockState ballblockState;

    public BallBlock() {

    }

    public void init(HardwareMap hardwareMap) {
        servo = hardwareMap.get(ServoImplEx.class, Constants.BALLBLOCK);
        close();
    }

    public BallblockState getState() {
        return ballblockState;
    }

    public void set(Constants.BallblockState state) {
        if (state == BallblockState.OPEN) {
            open();
        } else {
            close();
        }
    }

    public void toggle() {
        if (ballblockState == BallblockState.OPEN) {
            close();
        } else {
            open();
        }
    }

    public void close() {
        ballblockState = BallblockState.CLOSE;
        servo.setPosition(Constants.BALLBLOCK_CLOSE);
        return;
    }

    public void open() {
        ballblockState = BallblockState.OPEN;
        servo.setPosition(Constants.BALLBLOCK_OPEN);
        return;
    }
}
