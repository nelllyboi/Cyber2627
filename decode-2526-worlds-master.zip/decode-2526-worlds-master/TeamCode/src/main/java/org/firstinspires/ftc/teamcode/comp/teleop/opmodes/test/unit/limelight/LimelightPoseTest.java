package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.limelight;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.IMU;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

@TeleOp
@Disabled
public class LimelightPoseTest extends LinearOpMode {
    private Limelight3A limelight;
    private double x;
    private double y;
    private double theta;
    private IMU imu;

    @Override
    public void runOpMode() throws InterruptedException {
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        imu = hardwareMap.get(IMU.class, "imu");

        imu.initialize(
                new IMU.Parameters(
                        new RevHubOrientationOnRobot(
                                RevHubOrientationOnRobot.LogoFacingDirection.LEFT,
                                RevHubOrientationOnRobot.UsbFacingDirection.FORWARD
                        )
                )
        );

        telemetry.setMsTransmissionInterval(11);

        limelight.pipelineSwitch(1);
        limelight.start();

        waitForStart();

        while (opModeIsActive()) {

            double angle = imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.DEGREES);

            if (angle < 0) {
                angle = 180 + angle;
            } else {
                angle = 180 - angle;
            }
            telemetry.addData("Yaw", angle);

            LLResult result = limelight.getLatestResult();
            telemetry.addLine("goon");
            if (result != null) {
                if (result.isValid()) {
                    Pose3D botpose = result.getBotpose();
                    x = botpose.getPosition().x * 39.37;
                    y = botpose.getPosition().y * 39.37;
                }
            }

            telemetry.addData("curr x", x);
            telemetry.addData("curr y", y);
            telemetry.addData("curr t", theta);
            telemetry.update();
        }
    }
}