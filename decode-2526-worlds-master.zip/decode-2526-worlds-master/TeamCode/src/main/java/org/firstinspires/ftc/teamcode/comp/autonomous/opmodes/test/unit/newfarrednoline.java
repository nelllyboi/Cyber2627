package org.firstinspires.ftc.teamcode.comp.autonomous.opmodes.test.unit;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

import org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems.NewDriveAuto;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Shooter;

import java.util.concurrent.atomic.AtomicBoolean;
@Disabled
@Autonomous
public class newfarrednoline extends LinearOpMode {

    FtcDashboard dashboard = FtcDashboard.getInstance();

    @Override
    public void runOpMode() {

        NewDriveAuto drive = new NewDriveAuto(hardwareMap);
        TurretServo turret = new TurretServo(hardwareMap, true);
        Shooter shooter = new Shooter(hardwareMap);

        AtomicBoolean running = new AtomicBoolean(true);

        turret.setPosition(0.05);

        waitForStart();

        drive.localizer.setStartPose(10, -2, 0);

        Thread loop = new Thread(() -> {

            while (opModeIsActive() && running.get()) {

                TelemetryPacket packet = new TelemetryPacket();

                Pose2D pose = drive.updatePose(telemetry, 24, true);

                double x = pose.getX(DistanceUnit.INCH);
                double y = pose.getY(DistanceUnit.INCH);
                double theta = pose.getHeading(AngleUnit.DEGREES);

                double odo_turret_angle =
                        (theta - 180 * Math.atan2(y, x) / Math.PI) % 360;

                if (odo_turret_angle < 0) odo_turret_angle += 360;

                double turretPos = odo_turret_angle / 360.0 * 0.85 + 0.05;
                turret.setPosition(turretPos);

                double[] shot = Shooter.calculateShotVectorNoVelRed(x, y);

                double hoodAngleRad = shot[0];
                double hoodAngleDeg = Math.toDegrees(hoodAngleRad);

                double hoodPos = (hoodAngleDeg - Shooter.hood_ang_low) / (Shooter.hood_ang_high - Shooter.hood_ang_low) * (Shooter.hood_pos_high - Shooter.hood_pos_low) + Shooter.hood_pos_low;

                shooter.setHoodPos(0.2);

                packet.put("X", x);
                packet.put("Y", y);
                packet.put("Heading", theta);

                packet.put("Turret Angle", odo_turret_angle);
                packet.put("Turret Pos", turretPos);

                packet.put("Hood Angle (deg)", hoodAngleDeg);
                packet.put("Hood Pos", hoodPos);

                packet.put("Localized", drive.localizer.localized);
                packet.put("Found", drive.localizer.found);

                dashboard.sendTelemetryPacket(packet);
            }
        });

        loop.start();

        Actions.runBlocking(
                new SequentialAction(
                        new SleepAction(30)
                )
        );

        running.set(false);
    }
}