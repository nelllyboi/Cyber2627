package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.turret;


import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.to_left_of;
import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.to_right_of;

import com.acmerobotics.dashboard.config.Config;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;


@TeleOp(group = "test", name="Turret - Constant Angle Test")
@Configurable
public class TurretSetAngleTest extends LinearOpMode {
    public static double position = 90;
    TurretServo turretServo;
    @Override
    public void runOpMode() {
        turretServo = new TurretServo(hardwareMap);

        waitForStart();

        while (opModeIsActive()) {
            turretServo.setTargetAngleInDegrees(position);
            telemetry.addData("To Right Of", to_right_of(90, position));
            telemetry.addData("To Left Of", to_left_of(90, position));
            telemetry.addData("Pos", turretServo.getTargetAngle());
            telemetry.update();
        }
    }


//    public static double position = 0.5;
//    TurretServo turretServo;
//    @Override
//    public void runOpMode() {
//        turretServo = new TurretServo(hardwareMap);
//
//        waitForStart();
//
//        while (opModeIsActive()) {
//            turretServo.setPosition(position);
//            telemetry.addData("Pos", turretServo.axon1.getPosition());
//        }
//    }
}
