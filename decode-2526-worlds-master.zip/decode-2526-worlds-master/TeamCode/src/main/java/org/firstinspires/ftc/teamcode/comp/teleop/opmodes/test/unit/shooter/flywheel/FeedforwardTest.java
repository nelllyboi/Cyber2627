package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.shooter.flywheel;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.flywheel.FlywheelPIDF;

/*
kV = basically p, check if it actually reaches the target RPM
kS = the minimum voltage required to actually make the flywheel move
kA = motion profiling trapezoid --- check if it actually follows the intended trapezoid


kS first
kV second
kA last
*/

@TeleOp(name = "Feedforward Increments", group = "Tests")
@Disabled

public class FeedforwardTest extends LinearOpMode {
    public static double TARGET_X = 72; // distance to goal center
    public static double TARGET_Y = 72;
    DcMotor intake;
    DcMotor transfer;
    private boolean aPressed = false;
    private boolean intakeOn = false;
    private DcMotorEx flywheelMotor;
    private double targetRPM = 1000;
    private DcMotorEx flywheelMotor2;
    //private DcMotor transfer;
    private FlywheelPIDF flywheelPID;
    public FtcDashboard dashboard;


    private boolean flywheelOn = false;
    //private boolean transferOn = false;
    private boolean dUPressed = false;
    private boolean bPressed = false;
    private boolean xPressed = false;
    private boolean dDPressed = false;
    private ServoImplEx ball_block;


    @Override
    public void runOpMode() throws InterruptedException {
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());

        flywheelMotor = hardwareMap.get(DcMotorEx.class, "flywheel");
        flywheelMotor.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
        flywheelMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        flywheelMotor2 = hardwareMap.get(DcMotorEx.class, "flywheel2");
        flywheelMotor2.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
        flywheelMotor2.setDirection(DcMotorSimple.Direction.REVERSE);
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
        intake.setDirection(DcMotorSimple.Direction.REVERSE);

        flywheelPID = new FlywheelPIDF(hardwareMap, flywheelMotor, flywheelMotor2);
        ball_block = hardwareMap.get(ServoImplEx.class, "ballBlock");
        ball_block.setPwmRange(new PwmControl.PwmRange(500, 2500));

        waitForStart();

        while (opModeIsActive()) {
            TelemetryPacket packet = new TelemetryPacket();
            ball_block.setPosition(0.07);

            double currentRPM = flywheelPID.getRPM();
            double power = 0;

            if (intakeOn) {
                intake.setPower(-1);
                transfer.setPower(1);
            } else {
                intake.setPower(0);
                transfer.setPower(0);
            }

            if (gamepad1.a) {
                if (!aPressed) {
                    flywheelOn = !flywheelOn;
                    aPressed = true;
                }
            } else {
                aPressed = false;
            }

            if (gamepad1.b) {
                if (!bPressed) {
                    intakeOn = !intakeOn;
                    bPressed = true;
                }
            } else {
                bPressed = false;
            }

            if (gamepad1.dpad_up) {
                if (!dUPressed) {
                    targetRPM += 100;
                    dUPressed = true;
                }
            } else {
                dUPressed = false;
            }

            if (gamepad1.dpad_down) {
                if (!dDPressed) {
                    targetRPM -= 100;
                    dDPressed = true;
                }
            } else {
                dDPressed = false;
            }

            if (flywheelOn) {
                power = flywheelPID.controller(targetRPM, currentRPM);
                power = Math.max(0, Math.min(1, power));
                flywheelPID.setPower(power);
            } else {
                flywheelPID.setPower(0);
            }

            telemetry.addData("Target RPM", targetRPM);
            telemetry.addData("Current RPM", currentRPM);
            if (flywheelOn) {
                packet.put("Target RPM", targetRPM);
            } else {
                packet.put("Target RPM", 0);
            }
            packet.put("Current RPM", currentRPM);
            telemetry.addData("Motor Power", power);
            telemetry.addData("kS", 0.5);
            telemetry.addData("kA", 0);
            telemetry.addData("kV", 0);
            telemetry.addData("Flywheel Active", flywheelOn ? "Yes" : "No");
            telemetry.addLine("Controls: A=On/Off, Dpad Up/Down=Change RPM, C for Intake");
            telemetry.update();
        }

    }
}