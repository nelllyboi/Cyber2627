package org.firstinspires.ftc.teamcode.development.autonomous.opmodes.prod.far.line;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.BallBlockAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.DriveAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.IntakeAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.ShooterAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.BlueTurretAuto;
import org.firstinspires.ftc.teamcode.globals.Globals;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.function.Supplier;

@Disabled
@Autonomous(name = "Blue - Far Side LINE", group = "line", preselectTeleOp = "Blue Teleop")
public class FarBlueLine extends LinearOpMode {

    public static double start_theta = 180;
    @Override
    public void runOpMode() throws InterruptedException {

        FtcDashboard dashboard = FtcDashboard.getInstance();

        DriveAuto drive = new DriveAuto(hardwareMap, 63, -14, start_theta, false);
        IntakeAuto intake = new IntakeAuto(hardwareMap, true);
        BallBlockAuto ballBlock = new BallBlockAuto(hardwareMap);
        BlueTurretAuto turret = new BlueTurretAuto(hardwareMap, 63, -14);
        ShooterAuto shooter = new ShooterAuto(hardwareMap);

        Function<Double, Action> ramp = speed -> new ParallelAction(
                intake.intakeForward(),
                ballBlock.blockClose(),
                shooter.setSpeed(speed),
                shooter.flywheelOn(),
                shooter.waitRPM()
        );

        Supplier<Action> shoot = () -> new SequentialAction(
                turret.enableLimelight(),
                new SleepAction(0.2),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockClose(),
                        intake.transferForward()
                ),
                new SleepAction(0.05),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockOpen(),
                        intake.transferForward()
                ),
                new SleepAction(0.05),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockOpen(),
                        intake.transferForward()
                ),
                new SleepAction(0.6),
                new ParallelAction(
                        ballBlock.blockClose(),
                        intake.transferOff(),
                        turret.disableLimelight()
                )
        );

        Globals.START_X = 63;
        Globals.START_Y = -14;
        Globals.START_THETA = 180;

        turret.setYOff(-64);
        drive.setTimeoutTime(1);
        turret.setLmDegsOff(-1.75);
        waitForStart();

        AtomicBoolean running = new AtomicBoolean(true);

        Thread backgroundLoop = new Thread(() -> {
            while ((opModeIsActive() || opModeInInit()) && running.get()) {

                TelemetryPacket packet = new TelemetryPacket();
                double[] rets = drive.odo.retPos();

                packet.put("X", rets[0]);
                packet.put("Y", rets[1]);
                packet.put("T", rets[2]);

                packet.put("angle it thinks its at", turret.retLoop(rets[0], rets[1], Math.toDegrees(rets[2])));
                double dist_x = rets[0] + 72;
                double dist_y = 72 + rets[1];
                double dist = Math.hypot(dist_x, dist_y);
                packet.put("Speed", shooter.retLoop(dist));
                packet.fieldOverlay()
                        .fillRect(rets[0], rets[1], 2, 2);

                dashboard.sendTelemetryPacket(packet);
            }
        });


        backgroundLoop.start();

        Actions.runBlocking(
                new SequentialAction(
                        turret.disableLimelight(),
                        ballBlock.blockClose(),
                        new SleepAction(0.35),
                        intake.intakeForward(),
                        new ParallelAction(
                                ramp.apply(3400.0)
                        ),
                        shoot.get(),

                        drive.toPoint(40, -19, 0), // int 3 preset
                        drive.toPoint(34.5, -23.5, 0),
                        drive.toPointThird(31.5, -65.5, 0), // int 3 intake
                        new ParallelAction(
                                ramp.apply(3400.0),
                                drive.toPointBackwards(55, -20, 0)
                        ),
                        shoot.get(),

                        drive.toPoint(57, -20, 0), // forward preset
                        drive.toPointThird(58, -57, 0), // evo battle ram
                        drive.toPointBackwards(56, -42, -4), // backwards
                        drive.toPointThird(58, -57, 0), // evo battle ram

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(55, -20, 0), //back triangle
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        shoot.get(),
                        intake.intakeForward(),
                        drive.toPoint(57, -20, 0), // forward preset
                        drive.toPointThird(58, -57, 0), // evo battle ram
                        drive.toPointBackwards(56, -42, -4), // backwards
                        drive.toPointThird(58, -57, 0), // evo battle ram

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(57, -20, 0), //back triangle
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        shoot.get(),
                        intake.intakeForward(),
                        drive.toPoint(49, -20, 0), // forward preset
                        drive.toPointThird(50, -57, 0), // evo battle ram
                        drive.toPointBackwards(52, -42, -4), // backwards
                        drive.toPointThird(54, -57, 0), // evo battle ram
                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(57, -20, 0), //back triangle
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        shoot.get(),
                        intake.intakeForward(),
                        drive.toPoint(49, -20, 0), // forward preset
                        drive.toPointThird(50, -57, 0), // evo battle ram
                        drive.toPointBackwards(52, -42, -4), // backwards
                        drive.toPointThird(54, -57, 0), // evo battle ram

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(57, -20, 0), //back triangle
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        shoot.get(),
                        intake.intakeForward(),
                        drive.toPoint(55, -20, 0), // forward preset
                        drive.toPointThird(57, -57, 0), // evo battle ram
                        drive.toPointBackwards(55, -42, -4) // backwards
                )
        );
    }
}
