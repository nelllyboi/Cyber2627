package org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.localizers.Localizer;

public class DriveAuto {
    public Localizer odo;

    public static double k_theta = 7.5;
    public static double k_v = 2;

    public static double radius = 1.88976;
    public static double t_width = 15.2362;
    public static double decel_rad = 12;
    public static double scalar = 0.1;
    public static double t_scalar = 0.4;
    public static double TIMEOUT_TIME = 3;

    private double last_x;
    private double last_y;

    public DcMotor left1;
    public DcMotor left2;
    public DcMotor right1;
    public DcMotor right2;
    private boolean startedTimer = false;
    private ElapsedTime timeout = new ElapsedTime();

    private double x;
    private double y;
    private double theta_lcl;

    public DriveAuto(HardwareMap hardwareMap, double s_x, double s_y, double s_t) {
        //constructors
        odo = new Localizer(hardwareMap);

        //inits
        odo.setPosition(s_x, s_y, s_t);

        //Drive Motor inits
        left1 = hardwareMap.get(DcMotor.class, "left1");
        left2 = hardwareMap.get(DcMotor.class, "left2");
        right1 = hardwareMap.get(DcMotor.class, "right1");
        right2 = hardwareMap.get(DcMotor.class, "right2");

        right1.setDirection(DcMotorSimple.Direction.REVERSE);

        left1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        left2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        right1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        right2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        left1.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        left2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        right1.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        right2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }

    public void setTimeoutTime(double time) {
        TIMEOUT_TIME = time;
    }

    public static Object[] pointPowers(double target_x, double target_y, double current_x, double current_y, double current_theta, double goal_theta) {

        double theta_d = Math.atan2((target_y - current_y), (target_x - current_x));
        boolean closeEnough = false;

        double vel_t = k_theta * (MathFunctions.angle_wrap(current_theta-theta_d));
        if (Math.abs(current_x - target_x) < 2 && Math.abs(target_y - current_y) < 2) {
            closeEnough = true;
        }
        double distance = Math.sqrt(Math.pow(target_x-current_x, 2) + Math.pow(target_y-current_y, 2));
        double abs_distance = Math.abs(distance);

        double vel_b = k_v * distance;
        double phi_left = (t_width/(2 * radius))*(vel_t) + vel_b/radius;
        double phi_right = -(t_width/(2 * radius))*(vel_t) + vel_b/radius;

        return new Object[] {phi_right, phi_left, closeEnough, abs_distance};
    }

    public static Object[] pointPowersBackwards(double target_x, double target_y, double current_x, double current_y, double current_theta, double goal_theta) {

        double theta_d = MathFunctions.oppositeAngle(Math.atan2((target_y - current_y), (target_x - current_x)));
        boolean closeEnough = false;

        double vel_t = k_theta * MathFunctions.angle_wrap(current_theta-theta_d);
        if (Math.abs(current_x - target_x) < 2 && Math.abs(target_y - current_y) < 2) {
            closeEnough = true;
        }

        double distance = Math.sqrt(Math.pow(target_x-current_x, 2) + Math.pow(target_y-current_y, 2));
        double abs_distance = Math.abs(distance);
        double vel_b = -k_v * distance;

        double phi_left = vel_b/radius - (t_width/(2 * radius))*(vel_t);
        double phi_right = vel_b/radius + (t_width/(2 * radius))*(vel_t);

        return new Object[] {phi_right, phi_left, closeEnough, abs_distance};
    }

    public static Object[] pointTurn(double current_theta, double goal_theta) {

        boolean closeEnough = false;
        goal_theta = Math.toRadians(goal_theta);

        double vel_t = k_theta * MathFunctions.angle_wrap(current_theta-goal_theta);
        if (Math.abs(MathFunctions.angle_wrap(current_theta-goal_theta)) < Math.toRadians(10)) {
            closeEnough = true;
        }


        double phi_left = (t_width/(2 * radius))*(vel_t);
        double phi_right = (t_width/(2 * radius))*(vel_t);

        return new Object[] {phi_right, phi_left, closeEnough};
    }

    public static double[] normalize(double leftPower, double rightPower, double abs_distance) {
        double max = Math.max(Math.abs(leftPower), Math.abs(rightPower));
        double modifier = 1;
        if (abs_distance < decel_rad) {
            modifier = abs_distance * scalar;
        }

        modifier = Math.max(0.1, modifier);

        if (max > 1) {
            leftPower /= max;
            rightPower /= max;
        }

        leftPower *= modifier;
        rightPower *= modifier;
        return new double[] {leftPower, rightPower};
    }

    public static double[] normalize_turn(double leftPower, double rightPower) {
        double max = Math.max(Math.abs(leftPower), Math.abs(rightPower));

        if (max > 1) {
            leftPower /= max;
            rightPower /= max;
        }

        return new double[] {leftPower, rightPower};
    }

    public Pose2D updateOdo(Telemetry telemetry) {
        odo.update(telemetry, 24, odo.still());
        Pose2D retPose = odo.getRealFieldPose();

        return retPose;
    }

    public class ToPointBackwards implements Action {
        private double x_to;
        private double y_to;
        private double turn_to;
        public ToPointBackwards(double x_to, double y_to, double turn_to) {
            this.x_to = x_to;
            this.y_to = y_to;
            this.turn_to = turn_to;
            last_x = x;
            last_y = y;
        }

        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            Object[] rets = pointPowersBackwards(x_to, y_to, x, y, theta_lcl, 0.0);
            if ((boolean) rets[2]) {
                left1.setPower(0);
                left2.setPower(0);
                right1.setPower(0);
                right2.setPower(0);
                startedTimer = false;
                timeout.reset();
                return false;
            }
            if (Math.abs(last_x - x) < 3 && Math.abs(last_y - y) < 3) {
                if (startedTimer == false) {
                    timeout.startTime();
                    startedTimer = true;
                } else if (timeout.seconds() > TIMEOUT_TIME) {
                    left1.setPower(0);
                    left2.setPower(0);
                    right1.setPower(0);
                    right2.setPower(0);
                    timeout.reset();
                    startedTimer = false;
                    return false;
                }
            } else {
                timeout.reset();
                startedTimer = false;
                last_x = x;
                last_y = y;
            }
            double[] powers = normalize((double) rets[0], (double) rets[1], (double) rets[3]);
            packet.put("leftpwr", powers[0]);
            packet.put("rightpwr", powers[1]);
            left1.setPower(powers[0]*0.95);
            left2.setPower(powers[0]*0.95);
            right1.setPower(powers[1]*0.95);
            right2.setPower(powers[1]*0.95);
            return true;
        }

    }

    public Action toPointBackwards(double x_to, double y_to, double turn_to) { return new ToPointBackwards(
            x_to, y_to, turn_to); }

    public class ToPointBackwardsThird implements Action {
        private double x_to;
        private double y_to;
        private double turn_to;
        public ToPointBackwardsThird(double x_to, double y_to, double turn_to) {
            this.x_to = x_to;
            this.y_to = y_to;
            this.turn_to = turn_to;
            last_x = x;
            last_y = y;
        }

        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            k_theta = 7;
            Object[] rets = pointPowersBackwards(x_to, y_to, x, y, theta_lcl, 0.0);
            if ((boolean) rets[2]) {
                left1.setPower(0);
                left2.setPower(0);
                right1.setPower(0);
                right2.setPower(0);
                k_theta = 7.5;
                startedTimer = false;
                timeout.reset();
                return false;
            }
            if (Math.abs(last_x - x) < 3 && Math.abs(last_y - y) < 3) {
                if (!startedTimer) {
                    timeout.startTime();
                    startedTimer = true;
                } else if (timeout.seconds() > TIMEOUT_TIME) {
                    left1.setPower(0);
                    left2.setPower(0);
                    right1.setPower(0);
                    right2.setPower(0);
                    timeout.reset();
                    startedTimer = false;
                    return false;
                }
            } else {
                timeout.reset();
                startedTimer = false;
                last_x = x;
                last_y = y;
            }
            double[] powers = normalize((double) rets[0], (double) rets[1], (double) rets[3]);
            packet.put("leftpwr", powers[0]);
            packet.put("rightpwr", powers[1]);
            left1.setPower(powers[0]*0.8);
            left2.setPower(powers[0]*0.8);
            right1.setPower(powers[1]*0.8);
            right2.setPower(powers[1]*0.8);
            return true;
        }
    }

    public Action toPointBackwardsThird(double x_to, double y_to, double turn_to) { return new ToPointBackwardsThird(
            x_to, y_to, turn_to); }

    public class ToPoint implements Action {
        private double x_to;
        private double y_to;
        private double turn_to;
        public ToPoint(double x_to, double y_to, double turn_to) {
            this.x_to = x_to;
            this.y_to = y_to;
            this.turn_to = turn_to;
            last_x = x;
            last_y = y;
        }

        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            Object[] rets = pointPowers(x_to, y_to, x, y, theta_lcl, 0.0);
            if ((boolean) rets[2]) {
                left1.setPower(0);
                left2.setPower(0);
                right1.setPower(0);
                right2.setPower(0);
                startedTimer = false;
                timeout.reset();
                return false;
            }
            if (Math.abs(last_x - x) < 3 && Math.abs(last_y - y) < 3) {
                if (!startedTimer) {
                    timeout.startTime();
                    startedTimer = true;
                } else if (timeout.seconds() > TIMEOUT_TIME) {
                    left1.setPower(0);
                    left2.setPower(0);
                    right1.setPower(0);
                    right2.setPower(0);
                    timeout.reset();
                    startedTimer = false;
                    return false;
                }
            } else {
                timeout.reset();
                startedTimer = false;
                last_x = x;
                last_y = y;
            }
            double[] powers = normalize((double) rets[0], (double) rets[1], (double) rets[3]);
            packet.put("leftpwr", powers[0]);
            packet.put("rightpwr", powers[1]);
            left1.setPower(powers[1]*0.95);
            left2.setPower(powers[1]*0.95);
            right1.setPower(powers[0]*0.95);
            right2.setPower(powers[0]*0.95);
            return true;
        }
    }

    public Action toPoint(double x_to, double y_to, double turn_to) { return new ToPoint(
            x_to, y_to, turn_to); }

    public class ToTurn implements Action {
        private double turn_to;
        public ToTurn(double turn_to) {
            this.turn_to = turn_to;
            last_x = x;
            last_y = y;
        }

        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            Object[] rets = pointTurn(theta_lcl, turn_to);
            if ((boolean) rets[2]) {
                left1.setPower(0);
                left2.setPower(0);
                right1.setPower(0);
                right2.setPower(0);
                startedTimer = false;
                timeout.reset();
                return false;
            }
            if (Math.abs(last_x - x) < 3 && Math.abs(last_y - y) < 3) {
                if (!startedTimer) {
                    timeout.startTime();
                    startedTimer = true;
                } else if (timeout.seconds() > TIMEOUT_TIME) {
                    left1.setPower(0);
                    left2.setPower(0);
                    right1.setPower(0);
                    right2.setPower(0);
                    timeout.reset();
                    startedTimer = false;
                    return false;
                }
            } else {
                timeout.reset();
                startedTimer = false;
                last_x = x;
                last_y = y;
            }
            double[] powers = normalize_turn((double) rets[0], (double) rets[1]);
            packet.put("leftpwr", powers[0]);
            packet.put("rightpwr", powers[1]);
            left1.setPower(powers[1]*0.95);
            left2.setPower(powers[1]*0.95);
            right1.setPower(powers[0]*0.95);
            right2.setPower(powers[0]*0.95);
            return true;
        }
    }

    public Action toPointTurn(double turn_to) { return new ToTurn(
            turn_to); }

    public class ToPointHalf implements Action {
        private double x_to;
        private double y_to;
        private double turn_to;
        public ToPointHalf(double x_to, double y_to, double turn_to) {
            this.x_to = x_to;
            this.y_to = y_to;
            this.turn_to = turn_to;
            last_x = x;
            last_y = y;
        }


        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            k_theta = 14;
            Object[] rets = pointPowers(x_to, y_to, x, y, theta_lcl, 0.0);
            if ((boolean) rets[2]) {
                left1.setPower(0);
                left2.setPower(0);
                right1.setPower(0);
                right2.setPower(0);
                k_theta = 7.5;
                startedTimer = false;
                timeout.reset();
                return false;
            }
            if (Math.abs(last_x - x) < 3 && Math.abs(last_y - y) < 3) {
                if (!startedTimer) {
                    timeout.startTime();
                    startedTimer = true;
                } else if (timeout.seconds() > TIMEOUT_TIME) {
                    left1.setPower(0);
                    left2.setPower(0);
                    right1.setPower(0);
                    right2.setPower(0);
                    timeout.reset();
                    startedTimer = false;
                    return false;
                }
            } else {
                timeout.reset();
                startedTimer = false;
                last_x = x;
                last_y = y;
            }
            double[] powers = normalize((double) rets[0], (double) rets[1], (double) rets[3]);
            packet.put("leftpwr", powers[0]);
            packet.put("rightpwr", powers[1]);
            left1.setPower(powers[1]*0.8);
            left2.setPower(powers[1]*0.8);
            right1.setPower(powers[0]*0.8);
            right2.setPower(powers[0]*0.8);
            return true;
        }
    }

    public Action toPointHalf(double x_to, double y_to, double turn_to) { return new ToPointHalf(
            x_to, y_to, turn_to); }


}
