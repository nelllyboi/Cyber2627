package org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.ServoImplEx;

public class BallBlockAuto {

    public ServoImplEx ballBlock;
    public static double BLOCK_OPEN = 0.21;
    public static double BLOCK_CLOSED = 0.38;

    public BallBlockAuto(HardwareMap hardwareMap) {
        ballBlock = hardwareMap.get(ServoImplEx.class, "ballBlock");
    }

    public class BlockOpen implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            ballBlock.setPosition(BLOCK_OPEN);
            return false;
        }
    }

    public class BlockClose implements Action {

        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            ballBlock.setPosition(BLOCK_CLOSED);
            return false;
        }
    }

    public Action blockOpen() { return new BlockOpen(); }
    public Action blockClose() { return new BlockClose(); }
}
