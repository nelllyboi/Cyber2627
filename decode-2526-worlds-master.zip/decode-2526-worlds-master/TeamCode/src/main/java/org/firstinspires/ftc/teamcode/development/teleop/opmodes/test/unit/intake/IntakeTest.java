package org.firstinspires.ftc.teamcode.development.teleop.opmodes.test.unit.intake;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.RobotLog;

import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.BallBlock;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Intake;

@Configurable
@Disabled
@TeleOp
public class IntakeTest extends LinearOpMode {

    Intake intake;
    BallBlock ballBlock;

    @Override
    public void runOpMode() {

        intake = new Intake();
        intake.init(hardwareMap);

        ballBlock = new BallBlock();
        ballBlock.init(hardwareMap);

        waitForStart();

        while (opModeIsActive()) {

            if (gamepad1.xWasPressed()) {
                RobotLog.vv("AstroBot", "X-Square was pressed");
                if (intake.getState() != Constants.IntakeState.FORWARD) {
                    intake.forward();
                } else {
                    intake.stop();
                }
            }

            if (gamepad1.bWasPressed()) {
                RobotLog.vv("AstroBot", "B-Circle was pressed");
                if (intake.getState() != Constants.IntakeState.BACKWARD)
                    intake.backward();
                else
                    intake.stop();
            }

            if (gamepad1.aWasPressed()) {
                RobotLog.vv("AstroBot", "A-Cross was pressed");
                ballBlock.toggle();
            }

            telemetry.addLine("X-Square - Intake Forward/STOP");
            telemetry.addLine("B-Circle - Intake Reverse/STOP");
            telemetry.addLine("A-Cross - Ball Block Open/CLOSE");
            telemetry.update();
        }
    }
}
