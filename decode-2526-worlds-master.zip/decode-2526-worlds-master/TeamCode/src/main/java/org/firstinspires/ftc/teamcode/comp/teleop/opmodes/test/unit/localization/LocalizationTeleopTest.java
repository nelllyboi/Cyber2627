package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.localization;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.partial.turret.TurretLocalizationTest;

@TeleOp(name="localization teleop WAHOO", group="Test")
@Disabled
public class LocalizationTeleopTest extends LinearOpMode {

    @Override
    public void runOpMode() throws InterruptedException {


        TurretLocalizationTest localizer = new TurretLocalizationTest(hardwareMap);


        waitForStart();

        while (opModeIsActive()) {
            localizer.update(telemetry, 24, true, 0);
        }
    }}
