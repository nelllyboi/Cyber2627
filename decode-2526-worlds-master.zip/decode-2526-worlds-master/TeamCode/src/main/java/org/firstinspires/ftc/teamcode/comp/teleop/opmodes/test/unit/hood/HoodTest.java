package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.hood;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;

@Config
@Configurable
@Disabled

@TeleOp(name = "Hood Test", group = "Test")
public class HoodTest extends OpMode {

    public static double HOOD_POS = 0.0;

    FtcDashboard dashboard = FtcDashboard.getInstance();

    private Servo hoodServo;

    @Override
    public void init() {
        hoodServo = hardwareMap.get(Servo.class, "hood");
    }

    @Override
    public void loop() {
        TelemetryPacket packet = new TelemetryPacket();

        hoodServo.setPosition(HOOD_POS);

        telemetry.addData("Hood Position", HOOD_POS);
        packet.put("Hood Pos", HOOD_POS);

        dashboard.sendTelemetryPacket(packet);
        telemetry.update();
    }
}