package org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems;

import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.regressBlueIdle;
import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.regressRedIdle;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImpl;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.flywheel.FlywheelPIDF;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut.HoodLUT;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut.VelocityLUT;

@Configurable
public class ShooterAuto {

    public enum ShotMode {
        NORMAL,
        FAR
    }

    private ShotMode shotMode = ShotMode.NORMAL;

    public FlywheelPIDF flywheel;
    public DcMotorEx flywheelMotor;
    public DcMotorEx flywheelMotor2;
    public boolean flywheelOn;
    private double targetRpm = 1500;
    public boolean atSpeed = false;
    private ServoImplEx hood;
    public static double IDLE_POWER = 0.6;

    public ShooterAuto(HardwareMap hardwareMap) {
        this(hardwareMap, ShotMode.NORMAL);
    }

    // Constructor with selectable mode
    public ShooterAuto(HardwareMap hardwareMap, ShotMode mode) {
        this.shotMode = mode;

        hood = hardwareMap.get(ServoImplEx.class, "hood");
        hood.setDirection(Servo.Direction.REVERSE);

        flywheelMotor = hardwareMap.get(DcMotorEx.class, "flywheel");
        flywheelMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        flywheelMotor.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

        flywheelMotor2 = hardwareMap.get(DcMotorEx.class, "flywheel2");
        flywheelMotor2.setDirection(DcMotorSimple.Direction.REVERSE);
        flywheelMotor2.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

        flywheel = new FlywheelPIDF(flywheelMotor, flywheelMotor2);
    }

    public double retLoop(double dist) {
        dist  = dist -7;
        targetRpm = VelocityLUT.get(dist) - 150;
        double hoodPos = HoodLUT.get(dist, flywheel.getRPM()) - 0.04;
        hood.setPosition(hoodPos);
        double power = 0;
        if (flywheelOn) {
            power = flywheel.controller(targetRpm, flywheel.getRPM());
        } else {
            power = IDLE_POWER;
        }

        power = Math.max(0, Math.min(1, power));
        flywheel.setPower(power);

        if (Math.abs(flywheel.getRPM() - targetRpm) < 50) {
            atSpeed = true;
        } else {
            atSpeed = false;
        }

        return targetRpm;
    }

    public double retLoopRed(double x, double y) {
        double power = 0;

        if (flywheelOn) {

            double[] shootRets;

            /*if (shotMode == ShotMode.NORMAL) {
                shootRets = Shooter.calculateShotVectorNoVelRed(x, y);
            } else {
                shootRets = Shooter.calculateShotVectorNoVelRed(x, y);
            }*/

//            power = velToRPM(shootRets[1]);
//            targetRpm = velToRPM(shootRets[1]);

            if (shotMode == ShotMode.NORMAL) {
                power += 50;
                targetRpm += 50;
            } else {
                power -= 50;
                targetRpm -= 50;
            }

            /*double hoodAngle = clamp(
                    90 - Math.toDegrees(shootRets[0]),
                    Math.toDegrees(HOOD_MAX),
                    Math.toDegrees(HOOD_MIN)
            );

            flywheel.setHoodAngle(hoodAngle);*/

        } else {
            power = 0;
        }

//        flywheel.setRPM(power);

        if (Math.abs(flywheel.getRPM() - targetRpm) < 50) {
            atSpeed = true;
        } else {
            atSpeed = false;
        }

        return flywheel.getRPM();
    }

    public double retLoopBlue(double x, double y) {
        double power = 0;

        if (flywheelOn) {

            double[] shootRets;

            /*if (shotMode == ShotMode.NORMAL) {
                shootRets = Shooter.calculateShotVectorNoVelBlue(x, y);
            } else {
                shootRets = Shooter.calculateShotVectorNoVelBlue(x, y);
            }*/

//            power = velToRPM(shootRets[1]);
//            targetRpm = velToRPM(shootRets[1]);

            if (shotMode == ShotMode.NORMAL) {
                power += 50;
                targetRpm += 50;
            } else {
                power -= 50;
                targetRpm -= 50;
            }

            /*double hoodAngle = clamp(
                    90 - Math.toDegrees(shootRets[0]),
                    Math.toDegrees(HOOD_MAX),
                    Math.toDegrees(HOOD_MIN)
            );

            flywheel.setHoodAngle(hoodAngle);*/

        } else {
            power = 0;
        }

//        flywheel.setRPM(power);

        if (Math.abs(flywheel.getRPM() - targetRpm) < 50) {
            atSpeed = true;
        } else {
            atSpeed = false;
        }

        return flywheel.getRPM();
    }

    public double retLoopRedTeleop(double x, double y) {
        double power = 0;

        if (flywheelOn) {
            // pass
        } else {
            power = regressRedIdle(x, y);
        }

        power = Math.max(0, Math.min(1, power));

        if (Math.abs(flywheel.getRPM() - targetRpm) < 50) {
            atSpeed = true;
        } else {
            atSpeed = false;
        }

        return flywheel.getRPM();
    }

    public double retLoopBlueTeleop(double x, double y) {
        double power = 0;

        if (flywheelOn) {
            // pass
        } else {
            power = regressBlueIdle(x, y);
        }

        power = Math.max(0, Math.min(1, power));

        if (Math.abs(flywheel.getRPM() - targetRpm) < 50) {
            atSpeed = true;
        } else {
            atSpeed = false;
        }

        return flywheel.getRPM();
    }

    public class FlywheelOn implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            flywheelOn = true;
            return false;
        }
    }

    public class FlywheelOff implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            flywheelOn = false;
            return false;
        }
    }

    public class SetFlywheelSpeed implements Action {
        double speed;

        public SetFlywheelSpeed(double speed) {
            this.speed = speed;
        }

        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
//            targetRpm = speed;
            return false;
        }
    }

    public class WaitForTargetRPM implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            return !atSpeed;
        }
    }

    public boolean isAtSpeed() {
        return flywheelOn;
    }

    public Action flywheelOn() { return new FlywheelOn(); }
    public Action flywheelOff() { return new FlywheelOff(); }
    public Action setSpeed(double speed) { return new SetFlywheelSpeed(speed); }
    public void setSpeedTeleop(double speed) { targetRpm = speed; }
    public Action waitRPM() { return new WaitForTargetRPM(); }

    public double currRPM() { return flywheel.getRPM(); }

    public void setIdlePower(double power) {
        IDLE_POWER = power;
    }
}
