package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.complete;

import com.acmerobotics.dashboard.config.Config;
import com.bylazar.field.PanelsField;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.localizers.Localizer;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.localizers.LocalizerTurret;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut.HoodLUT;
import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut.VelocityLUT;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Drive;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Lift;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Shooter;

@TeleOp(name = "red localizing teleop", group = "none")
@Disabled
@Config
public class LocalizationTeleopTest extends LinearOpMode {

    PanelsField dashboard = PanelsField.INSTANCE;





    private boolean enableDrive = true;
    private double odo_turret_angle = 0;
    private int velo_offset = 0;

    private Drive drive;
    private ElapsedTime timer= new ElapsedTime();
    private double count=0;
    private double hoodAngle = 0;
    private double hoodAngleOld = 0;
    private double targetRPMOld = 0;
    private Lift lift;
    private TurretServo turret;
    private Shooter shooter;
    private DcMotorEx intake;
    private DcMotorEx transfer;
    private Servo ballBlock;
    private LocalizerTurret localizer;


    Constants.ShootSequence shootSequence = Constants.ShootSequence.IDLE;

    private double turretOffset = 0;
    private double rpmOffset = 0;
    private double actual_angle = 0;
    private double startingTurret = 0;
    private boolean still = false;
    private double oldAngle = 0;
    public int state = 0;
    private double currentAngle = 0;
    private double oldTarget=0;
    public static double targetRPM = 2000;
    public static double hoodPos = 0.5;

    private double calculatedRPM;

    public void runOpMode() {

        localizer = new LocalizerTurret(hardwareMap);

        //shooter = new Shooter(hardwareMap);
        turret = new TurretServo(hardwareMap, true);
        drive = new Drive(hardwareMap);
        lift = new Lift(hardwareMap);
        shooter = new Shooter(hardwareMap);
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
        ballBlock = hardwareMap.get(Servo.class, "ballBlock");


        lift.disengageLift();
        turret.setPosition(0.475);
        waitForStart();

        timer.reset();
        boolean regressionActive = true;

        while (opModeIsActive()) {
            // Get current voltage /typically 0 to 3.3V on REV Hubs)


            localizer.update(telemetry, 24, localizer.still());

//            double x = localizer.x;
//            double y = localizer.y;
////            double theta = Math.toRadians(localizer.heading);
//            double theta = localizer.heading;

//
//            if (x >= 24 && shootSequence != Constants.ShootSequence.IDLE) {
//                transfer.intakeLoop(true);
//            } else {
//                transfer.intakeLoop(false);
//            }
//
//            telemetry.addData("x", x);
//            telemetry.addData("y", y);
//            telemetry.addData("t", theta);

//            double odo_turret_angle =
//                    turret.calculateTurretAngle(
//                            x,
//                            y,
//                            0,
//                            0,
//                            Math.toDegrees(-theta)
//                    );
//            odo_turret_angle = (theta - 180 * Math.atan((y) / x) / Math.PI+localizer.pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES)*.075+360+turretOffset)%360;
            odo_turret_angle = (localizer.heading - 180 * Math.atan((localizer.y) / localizer.x) / Math.PI+localizer.pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES)*.075+360+turretOffset)%360;
            if (odo_turret_angle<0){odo_turret_angle+=360;}
            if (localizer.localized) {
//                turret.setPosition(turretAngle);
                if (Math.abs(odo_turret_angle-oldTarget)>1){
                    turret.setPosition(odo_turret_angle/360*.85+0.05);
                    oldTarget = odo_turret_angle;

                }
            }
            telemetry.addData("taget angle", odo_turret_angle);


            telemetry.addData("currentAngle", currentAngle);


//            odo_turret_angle = (odo_turret_angle/360)*0.85+0.05;
//            turret.setPosition(odo_turret_angle);


//            double normalized_odo_turret_angle =
//                    TurretServo.normalizeDegrees(odo_turret_angle + turretOffset);
//
//            double targetRPM = regressBlue(x, y);
//            if (targetRPM > 3600) {
//                targetRPM = 3600;
//            }

            if (shootSequence == Constants.ShootSequence.IDLE && enableDrive) {
                drive.driveLoop(
                        gamepad1.left_stick_y,
                        1.5 * gamepad1.right_stick_x
                );}
            targetRPM = VelocityLUT.get(localizer.distance);
            hoodAngle = HoodLUT.get(localizer.distance, shooter.getRPM());




            count++;
            targetRPM = VelocityLUT.get(localizer.distance)+velo_offset;
            hoodAngle = HoodLUT.get(localizer.distance, shooter.getRPM());

            telemetry.addData("loopTimes", count/timer.seconds());

            if(gamepad1.right_trigger>.5 && state!=0){intake.setPower(1);transfer.setPower(-1);ballBlock.setPosition(0.38);state=0;velo_offset=0;}
            else if(gamepad1.left_trigger>0.5 && state!=1){intake.setPower(.5);transfer.setPower(-1);ballBlock.setPosition(0.21);state=1;velo_offset=0;}
            else if (state!=2 && gamepad1.right_trigger<.5 && gamepad1.left_trigger<0.5){intake.setPower(0);transfer.setPower(0);ballBlock.setPosition(0.38);state=2;velo_offset=0;}

            telemetry.addData("curr rpm", shooter.getRPM());
            telemetry.addData("taget rpm", targetRPM);
            shooter.setRPM(targetRPM);

            if (Math.abs(hoodAngle-hoodAngleOld)>0.03){
                shooter.setHoodPos(hoodAngle);hoodAngleOld=hoodAngle;}
//             else {
//                drive.driveLoop(
//                        gamepad1.right_stick_y,
//                        0
//                );
//            }
//
//            if (gamepad1.squareWasPressed()) {
//                transfer.intakeForward();
//            }
//            else if (gamepad1.circleWasPressed()) {
//                transfer.intakeBackward();
//            }
//
            if (gamepad1.dpadRightWasPressed()) {
                turretOffset += 2;
//                gamepad1.rumble(300);
            }
            else if (gamepad1.dpadLeftWasPressed()) {
                turretOffset -= 2;
//                gamepad1.rumble(300);
            }
//
//            if (gamepad1.dpadUpWasPressed()) {
//                rpmOffset += 50;
//                gamepad1.rumble(300);
//            }
//            else if (gamepad1.dpadDownWasPressed()) {
//                rpmOffset -= 50;
//                gamepad1.rumble(300);
//            }
//
//            shooter.setRPM(targetRPM + rpmOffset);
//
//            if (gamepad1.crossWasPressed()) {
//                regressionActive = !regressionActive;
//            }
//
//            if (gamepad1.rightBumperWasPressed()
//                    && shootSequence == Constants.ShootSequence.IDLE) {
//
//                flywheelOn = true;
//
//                transfer.blockOut();
//                transfer.intakeForward();
//                transfer.transferForward();
//
//                shootSequence = Constants.ShootSequence.SPIN_UP;
//                shootSequenceTimer.reset();
//
//                Object[] ll_rets = blueATE.retLoopMT2();
//
//                double errorInDegs = 0;
//
//                if ((boolean) ll_rets[0]) {
//                    errorInDegs = (double) ll_rets[1];
//                    errorInDegs -= turretOffset;
//                }
//
//                startingTurret =
//                        turret.getTargetAngle()
//                                + errorInDegs * kP;
//            }
//
//            if (shootSequence == Constants.ShootSequence.SPIN_UP && (shootSequenceTimer.milliseconds() > 500 || (shooter.isAtSpeed(targetRPM + rpmOffset) && Math.abs(txOff) < 1))) {
//
//                transfer.blockIn();
//
//                shootSequence = Constants.ShootSequence.SHOOTING;
//
//                RobotLog.vv(
//                        "Bot",
//                        "Shootsequence set to %s, Timer %.3f",
//                        shootSequence,
//                        shootSequenceTimer.milliseconds()
//                );
//
//                shootSequenceTimer.reset();
//            }
//
//            else if (shootSequence == Constants.ShootSequence.SHOOTING
//                    && shootSequenceTimer.milliseconds() > 500) {
//
//                transfer.intakeForward();
//                transfer.blockOut();
//                transfer.transferOff();
//
//                shootSequence = Constants.ShootSequence.IDLE;
//
//                flywheelOn = false;
//
//                RobotLog.vv(
//                        "Bot",
//                        "Shootsequence set to %s, Timer %.3f",
//                        shootSequence,
//                        shootSequenceTimer.milliseconds()
//                );
//            }
//
//            if (shootSequence == Constants.ShootSequence.IDLE) {
//                turret.setTargetAngleInDegrees(normalized_odo_turret_angle);
//            } else {
//                Object[] ll_rets = blueATE.retLoopMT2();
//
//                double errorInDegs = 0;
//
//                if ((boolean) ll_rets[0]) {
//                    errorInDegs = (double) ll_rets[1] - lmDegsOffset;
//                    txOff = errorInDegs;
//                }
//
//                double angle =
//                        turret.getTargetAngle()
//                                + errorInDegs * kP;
//
//                angle =
//                        TurretServo.normalizeDegrees(angle);
//
//                actual_angle = angle;
//
//                turret.setTargetAngleInDegrees(angle);
//            }
//
//            if (shootSequence == Constants.ShootSequence.IDLE
//                    && gamepad1.triangleWasPressed()) {
//
//                enableDrive = false;
//                lift.engageLift();
//            }
//
//            if (gamepad1.leftBumperWasPressed()) {
//                shootSequence = Constants.ShootSequence.IDLE;
//            }

//            dashboard.getField().moveCursor(x, y);
            dashboard.getField().circle(3.0);
            dashboard.getField().update();
        }
    }
}
