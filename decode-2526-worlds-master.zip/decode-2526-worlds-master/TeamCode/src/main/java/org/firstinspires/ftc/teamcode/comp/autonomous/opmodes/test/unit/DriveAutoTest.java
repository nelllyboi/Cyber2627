package org.firstinspires.ftc.teamcode.comp.autonomous.opmodes.test.unit;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.bylazar.field.CanvasRotation;
import com.bylazar.field.FieldPresetParams;
import com.bylazar.field.PanelsField;
import com.bylazar.panels.Panels;
import com.bylazar.telemetry.TelemetryManager;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
import org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems.TurretAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.DriveAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.RedTurretAuto;
import org.firstinspires.ftc.teamcode.globals.Globals;

import java.util.concurrent.atomic.AtomicBoolean;

@Disabled
@Autonomous
public class DriveAutoTest extends LinearOpMode {
    PanelsField field = PanelsField.INSTANCE;
    FtcDashboard dashboard = FtcDashboard.getInstance();
    FieldPresetParams params = new FieldPresetParams(
            "aman",
            0,
            0,
            CanvasRotation.DEG_90,
            false,
            false,
            true
    );

    @Override
    public void runOpMode() {
        RedTurretAuto turret = new RedTurretAuto(hardwareMap, -57, 44.5);

        waitForStart();

        DriveAuto drive = new DriveAuto(hardwareMap, -57, 44.5, 180, false);

        AtomicBoolean running = new AtomicBoolean(true);

        field.getField().setOffsets(params);

        Thread backgroundLoop = new Thread(() -> {
            while ((opModeIsActive() || opModeInInit()) && running.get()) {
                TelemetryPacket packet = new TelemetryPacket();
                double[] rets = drive.odo.retPos();

                packet.put("X", rets[0]);
                packet.put("Y", rets[1]);
                packet.put("T", rets[2]);

                double rtn = turret.retLoop(rets[0], rets[1], Math.toDegrees(rets[2]));
                packet.put("angle it thinks its at", rtn);
                telemetry.addData("angle wrap rtn", rtn);
//                packet.put("Speed", shooter.retLoop());
//                packet.put("At speed?", shooter.isAtSpeed());
                packet.fieldOverlay()
                        .fillRect(rets[0], rets[1], 2, 2);

                Globals.START_X = rets[0];
                Globals.START_Y = rets[1];
                Globals.START_THETA = Math.toDegrees(rets[2]);

                dashboard.sendTelemetryPacket(packet);
            }
        });

        backgroundLoop.start();

        Actions.runBlocking(
                new SequentialAction(
                        new SleepAction(30)
                )
        );
    }
}
