package org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.HardwareMap;

@Configurable
public class BreakBeam {
    private DigitalChannel laserInput;
    private DigitalChannel laserInput1;
    private int detectTicks = 0;
    public static final int TICK_THRESHOLD = 5;
    public BreakBeam(HardwareMap hardwareMap) {
        laserInput = hardwareMap.get(DigitalChannel.class, "laserDigitalInput");
        laserInput1 = hardwareMap.get(DigitalChannel.class, "laserDigitalInput1");

        laserInput.setMode(DigitalChannel.Mode.INPUT);
        laserInput1.setMode(DigitalChannel.Mode.INPUT);
    }

    public boolean allThree() {
        boolean stateHigh0 = laserInput.getState();
        boolean stateHigh1 = laserInput1.getState();
        boolean detected = stateHigh0 && stateHigh1;

        if (detected) {
            detectTicks++;
        } else {
            detectTicks = 0; // reset if broken
        }

        if (detectTicks >= TICK_THRESHOLD) {
            return true;
        } else {
            return false;
        }
    }
}
