package org.firstinspires.ftc.teamcode.development.teleop.opmodes.test.unit.hood;

import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.map;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Shooter;

@TeleOp
@Disabled
@Configurable
public class HoodTest extends LinearOpMode {
    public static double pos = 0;
    public static boolean angle = false;
    public Shooter shooter;

    @Override
    public void runOpMode() {

        shooter = new Shooter(hardwareMap);

        waitForStart();

        while (opModeIsActive()) {
            if (angle) {
                shooter.setHoodAngle(pos);
            } else {
                shooter.setHoodPos(pos);
            }
            telemetry.addData("alsdjflaksdjf", map(pos, Shooter.hood_ang_low, Shooter.hood_ang_high, Shooter.hood_pos_low, Shooter.hood_pos_high));
            telemetry.update();
        }
    }
}
