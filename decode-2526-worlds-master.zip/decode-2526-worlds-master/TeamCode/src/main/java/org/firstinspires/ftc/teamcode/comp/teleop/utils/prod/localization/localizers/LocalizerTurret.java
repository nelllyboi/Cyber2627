// IntelliJ API Decompiler stub source generated from a class file
// Implementation of methods is not available

package org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.localizers;


import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut.AirtimeLUT;

import java.util.List;
import java.util.Timer;

@com.bylazar.configurables.annotations.Configurable
public class LocalizerTurret {
    public double headingVelo = 0;
    public double xVelo = 0;
    public double yVelo = 0;

    private AnalogInput ma3Encoder;
    public static double Ratio = 2.06107;
    private double currentAngle;
    private Pose2D goalPose;
    private Pose2D realGoalPose;
    private Pose2D realFieldPose;
    private Pose2D fieldPose;

    public static double alpha = 0.1;
    private double count =0;
    public static double kP = 0.025;
    public static double kD = .0015;
    public static double hoodAngle = 0.4;
    private double hoodAngleOld = hoodAngle;
    private double turretAngleMultiplier = 1300/180.0;

    private int loopCounter = 0;
    private Limelight3A limelight;
    public GoBildaPinpointDriver pinpoint;


    public boolean angled = false;
    public boolean localized = false;

    private Timer timer = new Timer();
    public static double velocity = 3000;
    public double heading = 0;

    public double x =0;
    public double y=0;

    double updatedx = 0;
    double updatedy=0;
    double updatedheading=0;
    private double oldx =0;
    private double oldy=0;

    private Pose2D pose;
    public double distance=0;
    public double oldDistance = 0;
    public double totalDistance = 0;
    public boolean found=false;



    private int direction;
    LLResult result;
    private double power = 0;
    private double oldPower = 0;

    private double flywheelRightVel = 0;

    public void setStartPose(double x, double y, double heading) {

        pinpoint.setPosition(new Pose2D(DistanceUnit.INCH, x, y, AngleUnit.DEGREES, heading));

        updatedx = x;
        updatedy = y;
        updatedheading = heading;

        oldx = x;
        oldy = y;

        localized = false;
        found = false;
    }

    public LocalizerTurret(HardwareMap hardwareMap) {
        ma3Encoder = hardwareMap.get(AnalogInput.class, "turretencoder");

        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "odo");
        pinpoint.resetPosAndIMU(); // zero both odometry and IMU
        pinpoint.setEncoderDirections(GoBildaPinpointDriver.EncoderDirection.REVERSED, GoBildaPinpointDriver.EncoderDirection.REVERSED);
        pinpoint.setOffsets(2.75, -3.75, DistanceUnit.INCH);

        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.pipelineSwitch(0);
        limelight.setPollRateHz(100);
        limelight.start();

    }
    public boolean inFarZoneRed() {
        // Define the 3 triangle points
        double x1 = 28, y1 = 0;
        double x2 = 52, y2 = 18;
        double x3 = 52, y3 = -30;

        // Calculate area of full triangle
        double A = Math.abs((x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2)) / 2.0);

        // Calculate areas of 3 smaller triangles
        Pose2D realPose = getRealFieldPose();
        double x = realPose.getX(DistanceUnit.INCH);
        double y = realPose.getY(DistanceUnit.INCH);
        double A1 = Math.abs((x*(y2-y3) + x2*(y3-y) + x3*(y-y2)) / 2.0);
        double A2 = Math.abs((x1*(y-y3) + x*(y3-y1) + x3*(y1-y)) / 2.0);
        double A3 = Math.abs((x1*(y2-y) + x2*(y-y1) + x*(y1-y2)) / 2.0);

        // Check if sum of smaller areas equals full area
        return Math.abs(A - (A1 + A2 + A3)) < 50 && Math.abs(xVelo)<5 && yVelo>-5 && yVelo<30;
    }
    public boolean still(){
        if (Math.abs(xVelo)<2 &&Math.abs(yVelo)<2 &&
                Math.abs(headingVelo)<5){
            return true;
        }
        return false;
    }

    public void update(Telemetry telemetry, int targetID, boolean localizing) {
        pinpoint.update();
        headingVelo = pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES);
        xVelo = pinpoint.getVelX(DistanceUnit.INCH);
        yVelo = pinpoint.getVelY(DistanceUnit.INCH);
        pose = pinpoint.getPosition();
        loopCounter+=1;
        double currentVoltage = ma3Encoder.getVoltage();
        if (loopCounter==1){LLResult result = limelight.getLatestResult();}
        currentAngle = ((((currentVoltage-.053)/ 3.135)-.05)/.85*360+360)%360;
        if(still()){result = limelight.getLatestResult();}
//        telemetry.addData("staleness", result.getStaleness());
        List<LLResultTypes.FiducialResult> fiducials = result.getFiducialResults();
        telemetry.addData("found?", result.isValid());

        if (result.isValid()) {
            for (LLResultTypes.FiducialResult fiducial : fiducials) {
                int id = fiducial.getFiducialId();
                if (id == targetID) {
                    x = (fiducial.getCameraPoseTargetSpace().getPosition().z);
                    y = (fiducial.getCameraPoseTargetSpace().getPosition().x);
                    heading = fiducial.getCameraPoseTargetSpace().getOrientation().getRoll()+currentAngle;
                    if (heading>180){
                        heading-=360;
                    }
                    if(heading<-180){heading+=360;}
//                        double theta = Math.toRadians(turretAngle);
//                        double rotatedX = x * Math.cos(theta) - y * Math.sin(theta);
//                        double rotatedY = x * Math.sin(theta) + y * Math.cos(theta);
//                        x = rotatedX;
//                        y = rotatedY;

//                         existing offsets
                    y -= 0.15;
                    x -= 0.2;
                    if (!localized && localizing) {
                        pinpoint.setPosition(new Pose2D(DistanceUnit.METER, -x, y, AngleUnit.DEGREES, heading));
                        updatedx=-x;
                        updatedy=y;
                        updatedheading=heading;
                        localized = true;
                        found = true;
                        count += 1;
                    } else {
                        found = true;
                        //x+=.65;
                        //heading+=turetOfset;
                        //pinpoint.getVelX(DistanceUnit.INCH) < 5 && pinpoint.getVelY(DistanceUnit.INCH) < 5 && pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES) < 2 && pinpoint.getPosX(DistanceUnit.INCH) < 70 && Math.abs(pinpoint.getPosY(DistanceUnit.INCH)) < 20
                        if (localizing) {
                            alpha = 0.4*1 / Math.max(1, result.getStaleness()) * Math.max(Math.min(10, totalDistance / 300), 1);
                            updatedx = (-x * alpha + pose.getX(DistanceUnit.METER)) / (1 + alpha);
                            updatedy = (y * alpha + pose.getY(DistanceUnit.METER)) / (1 + alpha);
                            updatedheading = (heading * alpha/25 + pose.getHeading(AngleUnit.DEGREES)) / (1 + alpha/25);
                            if (updatedheading > 180) {
                                updatedheading -= 360;
                            }


                            totalDistance = totalDistance * 3 / 10;
                            count += 1;
                            if (Math.abs(x-pose.getX(DistanceUnit.METER))<0.3 && Math.abs(y-pose.getY(DistanceUnit.METER))<.3 && Math.abs(heading-pose.getHeading(AngleUnit.DEGREES))<5) {
                                pinpoint.setPosition(new Pose2D(DistanceUnit.METER, updatedx, updatedy, AngleUnit.DEGREES, updatedheading));}

//                                pinpoint.setPosition(new Pose2D(DistanceUnit.METER, (-x * alpha + pinpoint.getPosX(DistanceUnit.METER)) / (1 + alpha), (y * alpha + pinpoint.getPosY(DistanceUnit.METER)) / (1 + alpha), AngleUnit.DEGREES, (heading * alpha + pinpoint.getHeading(AngleUnit.DEGREES)) / (1 + alpha)));


//
//
//                    if (!localized && still() && count < 1) {
//                        pinpoint.setPosition(new Pose2D(DistanceUnit.METER, -x, y, AngleUnit.DEGREES, heading));
//                        localized = true;
//                        found = true;
//                        count += 1;
//                    }
//
//                    else {
//                        found = true;
//                        if (still()) {
//                            alpha = 0.025 * 10 / Math.max(1, result.getStaleness())*Math.max(Math.min(10, totalDistance/300), 1);
//                            totalDistance=totalDistance*9/10;
//                            pinpoint.setPosition(new Pose2D(DistanceUnit.METER, (-x * alpha + pinpoint.getPosX(DistanceUnit.METER)) /
//                                    (1 + alpha), (y * alpha + pinpoint.getPosY(DistanceUnit.METER)) /
//                                    (1 + alpha), AngleUnit.DEGREES, (heading * alpha + pinpoint.getHeading(AngleUnit.DEGREES)) /
//                                    (1 + alpha)));
//                            count += 1;
//                        }
                        }
                    }

                }}}

        x = pose.getX(DistanceUnit.INCH);
        y = pose.getY(DistanceUnit.INCH);
        heading = pose.getHeading(AngleUnit.DEGREES);

        realGoalPose = new Pose2D(DistanceUnit.INCH, x, y, AngleUnit.DEGREES, heading);

        y+=yVelo* AirtimeLUT.get(distance);
        distance = Math.sqrt(x * x + y * y);
        totalDistance += Math.abs(Math.sqrt((x-oldx) * (x-oldx) + (y-oldy) * (y-oldy)));
        goalPose = new Pose2D(DistanceUnit.INCH, x, y, AngleUnit.DEGREES, heading);
        double phi = Math.toRadians(52.5);

        double xprime = (goalPose.getX(DistanceUnit.INCH) - 72) * Math.cos(phi) + (goalPose.getY(DistanceUnit.INCH) - 72) * Math.sin(phi);
        double yprime = (goalPose.getX(DistanceUnit.INCH) - 72) * Math.sin(phi) + (goalPose.getY(DistanceUnit.INCH) - 72) * Math.cos(phi);
        double thetaprime = heading - 52.5;
        fieldPose = new Pose2D(DistanceUnit.INCH, xprime, yprime, AngleUnit.DEGREES, thetaprime);

        xprime = 29 + (realGoalPose.getX(DistanceUnit.INCH) - 72) * Math.cos(phi) + (realGoalPose.getY(DistanceUnit.INCH) - 72) * Math.sin(phi);
        yprime = 48 -(realGoalPose.getX(DistanceUnit.INCH) - 72) * Math.sin(phi) + (realGoalPose.getY(DistanceUnit.INCH) - 72) * Math.cos(phi);
        thetaprime = realGoalPose.getHeading(AngleUnit.DEGREES) - 52.5;
        realFieldPose = new Pose2D(DistanceUnit.INCH, xprime, yprime, AngleUnit.DEGREES, thetaprime);

        oldx=x;
        oldy=y;
//        telemetry.addData("updatex", updatedx*39.37);
//        telemetry.addData("updatey", updatedy*39.37);
//        telemetry.addData("updateheading", updatedheading);


        telemetry.addData("localizing", localizing);

        telemetry.addData("x:", x);
        telemetry.addData("y:", y);
//        telemetry.addData("distance: ", distance);
        telemetry.addData("heading:", heading);
        telemetry.addData("count", count);

//        telemetry.addData("turretAngle", turretAngle);
        telemetry.update();

    }

    public Pose2D getGoalPose() {
        return goalPose;
    }

    public Pose2D getFieldPose() { return fieldPose; }

    public Pose2D getRealFieldPose() { return realFieldPose; }

    public Pose2D getRealGoalPose() {
        return realGoalPose;
    }
}