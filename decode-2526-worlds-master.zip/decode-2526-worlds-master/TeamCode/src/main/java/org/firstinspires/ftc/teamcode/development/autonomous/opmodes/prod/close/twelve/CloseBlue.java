package org.firstinspires.ftc.teamcode.development.autonomous.opmodes.prod.close.twelve;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.BallBlockAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.BlueTurretAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.DriveAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.IntakeAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.ShooterAuto;
import org.firstinspires.ftc.teamcode.globals.Globals;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.function.Supplier;

@Autonomous(name="Blue - Close Side", group = "Close", preselectTeleOp = "Blue Teleop")
public class CloseBlue extends LinearOpMode {

    public static double start_theta = 180;
    @Override
    public void runOpMode() throws InterruptedException {

        FtcDashboard dashboard = FtcDashboard.getInstance();

        DriveAuto drive = new DriveAuto(hardwareMap, -57, -44.5, start_theta, false);
        IntakeAuto intake = new IntakeAuto(hardwareMap);
        BallBlockAuto ballBlock = new BallBlockAuto(hardwareMap);
        BlueTurretAuto turret = new BlueTurretAuto(hardwareMap, -57, -44.5);
        ShooterAuto shooter = new ShooterAuto(hardwareMap, ShooterAuto.ShotMode.NORMAL);

        Function<Double, Action> ramp = speed -> new ParallelAction(
                intake.intakeForward(),
                intake.transferForward(),
                ballBlock.blockClose(),
                shooter.setSpeed(speed),
                shooter.flywheelOn(),
                shooter.waitRPM()
        );

        Supplier<Action> shoot = () -> new SequentialAction(
                new SleepAction(0.3),
                turret.enableLimelight(),
                new SleepAction(0.2),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockClose(),
                        intake.transferForward()
                ),
                new SleepAction(0.05),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockOpen(),
                        intake.transferForward()
                ),
                new SleepAction(0.05),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockOpen(),
                        intake.transferForward()
                ),
                new SleepAction(0.3),
                new ParallelAction(
                        ballBlock.blockClose(),
                        intake.transferOff(),
                        turret.disableLimelight()
                )
        );

        turret.setLmDegsOff(0.35);

        waitForStart();

        AtomicBoolean running = new AtomicBoolean(true);

        Thread backgroundLoop = new Thread(() -> {
            while ((opModeIsActive() || opModeInInit()) && running.get()) {

                TelemetryPacket packet = new TelemetryPacket();
                double[] rets = drive.odo.retPos();

                packet.put("X", rets[0]);
                packet.put("Y", rets[1]);
                packet.put("T", rets[2]);

                double rtn = turret.retLoop(rets[0], rets[1], Math.toDegrees(rets[2]));
                packet.put("angle it thinks its at", rtn);
                telemetry.addData("angle wrap rtn", rtn);
                double dist_x = rets[0] + 72;
                double dist_y = 72 + rets[1];
                double dist = Math.hypot(dist_x, dist_y);
                packet.put("Speed", shooter.retLoop(dist));
                packet.fieldOverlay()
                        .fillRect(rets[0], rets[1], 2, 2);

                Globals.START_X = rets[0];
                Globals.START_Y = rets[1];
                Globals.START_THETA = Math.toDegrees(rets[2]);

                dashboard.sendTelemetryPacket(packet);
            }
        });


        backgroundLoop.start();

        Actions.runBlocking(
                new SequentialAction(
                        turret.disableLimelight(),
                        ballBlock.blockClose(),
                        new SleepAction(0.2),
                        intake.intakeForward(),
                        new SleepAction(0.1),
                        new ParallelAction(
                                ramp.apply(2750.0),
                                new SequentialAction(
                                        drive.toPointBackwards(-12.9, -22, 0) // back
                                )
                        ),
                        new SleepAction(0.3),
                        shoot.get(),

                        drive.toPoint(-11, -28, 0), // int 1 preset
                        drive.toPointThird(-14, -52.5, 0), // int 1 intake
                        drive.toPointBackwards(-10, -37.6, -4), // class preset
                        intake.intakeOff(),
                        drive.toPointThird(-5, -55, -4), // class hit
                        new SleepAction(0.5),
                        intake.intakeForward(),

                        new ParallelAction(
                                ramp.apply(2750.0),
                                drive.toPointBackwards(-15, -22, 0) // back
                        ),
                        shoot.get(),

                        drive.toPoint(8, -22.5, 0), // int 2 preset
                        drive.toPointThird(15, -61.5, 0), // int 2 intake

                        new ParallelAction(
                                ramp.apply(2750.0),
                                drive.toPointBackwardsThird(-10, -15, 0) // back
                        ),
                        shoot.get(),

                        drive.toPoint(18.5, -23.5, 0), // int 3 preset
                        drive.toPointThird(34.5, -60, 0), // int 3 intake\

                        new ParallelAction(
                                ramp.apply(2750.0),
                                drive.toPointBackwardsThird(-10, -15, 0) // back
                        ),
                        shoot.get(),
                        drive.toPoint(-10, -23, 0) // park
                )
        );
    }

}
