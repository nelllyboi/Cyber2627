package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.globals.Constants;

public class DriveTrain {

    DcMotor leftFront;
    DcMotor leftRear;
    DcMotor rightFront;
    DcMotor rightRear;

    public DriveTrain() {

    }

    public void init(HardwareMap hardwareMap) {
        leftFront = hardwareMap.get(DcMotor.class, Constants.DT_LEFT_FRONT);
        leftRear = hardwareMap.get(DcMotor.class, Constants.DT_LEFT_REAR);
        rightFront = hardwareMap.get(DcMotor.class, Constants.DT_RIGHT_FRONT);
        rightRear = hardwareMap.get(DcMotor.class, Constants.DT_RIGHT_REAR);

        leftFront.setMode(Constants.DT_RUNMODE_ENCODER);
        leftRear.setMode(Constants.DT_RUNMODE_ENCODER);
        rightFront.setMode(Constants.DT_RUNMODE_ENCODER);
        rightRear.setMode(Constants.DT_RUNMODE_ENCODER);

        leftFront.setDirection(Constants.DT_LEFT_FRONT_DIRECTION);
        leftRear.setDirection(Constants.DT_LEFT_REAR_DIRECTION);
        rightFront.setDirection(Constants.DT_RIGHT_FRONT_DIRECTION);
        rightRear.setDirection(Constants.DT_RIGHT_REAR_DIRECTION);

        leftFront.setZeroPowerBehavior(Constants.DT_ZERO_POWER_BEHAVIOR);
        leftRear.setZeroPowerBehavior(Constants.DT_ZERO_POWER_BEHAVIOR);
        rightFront.setZeroPowerBehavior(Constants.DT_ZERO_POWER_BEHAVIOR);
        rightRear.setZeroPowerBehavior(Constants.DT_ZERO_POWER_BEHAVIOR);
    }

    public void run(double forward, double left, Telemetry telemetry) {
        leftFront.setPower(forward + left);
        leftRear.setPower(forward + left);
        rightFront.setPower(forward - left);
        rightRear.setPower(forward - left);

    }

}
