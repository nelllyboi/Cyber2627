package org.firstinspires.ftc.teamcode.development.teleop.opmodes.test.integration;

import static org.firstinspires.ftc.teamcode.globals.Constants.*;
import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.*;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Shooter;

@TeleOp
@Configurable
@Disabled
@Config
public class ExitVelTest extends LinearOpMode {
    private Shooter shooter;
    private TurretServo turret;
    private DcMotorEx intake;
    private DcMotorEx transfer;
    private Servo ballBlock;
    private double targetRPM = 2500;
    private double targetAngle = 35;
    private boolean flywheelOn = false;
    private boolean intakeOn = false;
    private boolean transferOn = false;
    private boolean ballBlockClosed = false;
    FtcDashboard dashboard = FtcDashboard.getInstance();
    @Override
    public void runOpMode() {

        turret = new TurretServo(hardwareMap);
        shooter = new Shooter(hardwareMap);
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
        ballBlock = hardwareMap.get(Servo.class, "ballBlock");
        turret = new TurretServo(hardwareMap);

        waitForStart();

        while (opModeIsActive()) {
            telemetry.addLine("ZZZ SHOOT SPEED UP/DOWN: DPAD UP/DOWN");
            telemetry.addLine("SHOOT ANGLE UP/DOWN: DPAD LEFT/RIGHT");
            telemetry.addLine("FLYWHEEL ON: A");
            telemetry.addLine("INTAKE ON: B");
            telemetry.addLine("TRANSFER ON: X");
            telemetry.addLine("----------------------------------------");
            telemetry.addData("Current target speed", targetRPM);
            telemetry.addData("Current RPM", shooter.getRPM());
            telemetry.addData("Current hood angle", targetAngle);
            telemetry.addData("Flywheel On", flywheelOn);
            telemetry.addData("Intake On", intakeOn);
            telemetry.addData("Transfer On", transferOn);
            telemetry.update();

            turret.setTargetAngleInDegrees(90);

            if (gamepad1.dpadUpWasPressed()) {
                targetRPM += 50;
            } else if (gamepad1.dpadDownWasPressed()) {
                targetRPM -= 50;
            }

            if (gamepad1.aWasPressed()) {
                flywheelOn = !flywheelOn;
            }

            if (gamepad1.bWasPressed()) {
                intakeOn = !intakeOn;
            }

            if (gamepad1.xWasPressed()) {
                transferOn = !transferOn;
            }

            if (gamepad1.yWasPressed()) {
                ballBlockClosed = !ballBlockClosed;
            }

            if (targetRPM <= 0) {
                targetRPM = 0;
            }

            if (gamepad1.dpadLeftWasPressed()) {
                targetAngle -= 1;
            } else if (gamepad1.dpadRightWasPressed()) {
                targetAngle += 1;
            }

            targetAngle = clamp(targetAngle, Math.toDegrees(HOOD_MAX), Math.toDegrees(HOOD_MIN));

            if (flywheelOn) {
                shooter.setRPM(targetRPM);
            } else {
                shooter.setRPM(0);
            }

            if (transferOn) {
                transfer.setPower(-0.62);
            } else {
                transfer.setPower(0);
            }

            if (intakeOn) {
                intake.setPower(0.8);
            } else {
                intake.setPower(0);
            }

            if (ballBlockClosed) {
                ballBlock.setPosition(0.38);
            } else {
                ballBlock.setPosition(0.21);
            }

            TelemetryPacket packet = new TelemetryPacket();
            packet.put("RPM", shooter.getRPM());
            dashboard.sendTelemetryPacket(packet);
        }
    }
}
