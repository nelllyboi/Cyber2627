package org.firstinspires.ftc.teamcode.development.autonomous.opmodes.prod.far.line;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems.HuskyAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.BallBlockAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.DriveAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.IntakeAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.ShooterAuto;
import org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems.RedTurretAuto;
import org.firstinspires.ftc.teamcode.globals.Globals;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.function.Supplier;

@Disabled
@Autonomous(name = "Red - Far Side LINE", group = "line", preselectTeleOp = "Red Teleop")
public class FarRedLine extends LinearOpMode {

    public static double start_theta = 180;
    private boolean right = false;

    @Override
    public void runOpMode() throws InterruptedException {

        FtcDashboard dashboard = FtcDashboard.getInstance();

        DriveAuto drive = new DriveAuto(hardwareMap, 63, 14, start_theta, false);
        IntakeAuto intake = new IntakeAuto(hardwareMap, true);
        BallBlockAuto ballBlock = new BallBlockAuto(hardwareMap);
        RedTurretAuto turret = new RedTurretAuto(hardwareMap, 63, 14);
        ShooterAuto shooter = new ShooterAuto(hardwareMap, ShooterAuto.ShotMode.FAR);
        HuskyAuto husky = new HuskyAuto(hardwareMap);

        Function<Double, Action> ramp = speed -> new ParallelAction(
                intake.intakeForward(),
                intake.transferForward(),
                ballBlock.blockClose(),
                shooter.setSpeed(speed),
                shooter.flywheelOn(),
                shooter.waitRPM()
        );

//        Function<Boolean, Action> choose = goRight -> (
//                if (goRight) {
//                    drive.toPoint(55, 20, 0),
//                    drive.toPointHalf(57, 57, 0),
//                    drive.toPointBackwards(55, 42, -4),
//                    drive.toPointHalf(57, 57, 0)
//                } else {
//                    drive.toPoint(45, 20, 0),
//                    drive.toPointHalf(47, 57, 0),
//                    drive.toPointBackwards(45, 42, -4),
//                    drive.toPointHalf(47, 57, 0)
//                }
//        );

        Function<Boolean, Action> choose = goRight ->
                goRight ?
                      new SequentialAction(
                            drive.toPoint(55, 20, 0),
                            drive.toPointHalf(57, 57, 0),
                            drive.toPointBackwards(55, 42, -4),
                            drive.toPointHalf(57, 57, 0)
                      ) :
                      new SequentialAction(
                            drive.toPoint(45, 20, 0),
                            drive.toPointHalf(47, 57, 0),
                            drive.toPointBackwards(45, 42, -4),
                            drive.toPointHalf(47, 57, 0)
                      );

        Supplier<Action> shoot = () -> new SequentialAction(
                turret.enableLimelight(),
                new SleepAction(0.35),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockClose(),
                        intake.transferForward()
                ),
                new SleepAction(0.05),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockOpen(),
                        intake.transferForward()
                ),
                new SleepAction(0.05),
                new ParallelAction(
                        intake.intakeForward(),
                        ballBlock.blockOpen(),
                        intake.transferForward()
                ),
                new SleepAction(0.4),
                new ParallelAction(
                        ballBlock.blockClose(),
                        intake.transferOff(),
                        turret.disableLimelight()
                )
        );

        Globals.START_X = 63;
        Globals.START_Y = 14;
        Globals.START_THETA = 180;

        turret.setYOff(72);
        drive.setTimeoutTime(1);

        waitForStart();

        AtomicBoolean running = new AtomicBoolean(true);

        Thread backgroundLoop = new Thread(() -> {
            while ((opModeIsActive() || opModeInInit()) && running.get()) {

                TelemetryPacket packet = new TelemetryPacket();
                double[] rets = drive.odo.retPos();

                packet.put("X", rets[0]);
                packet.put("Y", rets[1]);
                packet.put("T", rets[2]);

                double turretAngle =
                        turret.retLoop(rets[0], rets[1], Math.toDegrees(rets[2]));
                packet.put("angle it thinks its at", turretAngle);

                double dist_x = rets[0] + 72;
                double dist_y = 72 - rets[1];
                double dist = Math.hypot(dist_x, dist_y);
                packet.put("Speed", shooter.retLoop(dist));

                packet.fieldOverlay()
                        .fillRect(rets[0], rets[1], 2, 2);

                Globals.START_X = rets[0];
                Globals.START_Y = rets[1];
                Globals.START_THETA = Math.toDegrees(rets[2]);

                right = husky.readHusky();

                dashboard.sendTelemetryPacket(packet);
            }
        });

        turret.setLlOffDegs(-1.75);
        backgroundLoop.start();

        Actions.runBlocking(
                new SequentialAction(
                        turret.disableLimelight(),
                        ballBlock.blockClose(),
                        new SleepAction(0.35),
                        intake.intakeForward(),
                        new ParallelAction(
                                ramp.apply(3400.0)
                        ),
                        new SleepAction(1),
                        shoot.get(),

                        drive.toPoint(42, 19, 0), // int 3 preset
                        drive.toPoint(37.5, 23.5, 0),
                        drive.toPointThird(31.5, 65.5, 0), // int 3 intake

                        new ParallelAction(
                                ramp.apply(3400.0),
                                drive.toPointBackwards(55, 20, 0)
                        ),
                        new SleepAction(1),
                        shoot.get(),

                        choose.apply(right),

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(55, 20, 0),
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        new SleepAction(1),
                        shoot.get(),

                        intake.intakeForward(),

                        choose.apply(right),

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(57, 20, 0),
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        new SleepAction(1),
                        shoot.get(),

                        intake.intakeForward(),

                        choose.apply(right),

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(57, 20, 0),
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        new SleepAction(1),
                        shoot.get(),

                        intake.intakeForward(),

                        choose.apply(right),

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(57, 20, 0),
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        new SleepAction(1),
                        shoot.get(),

                        intake.intakeForward(),

                        choose.apply(right),

                        new ParallelAction(
                                intake.intakeForward(),
                                drive.toPointBackwards(57, 20, 0),
                                ballBlock.blockClose(),
                                ramp.apply(3400.0)
                        ),
                        new SleepAction(1),
                        shoot.get(),

                        drive.toPoint(57, 60, 0)


                )
        );
    }
}
