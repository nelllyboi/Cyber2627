package org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.ServoImplEx;

public class AgitatorAuto {
    public ServoImplEx agitator;
    public static double AGITATOR_OPEN = 0;
    public static double AGITATOR_CLOSED = 0.3;

    public AgitatorAuto(HardwareMap hardwareMap) {
        agitator = hardwareMap.get(ServoImplEx.class, "agitator");
    }

    public class AgitatorOpen implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            agitator.setPosition(AGITATOR_OPEN);
            return false;
        }
    }

    public class AgitatorClose implements Action {

        @Override
        public boolean run(@NonNull TelemetryPacket telemetryPacket) {
            agitator.setPosition(AGITATOR_CLOSED);
            return false;
        }
    }

    public Action agitatorOpen() { return new AgitatorOpen(); }
    public Action agitatorClose() { return new AgitatorClose(); }
}
