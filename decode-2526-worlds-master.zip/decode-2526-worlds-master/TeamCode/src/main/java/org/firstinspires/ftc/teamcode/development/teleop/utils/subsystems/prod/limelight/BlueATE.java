package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.prod.limelight;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

public class BlueATE {
    private Limelight3A limelight;
    private ElapsedTime poseTimer;
    private Pose2D botPose;
    private boolean inPose = false;

    public BlueATE(HardwareMap hardwareMap, int pipeline) {
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.pipelineSwitch(2);
        limelight.start();
    }

    public Object[] retLoop() {
        LLResult result = limelight.getLatestResult();
        if (!inPose) {
            if (result != null && result.isValid()) {
                double pose = result.getTy();
                return new Object[]{true, pose};
            }
            return new Object[]{false};
        } else {
            if (result != null && result.isValid()) {
                Pose3D pose3d = result.getBotpose();
                Pose2D pose = new Pose2D(DistanceUnit.INCH, pose3d.getPosition().x, pose3d.getPosition().y, AngleUnit.RADIANS, pose3d.getOrientation().getYaw());

                botPose = pose;
            }
            return new Object[]{false};
        }
    }

    public Object[] retLoopMT2() {
        LLResult result = limelight.getLatestResult();
        if (result != null && result.isValid()) {
            Pose3D pose3d = result.getBotpose();
            double angle = result.getTy();
            Pose2d pose = new Pose2d(pose3d.getPosition().x, pose3d.getPosition().y, pose3d.getOrientation().getYaw(AngleUnit.DEGREES));
            return new Object[]{true, angle, pose};
        } else {
            return new Object[]{false};
        }
    }

    public void startBotPose() {
        limelight.pipelineSwitch(4);
        inPose = true;
        poseTimer.reset();
    }

    public Pose2D getBotPose() {
        return botPose;
    }
}
