package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.ballblock;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;

@Configurable
@Config
@TeleOp
@Disabled
public class BallBlockTest extends OpMode {

    public static double BALL_BLOCK_POS = 0.0;

    private Servo ballBlockServo;

    FtcDashboard dashboard = FtcDashboard.getInstance();

    @Override
    public void init() {
        ballBlockServo = hardwareMap.get(Servo.class, "ballBlock");
    }

    @Override
    public void loop() {

        TelemetryPacket packet = new TelemetryPacket();

        ballBlockServo.setPosition(BALL_BLOCK_POS);

        telemetry.addData("Ball Block Position", BALL_BLOCK_POS);
        packet.put("Ball Block Pos", BALL_BLOCK_POS);

        dashboard.sendTelemetryPacket(packet);
        telemetry.update();
    }
}