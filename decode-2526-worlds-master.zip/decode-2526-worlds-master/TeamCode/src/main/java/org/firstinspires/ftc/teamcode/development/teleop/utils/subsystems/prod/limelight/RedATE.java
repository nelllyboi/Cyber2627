package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.prod.limelight;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.robotcore.external.navigation.Position;

import java.util.concurrent.TimeUnit;

public class RedATE {
    private Limelight3A limelight;
    private Pose2D botPose;
    private boolean inPose = false;
    private ElapsedTime poseTimer = new ElapsedTime();
    public RedATE(HardwareMap hardwareMap, int pipeline) {
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.pipelineSwitch(3);
        limelight.start();
    }

    public Object[] retLoop() {
        if (poseTimer.time(TimeUnit.SECONDS) > 3 && inPose) {
            inPose = false;
        }
        LLResult result = limelight.getLatestResult();
        if (!inPose) {
            if (result != null && result.isValid()) {
                double pose = result.getTy();
                return new Object[]{true, pose};
            }
            return new Object[]{false};
        } else {
            if (result != null && result.isValid()) {
                Pose3D pose3d = result.getBotpose();
                botPose = new Pose2D(DistanceUnit.INCH, pose3d.getPosition().x, pose3d.getPosition().y, AngleUnit.RADIANS, pose3d.getOrientation().getYaw());
                return new Object[]{true, botPose};
            } else {
                return new Object[]{false};
            }
        }
    }

    public Object[] retLoop69() {
        LLResult result = limelight.getLatestResult();
        if (result != null && result.isValid()) {
            Pose3D pose3d = result.getBotpose();
            double angle = result.getTy();
            Position pose2d = pose3d.getPosition();
            return new Object[]{true, angle, pose2d.x, pose2d.y};
        } else {
            return new Object[]{false};
        }
    }

    public Object[] retLoopMT1(double imu) {
        limelight.updateRobotOrientation(imu);
        LLResult result = limelight.getLatestResult();
        if (result != null && result.isValid()) {
            Pose3D pose3d = result.getBotpose_MT2();
            double angle = result.getTy();
            Pose2d pose = new Pose2d(pose3d.getPosition().x, pose3d.getPosition().y, pose3d.getOrientation().getYaw(AngleUnit.DEGREES));
            return new Object[]{true, angle, pose};
        } else {
            return new Object[]{false};
        }
    }

    public Object[] retLoopMT1() {
        LLResult result = limelight.getLatestResult();
        if (result != null && result.isValid()) {
            Pose3D pose3d = result.getBotpose();
            double angle = result.getTy();
            Pose2d pose = new Pose2d(pose3d.getPosition().x, pose3d.getPosition().y, pose3d.getOrientation().getYaw(AngleUnit.DEGREES));
            return new Object[]{true, angle, pose};
        } else {
            return new Object[]{false};
        }
    }
}
