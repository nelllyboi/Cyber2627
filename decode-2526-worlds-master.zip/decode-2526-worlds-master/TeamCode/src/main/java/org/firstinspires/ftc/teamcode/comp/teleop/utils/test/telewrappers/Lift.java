package org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers;

import static org.firstinspires.ftc.teamcode.globals.Constants.*;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;

public class Lift {
    private ServoImplEx ptoLeft;
    private ServoImplEx ptoRight;

    public Lift(HardwareMap hardwareMap) {
        ptoLeft = hardwareMap.get(ServoImplEx.class, "ptoLeft");
        ptoRight = hardwareMap.get(ServoImplEx.class, "ptoRight");

        ptoLeft.setPwmRange(new PwmControl.PwmRange(500, 2500));
        ptoRight.setPwmRange(new PwmControl.PwmRange(500, 2500));

        ptoRight.setDirection(Servo.Direction.REVERSE);
        ptoLeft.setDirection(Servo.Direction.FORWARD);
    }

    public void disengageLift() {
        ptoLeft.setPosition(PL_DISENGAGE);
        ptoRight.setPosition(PR_DISENGAGE);
    }

    public void engageLift() {
        ptoLeft.setPosition(PL_ENGAGE);
        ptoRight.setPosition(PR_ENGAGE);
    }

    public void setLeftLiftPos(double pos) {
        ptoLeft.setPosition(pos);
    }

    public void setRightLiftPos(double pos) {
        ptoRight.setPosition(pos);
    }
}
