package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.teamcode.globals.Constants;

public class Transfer {

    DcMotor motor;

    BallBlock ballBlock;
    Constants.TransferState state;

    public Transfer() {

    }

    public void init(HardwareMap hardwareMap) {
        motor = hardwareMap.get(DcMotor.class, Constants.TRANSFER);
        motor.setDirection(DcMotorSimple.Direction.REVERSE);
        ballBlock = new BallBlock();
        ballBlock.init(hardwareMap);
        state = Constants.TransferState.STOP;
    }


    public void openBallBlock() {
        ballBlock.open();
    }

    public void closeBallBlock() {
        ballBlock.close();
    }

    public Constants.BallblockState getBallBlockState() { return ballBlock.getState();}

    public Constants.TransferState getState() {return state;}

    public void runTransfer(Constants.TransferState transferState) {
        if (transferState == Constants.TransferState.FORWARD) {
            forward();
        } else if (transferState == Constants.TransferState.BACKWARD) {
            backward();
        } else if (transferState == Constants.TransferState.STOP){
            stop();
        }
    }

    public void forward() {
        state = Constants.TransferState.FORWARD;
        motor.setPower(1);
    }

    public void backward() {
        state = Constants.TransferState.BACKWARD;
        motor.setPower(-1);
    }

    public void stop() {
        state = Constants.TransferState.STOP;
        motor.setPower(0);
    }




}
