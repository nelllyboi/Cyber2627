package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.lift;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Lift;

@TeleOp
@Configurable
@Disabled

public class PTOTest extends LinearOpMode {
    private Lift pto;
    private DcMotor left1;
    private DcMotor left2;
    private DcMotor right1;
    private DcMotor right2;
    @Override
    public void runOpMode() {

        pto = new Lift(hardwareMap);

        left1 = hardwareMap.get(DcMotor.class, "left1");
        left2 = hardwareMap.get(DcMotor.class, "left2");
        right1 = hardwareMap.get(DcMotor.class, "right1");
        right2 = hardwareMap.get(DcMotor.class, "right2");

        right1.setDirection(DcMotorSimple.Direction.REVERSE);
        waitForStart();

        while (opModeIsActive()) {
            double pwr = gamepad1.left_stick_y;
            left1.setPower(pwr);
            left2.setPower(pwr);
            right1.setPower(pwr);
            right2.setPower(pwr);

            if (gamepad1.b) {
                pto.disengageLift();
            } else if (gamepad1.a) {
                pto.engageLift();
            }



        }
    }
}
