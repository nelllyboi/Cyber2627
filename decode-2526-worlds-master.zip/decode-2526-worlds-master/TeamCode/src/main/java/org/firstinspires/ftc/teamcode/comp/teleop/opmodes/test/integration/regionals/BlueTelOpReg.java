/* Copyright (c) 2017 FIRST. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided that
 * the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 * of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of FIRST nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
 * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.regionals;

import static org.firstinspires.ftc.teamcode.globals.Constants.HOOD_MAX;
import static org.firstinspires.ftc.teamcode.globals.Constants.HOOD_MIN;
import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.clamp;
import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.regressBlue;
import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.velToRPM;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.RobotLog;

import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.DriveTrain;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Imu;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Intake;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.Transfer;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;
import org.firstinspires.ftc.teamcode.development.teleop.utils.localizers.OdometryDaemon;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.prod.limelight.BlueATE;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers.Shooter;

@TeleOp(name="TeleOpReg: Blue", group="TeleOpReg")
@Disabled
@Configurable
public class BlueTelOpReg extends LinearOpMode {


    /**
     * Teleop Timers
     */
    private ElapsedTime shootSequenceTimer = new ElapsedTime();
    public static double kP = 0.12;


    /**
     * Turret Variables
     */

    private double odo_turret_angle;
    private double normalized_odo_turret_angle;

    private double calculatedRPM;

    public BlueATE blueATE;
    public OdometryDaemon odo;
    Constants.IntakeState intakeState = Constants.IntakeState.STOP;
    Constants.ShootSequence shootSequence = Constants.ShootSequence.IDLE;

    boolean flywheelOn;

    @Override
    public void runOpMode() {

        // TODO: Adjust the x and y parameters
        odo = new OdometryDaemon(hardwareMap, 39, 33, 0, true);

        /**
         * Drivetrain Initializtions
         */
        DriveTrain driveTrain = new DriveTrain();
        driveTrain.init(hardwareMap);

        // TODO:
        blueATE = new BlueATE(hardwareMap, 67);

        // TODO:
        boolean enableDrive = true;

        /**
         * Intake Initializtions
         */
        Intake intake = new Intake();
        intake.init(hardwareMap);


        /**
         * Transfer Initializations
         */
        Transfer transfer = new Transfer();
        transfer.init(hardwareMap);

        /**
         * Shooter Initializations
         */
        Shooter shooter = new Shooter(hardwareMap);
        double rpmOffset = 50;

        boolean regressionActive = true;
        flywheelOn = false;



        /**
         * Turret Initializations
         */
        TurretServo turret = new TurretServo(hardwareMap);
        // TODO: Check
        double turretOffset = -2;


        /**
         * Limelight Initializations are in drive init
         */

        // TODO: Check Limelight initializations
//        Limelight3A limelight;
//
//        limelight = hardwareMap.get(Limelight3A.class, "limelight");
//        limelight.setPollRateHz(100); // This sets how often we ask Limelight for data (100 times per second)
//        limelight.start(); // This tells Limelight to start looking!
//
//
//        ArrayList<Double> limelightOffsets = new ArrayList<Double>();

        // Comparing the Imu from Control hub to Imu on GoBilda Odo
        Imu imu = new Imu();
        imu.init(hardwareMap);



//        /**
//         * Lift Initializations
//         */
//        Lift lift = new Lift();
//        lift.init(hardwareMap);



        /**
         * Telemetry Initializtions
         */

        ElapsedTime runtime = new ElapsedTime();
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        telemetry.addData("Status", "Initialized");
//        telemetry.addData("Estimated angle", odo_turret_angle);
        telemetry.update();



        // Wait for the game to start (driver presses START)
        waitForStart();
        runtime.reset();

        // runIntake until the end of the match (driver presses STOP)
        while (opModeIsActive() && !isStopRequested()) {
            // Show the elapsed game time.
            telemetry.addData("Status", "Run Time: " + runtime);

            /**
             * Drivetrain Commands
             */

            // TODO: Check
            if (shootSequence == Constants.ShootSequence.IDLE && enableDrive) {
                driveTrain.run(-gamepad1.right_stick_y, 0.7 * gamepad1.left_stick_x, telemetry);
            } else {
                driveTrain.run(0, 0, telemetry);
            }

            // TODO: Check retPos vs retPosTeleOp()
            double[] ritz = odo.retPosTeleOp();
            double x = ritz[0];
            double y = ritz[1];
            double theta = ritz[2];


            /**
             * Odo Commands
             */
            telemetry.addData("Odometry ", "X = %.3f, Y = %.3f, Angle = %.3f",
                                        x, y, theta);
            telemetry.addData("Rev Hub IMU:", imu.currAngle());

            if (gamepad1.psWasPressed()) {
                odo.odo.resetPosAndIMU();
                odo.start_x = 63;
                odo.start_y = 64;
            }


            /**
             * Intake Commands
             */

            if (gamepad1.squareWasPressed()) {
                intake.forward();
            } else if (gamepad1.circleWasPressed()) {
                intake.backward();
            }

            if (gamepad1.crossWasPressed()) {
                regressionActive = !regressionActive;
            }


            /**
             * Lift Commands
             */
            // TODO: Check lift operation
//            if (gamepad1.triangleWasPressed()) {
//                if (lift.isEngaged()) {
//                    lift.liftDisengage();
//                    // TODO: Check
////                    shooter.setIdlePower(0.6);
//                    enableDrive = true;
//                } else {
//                    lift.liftEngage();
//                    // TODO: Check
////                    shooter.setIdlePower(0);
//                    enableDrive = false;
//                    intakeState = Constants.IntakeState.STOP;
//                }
//
//            }

            /**
             * Transfer Commands
             */

            //No Commands


            /**
             * Limelight Commands
             */


            // TODO: Check limelight code
//            LLResult limelightresults = limelight.getLatestResult();
//            double tx = -100;
//            if (limelightresults != null && limelightresults.isValid()) {
//                Pose3D botpose = limelightresults.getBotpose();
//                if (botpose != null) {
//                    double mt1_x = botpose.getPosition().x;
//                    double mt1_y = botpose.getPosition().y;
////                    telemetry.addData("MT1 Location", "(" + mt1_x + ", " + mt1_y + ")");
//                    telemetry.addData("LL Pose", "x=%.2f y=%.2f ", mt1_x, mt1_y);
//                }
//
//                tx = limelightresults.getTx();
//
//            }



            /**
             * Turret Commands
             */

            // TODO: Check the turret with the ShootOnMove
            odo_turret_angle = 180 + turret.calculateTurretAngle(x,
                    y, 72, -72,
                    theta);

            normalized_odo_turret_angle = TurretServo.normalizeDegrees(odo_turret_angle);


            if (gamepad1.dpadLeftWasPressed()) {
                turretOffset += 2;
                gamepad1.rumble(300);
            } else if (gamepad1.dpadRightWasPressed()) {
                turretOffset -= 2;
                gamepad1.rumble(300);
            }

            double[] shootRets = Shooter.calculateShotVectorNoVelBlue(x, y);
            double targetRPM = velToRPM(shootRets[1]);
            double hoodAngle = clamp(90 - Math.toDegrees(shootRets[0]), Math.toDegrees(HOOD_MAX), Math.toDegrees(HOOD_MIN));

            /**
             * Shooter Sequence
             */

            if (gamepad1.rightBumperWasPressed() && shootSequence == Constants.ShootSequence.IDLE) {
                turret.setTargetAngleInDegrees(normalized_odo_turret_angle +  turretOffset);
                flywheelOn = true;
                transfer.closeBallBlock();
                intake.forward();
                transfer.forward();

                shootSequence = Constants.ShootSequence.SPIN_UP;
                shootSequenceTimer.reset();
            }


            // TODO: Check the shooter.atSpeed
            if (shootSequence == Constants.ShootSequence.SPIN_UP &&
//                    (shootSequenceTimer.milliseconds() > 2000) &&
                    shooter.isAtSpeed(targetRPM)) {
                transfer.openBallBlock();
                shootSequence = Constants.ShootSequence.SHOOTING;
                RobotLog.vv("AstroBot", "Shootsequence set to %s, Timer %.3f", shootSequence, shootSequenceTimer.milliseconds());
                shootSequenceTimer.reset();
//                limelightOffsets.add(tx - turretOffset);
            } else if (shootSequence == Constants.ShootSequence.SHOOTING && shootSequenceTimer.milliseconds() > 350) {
                intake.forward();
                transfer.closeBallBlock();
                transfer.stop();
                shootSequence = Constants.ShootSequence.IDLE;
                flywheelOn = false;
                RobotLog.vv("AstroBot", "Shootsequence set to %s, Timer %.3f", shootSequence, shootSequenceTimer.milliseconds());
            }

            if (shootSequence == Constants.ShootSequence.IDLE){
                turret.setTargetAngleInDegrees(normalized_odo_turret_angle + turretOffset);
            }

            /**
             * Shooter Commands
             */

            if (shootSequence == Constants.ShootSequence.SPIN_UP) {
                Object[] rets = blueATE.retLoop();
                double errorInDegs = 0;
                if ((boolean) rets[0]) {
                    errorInDegs = (double) rets[1];
                    errorInDegs -= turretOffset;
                }
                double angle = turret.getTargetAngle() - errorInDegs * kP;
                angle = TurretServo.normalizeDegrees(angle);
                turret.setTargetAngleInDegrees(angle);
            }

            if (gamepad1.dpadUpWasPressed()) {
                rpmOffset += 50;
                gamepad1.rumble(300);
            } else if (gamepad1.dpadDownWasPressed()) {
                rpmOffset -= 50;
                gamepad1.rumble(300);
            }

            // TODO: Check
//            shooter.retLoop();

            if (regressionActive) {
                calculatedRPM = regressBlue(-x, -y);
            } else {
                calculatedRPM = 2800;
            }

            // TODO: Check
//            shooter.setSpeedTeleop(calculatedRPM + rpmOffset);


            if (runtime.seconds() > 150) {
                RobotLog.vv("AstroBot", "Stopping: Runtime %.2f over 150 seconds", runtime.milliseconds());
                requestOpModeStop();
            }

            if (flywheelOn) {
                shooter.setRPM(targetRPM);
            } else {
                shooter.setRPM(0);
            }

            /**
             * Telemetry Commands
             */
            telemetry.addLine("□-Square / X Intake Forward");
            telemetry.addLine("○-Circle / B Intake Backward");
            telemetry.addLine("△-Triangle / Y Park Automation");
            telemetry.addLine("X-Cross / A Toggle Regression");
            telemetry.addLine("SHOOT SPEED UP/DOWN: DPAD UP/DOWN");
            telemetry.addLine("SHOOT ANGLE UP/DOWN: DPAD LEFT/RIGHT");
            telemetry.addLine("START SHOOT SEQUENCE: Right Bumper");
            telemetry.addLine("----------------------------------------");


            telemetry.addData("Hood Angle", hoodAngle);
            telemetry.addData("Flywheel On", flywheelOn);
            telemetry.addData("Flywheel target speed", targetRPM);
            telemetry.addData("Flywheel current RPM", shooter.getRPM());
            telemetry.addData("Flywheel at Speed", shooter.isAtSpeed(targetRPM));

            telemetry.addData("Shooter Stage", shootSequence);
            telemetry.addData("BallBlock", transfer.getBallBlockState());
            telemetry.addData("Intake", intake.getState());
            telemetry.addData("Transfer", transfer.getState());

            telemetry.addData("Regression active", regressionActive);
            telemetry.addData("Estimated angle", odo_turret_angle);
            telemetry.addData("Normalized Turret Angle", normalized_odo_turret_angle);
            telemetry.addData("Turret offset", turretOffset);
            telemetry.addData("RPM offset", rpmOffset);
            telemetry.addData("Flywheel target RPM", calculatedRPM+rpmOffset);
            telemetry.addData("Curr RPM", shooter.getRPM());
//            telemetry.addData("Limelight offsets", limelightOffsets);
            telemetry.update();
        }

    }
}
