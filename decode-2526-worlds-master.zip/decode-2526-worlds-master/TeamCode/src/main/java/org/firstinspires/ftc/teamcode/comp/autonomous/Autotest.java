package org.firstinspires.ftc.teamcode.comp.autonomous;

import android.net.wifi.WifiManager;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

import org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems.NewDriveAuto;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.localizers.LocalizerTurret;

@Disabled
@Autonomous
public class Autotest extends LinearOpMode {

    @Override
    public void runOpMode() {

        LocalizerTurret localizer = new LocalizerTurret(hardwareMap);

        telemetry.addLine("Initialized. Waiting for start...");
        telemetry.update();

        waitForStart();

        localizer.setStartPose(10, -2, 0);

        sleep(500);

        while (opModeIsActive()) {
            localizer.update(telemetry, 24, true);
            Pose2D pose = localizer.pinpoint.getPosition();

            telemetry.addData("x (in)", pose.getX(DistanceUnit.INCH));
            telemetry.addData("y (in)", pose.getY(DistanceUnit.INCH));
            telemetry.addData("heading (deg)", pose.getHeading(AngleUnit.DEGREES));


            telemetry.update();
        }
    }
}