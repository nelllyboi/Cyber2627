package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.partial.turret;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test.TurretServo;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.prod.limelight.RedATE;

@TeleOp(group = "test", name = "Turret + Limelight - Test Red Side")
@Disabled

@Configurable
public class TurretLimelightTest extends LinearOpMode {

    TurretServo turretServo;
    RedATE redATE;
    public static double kP = 0.01;
    public boolean aPressed = false;

    @Override
    public void runOpMode() {
        turretServo = new TurretServo(hardwareMap);
        redATE = new RedATE(hardwareMap, 1);
        waitForStart();

        while (opModeIsActive()) {
            Object[] rets = redATE.retLoop();
            if ((boolean) rets[0]) {
                double errorInDegs = (double) rets[1];
                turretServo.runToPosition(turretServo.getCurrentAngle() - errorInDegs * kP);
                telemetry.addData("Error", errorInDegs);
                telemetry.addData("Current Pos", turretServo.getCurrentAngle());
                telemetry.addData("Target Pos", turretServo.getCurrentAngle() - errorInDegs * kP);
            } else {
                telemetry.addLine("No Image Found!");
            }
            telemetry.update();
        }

    }
}
