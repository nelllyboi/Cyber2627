package org.firstinspires.ftc.teamcode.comp.teleop.utils.prod;

import android.util.Log;

public class MathFunctions {
    public static double map(double val, double first_min, double first_max, double second_min, double second_max) {
        return (val - first_min) * (second_max - second_min) / (first_max - first_min) + second_min;
    }

    public static double oppositeAngle(double angle_rad) {
        double result = angle_rad + Math.PI;
        result %= 2 * Math.PI;
        if (result < 0) result += 2 * Math.PI;
        return result;
    }

    public static Object[] special_wrap(double theta, double upper, double pastAngle) {
        double og_theta = theta - 180;
        if (theta < 0) {
            while (theta < upper - 360) {
                theta += 360;
            }
        } else {
            while (theta > upper) {
                theta -= 360;
            }
        }
        upper = upper - 180;

        if (to_right_of(upper, pastAngle) && og_theta < upper + 10 && og_theta > upper) {
            Log.e("WRAP ZONE: ", "WRAPPED RIGHT PROTECTION!");
            return new Object[] {0.0, og_theta + 360};
        } else if (to_left_of(upper, pastAngle) && og_theta > upper - 10 && og_theta < upper) {
            Log.e("WRAP ZONE: ", "WRAPPED LEFT PROTECTION!");
            return new Object[] {0.0, og_theta + 360};
        } else if (to_right_of(upper, pastAngle) && og_theta > upper + 10) {
            Log.e("WRAP: ", "WRAPPED RIGHT");
            return new Object[] {2.0, theta};
        } else if (to_left_of(upper, pastAngle) && og_theta < upper -10) {
            Log.e("WRAP: ", "WRAPPED LEFT");
            return new Object[] {1.0, theta};
        }
        return new Object[] {0.0, theta};
    }

    public static double get_sign(double num) {
        if (num >= 0) {
            return 1;
        } else {
            return -1;
        }
    }

    public static double angle_wrap(double theta){
        while (theta < -Math.PI) {
            theta += 2 * Math.PI;
        }
        while (theta > Math.PI) {
            theta -= 2 * Math.PI;
        }
        return theta;
    }

    public static double special_wrap(double theta) {
        while (theta < -90) {
            theta += 360;
        }
        while (theta > 270) {
            theta -= 360;
        }
        return theta;
    }

    public static double opposite_angle(double theta) {
        double result = theta + 180;
        result %= 360;
        if (result < 0) result += 360;
        return result;
    }

    public static boolean to_right_of(double ref, double theta) {
        if (ref < 180) {
            if (theta < 180) {
                if (theta < ref) {
                    return true;
                }
            } else {
                if (theta > MathFunctions.opposite_angle(ref)) {
                    return true;
                }
            }
        } else {
            if (theta < 180) {
                if (theta < MathFunctions.opposite_angle(ref)) {
                    return true;
                }
            } else {
                if (theta > ref) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean to_left_of(double ref, double theta) {
        return !(to_right_of(ref, theta));
    }

    public static double ninety_to_right(double theta) {
        if (theta >= 90) {
            return theta - 90;
        } else {
            return 270 + theta;
        }
    }

    public static double unnormalize(double theta) {
        double result = (270.0 - theta) % 360.0;
        if (result < 0) {
            result += 360.0;
        }
        return opposite_angle(result);
    }

    public static double regressRedOldV3(double x, double y) {
        return 2770.0039722882866
                + 10.582708959477092 * x
                - 6.853056435282341 * y
                + 0.08759674757419815 * x * x
                - 0.018484932575068426 * x * y
                + 0.0732897006813087 * y * y
                - 0.0008894925277900256 * x * x * x
                + 0.00047683388422886663 * x * x * y
                - 0.00048764347100149763 * x * y * y
                - 0.0006115667588452167 * y * y * y;
    }

    public static double[] to_goal_relative(double x, double y, double xg, double yg) {
        double xRel = x - xg;
        double yRel = y - yg;
        return new double[]{xRel, yRel};
    }

    public static double regressRedIdle(double x, double y) {
        return 2489.222527544776
                + 8.304209184718703 * x
                - 8.914313949734725 * y
                + 0.07387776714332475 * x * x
                - 0.006367024373586407 * x * y
                + 0.05228021948035562 * y * y
                - 0.0007076827083487558 * x * x * x
                + 0.0008081428114874445 * x * x * y
                - 0.0006088448493186682 * x * y * y
                + 0.0007520208252668192 * y * y * y;
    }

    public static double regressBlueOldV3(double x, double y) {
        y = -y;
        return 2770.0039722882866
                + 10.582708959477092 * x
                - 6.853056435282341 * y
                + 0.08759674757419815 * x * x
                - 0.018484932575068426 * x * y
                + 0.0732897006813087 * y * y
                - 0.0008894925277900256 * x * x * x
                + 0.00047683388422886663 * x * x * y
                - 0.00048764347100149763 * x * y * y
                - 0.0006115667588452167 * y * y * y;
    }

    public static double regressBlueIdle(double x, double y) {
        y = -y;
        return 2489.222527544776
                + 8.304209184718703 * x
                - 8.914313949734725 * y
                + 0.07387776714332475 * x * x
                - 0.006367024373586407 * x * y
                + 0.05228021948035562 * y * y
                - 0.0007076827083487558 * x * x * x
                + 0.0008081428114874445 * x * x * y
                - 0.0006088448493186682 * x * y * y
                + 0.0007520208252668192 * y * y * y;
    }

    public static double regressRed(double x, double y) {
        return 2952.3071089469518
                + 5.963400550303382 * x
                - 4.163895509387233 * y
                + 0.08007218644523494 * x * x
                - 0.06368321132998339 * x * y
                + 0.0665786641192862 * y * y
                - 0.00026026347129048943 * x * x * x
                + 0.002494445742779239 * x * x * y
                - 0.0017427897859807473 * x * y * y
                - 0.0011091793178158449 * y * y * y;
    }

    public static double regressBlue(double x, double y) {
        y = -y;
        return 2952.3071089469518
                + 5.963400550303382 * x
                - 4.163895509387233 * y
                + 0.08007218644523494 * x * x
                - 0.06368321132998339 * x * y
                + 0.0665786641192862 * y * y
                - 0.00026026347129048943 * x * x * x
                + 0.002494445742779239 * x * x * y
                - 0.0017427897859807473 * x * y * y
                - 0.0011091793178158449 * y * y * y;
    }

    //x hood angle, y exit velocity
    public static double hoodAndVelToRPM(double x, double y) {
        return 56636.91959829678
                - 65.82725899766059 * x
                - 404.0412634054457 * y
                + 42.157124578226075 * x * x
                - 11.369479639309052 * x * y
                + 1.551384354640561 * y * y;
    }
    public static double velToRPMv1(double vel) {
        return 10.97967 * vel - 458.71607;
    }

    public static double velToRPMv2(double vel) {
        return 14.30994 * vel + 291.11272;
    }

    public static double velToRPM(double vel) {
        return 18.54815 * vel - 592.53415;
    }

    public static double cubic_control(double forward) {
        return 0.78125 * Math.pow(forward, 3) + 0.21875 * forward;
    }

    public static double clamp(double val, double max, double min) {
        return Math.max(min, Math.min(max, val));
    }

}
