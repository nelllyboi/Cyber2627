package org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.flywheel;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;

@Configurable
public class FlywheelPIDF {

    private static final double MAX_INTEGRAL_SUM = 100;
    public double wheelRad;
    private DcMotorEx flywheel;
    private DcMotorEx flywheel2;

    private ElapsedTime timer = new ElapsedTime();

    // PID state
    private double lastError = 0;
    private double integralSum = 0;

    // Feedforward state
    private double lastReferenceRPM = 0;

    // PID gains
    public static double kP = 0.4;
    public static double kI = 0.0;
    public static double kD = 0.0;

    // Feedforward gains
    public static double kS = 0.0869777521;     // static friction (power)
    public static double kV = 0.000178;  // velocity feedforward (power / RPM) //0.00017271
    public static double kA = 10; // acceleration feedforward (power / RPM/s) //10

    public FlywheelPIDF(HardwareMap hardwareMap, DcMotorEx motor, DcMotorEx motor2) {
        flywheel = motor;
        flywheel2 = motor2;



        flywheel.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        flywheel2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
    }

    public FlywheelPIDF(DcMotorEx motor, DcMotorEx motor2) {
        flywheel = motor;
        flywheel2 = motor2;

        flywheel.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        flywheel2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
    }

    private double sign(double x) {
        if (x > 0) return 1.0;
        if (x < 0) return -1.0;
        return 0.0;
    }

    public double controller(double referenceRPM, double currentRPM) {
        double dt = timer.seconds();
        timer.reset();

        if (dt <= 0) {
            dt = 1e-3;
        }

        double error = referenceRPM - currentRPM;

        integralSum += error * dt;
        integralSum = Math.max(-MAX_INTEGRAL_SUM, Math.min(MAX_INTEGRAL_SUM, integralSum));

        double derivative = (error - lastError) / dt;
        lastError = error;

        double pid = (kP * error) + (kI * integralSum) + (kD * derivative);

        double ksTerm = (referenceRPM != 0) ? kS * sign(referenceRPM) : 0;
        double kvTerm = kV * referenceRPM;

        double referenceAccel = referenceRPM - lastReferenceRPM;
        lastReferenceRPM = referenceRPM;

        double kaTerm = kA * referenceAccel;

        return pid + ksTerm + kvTerm + kaTerm;
    }

    public void setPower(double power) {
        flywheel.setPower(power);
        flywheel2.setPower(power);
    }

    public double getCurrent() {
        return (flywheel.getCurrent(CurrentUnit.AMPS)
                + flywheel2.getCurrent(CurrentUnit.AMPS)) / 2.0;
    }

    public double getRPM() {
        double velocityTicksPerSecond = -flywheel.getVelocity();
        return (velocityTicksPerSecond / 28.0) * 60.0;
    }

    public double eVelToRPM(double eVel) {
        return eVel / wheelRad;
    }
}
