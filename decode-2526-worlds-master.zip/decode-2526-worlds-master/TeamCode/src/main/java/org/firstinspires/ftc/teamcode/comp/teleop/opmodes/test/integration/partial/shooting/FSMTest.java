package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.partial.shooting;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.flywheel.FlywheelPIDF;

@TeleOp(name = "Updated FSM Test")
@Disabled

public class FSMTest extends LinearOpMode {
    public DcMotorEx flywheel;
    public DcMotorEx flywheel2;
    public DcMotorEx intake;
    public DcMotorEx transfer;
    public ServoImplEx ballBlock;
    private boolean flywheelOn = false;

    // Shooter
    private FlywheelPIDF flywheelPID;
    private double targetRPM = 1000;

    // Button debounce
    private boolean yPressed = false;
    private boolean dPadUp = false;
    private boolean dPadDown = false;
    private boolean aPressed = false;

    public enum IntakeState {
        INTAKE_ON_BLOCK_OUT_TRANSFER_OFF,
        INTAKE_ON_BLOCK_IN_TRANSFER_ON
    }

    private IntakeState currentState = IntakeState.INTAKE_ON_BLOCK_OUT_TRANSFER_OFF;

    @Override
    public void runOpMode() {
        double power = 0;

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());

        flywheel = hardwareMap.get(DcMotorEx.class, "flywheel");
        flywheel2 = hardwareMap.get(DcMotorEx.class, "flywheel2");
        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
        ballBlock = hardwareMap.get(ServoImplEx.class, "ballBlock");

        flywheel.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        flywheel2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        flywheel.setDirection(DcMotorSimple.Direction.FORWARD);
        flywheel2.setDirection(DcMotorSimple.Direction.FORWARD);

        flywheel.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        flywheel2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        ballBlock.setPwmRange(new PwmControl.PwmRange(500, 2500));

        flywheelPID = new FlywheelPIDF(hardwareMap, flywheel, flywheel2);

        waitForStart();

        while (opModeIsActive()) {
            double currentRPM = flywheelPID.getRPM();
            if (gamepad1.dpad_up && !dPadUp) {
                targetRPM += 100;
                dPadUp = true;
            } else if (!gamepad1.dpad_up) {
                dPadUp = false;
            }

            if (gamepad1.dpad_down && !dPadDown) {
                targetRPM -= 100;
                dPadDown = true;
            } else if (!gamepad1.dpad_down) {
                dPadDown = false;
            }

            if (gamepad1.y && !yPressed) {
                yPressed = true;

                switch (currentState) {
                    case INTAKE_ON_BLOCK_OUT_TRANSFER_OFF:
                        currentState = IntakeState.INTAKE_ON_BLOCK_IN_TRANSFER_ON;
                        break;

                    case INTAKE_ON_BLOCK_IN_TRANSFER_ON:
                        currentState = IntakeState.INTAKE_ON_BLOCK_OUT_TRANSFER_OFF;
                        break;
                }
            }

            if (!gamepad1.y) {
                yPressed = false;
            }

            if (gamepad1.a) {
                if (!aPressed) {
                    flywheelOn = !flywheelOn;
                    aPressed = true;
                }
            } else {
                aPressed = false;
            }


            if (flywheelOn) {
                power = flywheelPID.controller(targetRPM, currentRPM);
                power = Math.max(0, Math.min(1, power));
                flywheelPID.setPower(power);
            } else {
                flywheelPID.setPower(0);
            }

            switch (currentState) {
                case INTAKE_ON_BLOCK_OUT_TRANSFER_OFF:
                    intake.setPower(1);
                    transfer.setPower(0);
                    ballBlock.setPosition(0.38);
                    break;

                case INTAKE_ON_BLOCK_IN_TRANSFER_ON:
                    intake.setPower(power);
                    transfer.setPower(1);
                    ballBlock.setPosition(0.21);
                    break;
            }

            telemetry.addData("State", currentState);
            telemetry.addData("Target RPM", targetRPM);
            telemetry.addData("Current RPM", currentRPM);
            telemetry.update();
        }
    }
}