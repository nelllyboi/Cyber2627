package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.teamcode.globals.Constants;


//@Config
public class Intake{

    DcMotor intakeMotor;

    Constants.IntakeState state;

    public Intake() {

    }

    public Constants.IntakeState getState() {
        return state;
    }

    public void init(HardwareMap hardwareMap) {
        intakeMotor = hardwareMap.get(DcMotor.class, Constants.INTAKE);
        intakeMotor.setMode((DcMotor.RunMode.RUN_WITHOUT_ENCODER));
        intakeMotor.setDirection(DcMotorSimple.Direction.FORWARD);
        state = Constants.IntakeState.STOP;
    }

    public void setIntake(Constants.IntakeState intakeState) {
        if (intakeState == Constants.IntakeState.FORWARD) {
            forward();
        } else if (intakeState == Constants.IntakeState.BACKWARD) {
            backward();
        } else if (intakeState == Constants.IntakeState.STOP) {
            stop();
        }
    }

    public void stop() {
        state = Constants.IntakeState.STOP;
        intakeMotor.setPower(0);
    }

    public void forward() {
        state = Constants.IntakeState.FORWARD;
        intakeMotor.setPower(1);
    }

    public void backward() {
        state = Constants.IntakeState.BACKWARD;
        intakeMotor.setPower(-1);
    }
    public void wipeRight() {
        return;
    }

    public void wipeRightreset() {
        return;
    }

    public void wipeLeft() { return; }

    public void wipeLeftreset() {
        return;
    }






}
