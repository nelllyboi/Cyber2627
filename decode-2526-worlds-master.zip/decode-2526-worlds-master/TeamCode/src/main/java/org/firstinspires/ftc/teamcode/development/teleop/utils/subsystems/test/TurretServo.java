package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test;

import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.special_wrap;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions;

public class TurretServo {
    ServoImplEx axon_rf, axon_rr;
    public double lastWrapped = 270;
    public TurretServo(HardwareMap hardwareMap) {
        axon_rf = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_RIGHT_FRONT);
        axon_rr = hardwareMap.get(ServoImplEx.class, Constants.TURRET_SERVO_RIGHT_REAR);

        axon_rf.setDirection(Servo.Direction.REVERSE);
        axon_rr.setDirection(Servo.Direction.REVERSE);

        axon_rf.setPwmRange(new PwmControl.PwmRange(Constants.TURRET_SERVO_RF_PWM_MIN, Constants.TURRET_SERVO_RF_PWM_MAX));
        axon_rr.setPwmRange(new PwmControl.PwmRange(Constants.TURRET_SERVO_RR_PWM_MIN, Constants.TURRET_SERVO_RR_PWM_MAX));

        axon_rf.setPosition(Constants.TURRET_SERVO_RIGHT_FRONT_INIT);
        axon_rr.setPosition(Constants.TURRET_SERVO_RIGHT_REAR_INIT);

//        try {
//            Thread.sleep(50);
//        } catch (InterruptedException ignored) {
//        }

    }

    public void setPosition(double pos) {
        axon_rf.setPosition(pos);
        axon_rr.setPosition(pos);
    }

    public void changeWrappedLeft() {
        if (lastWrapped == 270) {
            lastWrapped = 260;
        } else if (lastWrapped == 280) {
            lastWrapped = 270;
        } else if (lastWrapped == 260) {
            lastWrapped = 280;
        }
    }

    public void changeWrappedRight() {
        if (lastWrapped == 270) {
            lastWrapped = 280;
        } else if (lastWrapped == 260) {
            lastWrapped = 270;
        } else if (lastWrapped == 280) {
            lastWrapped = 260;
        }
    }

    public void runToPosition(double angleInDegrees) {
        angleInDegrees = MathFunctions.opposite_angle(angleInDegrees);
//        Object[] rets = MathFunctions.special_wrap(angleInDegrees, lastWrapped, getCurrentAngle());
//        if ((double) rets[0] == 1.0) {
//            changeWrappedLeft();
//        } else if ((double) rets[0] == 2.0) {
//            changeWrappedRight();
//        }
        angleInDegrees = special_wrap(angleInDegrees);
        axon_rf.setPosition(MathFunctions.map(angleInDegrees,
                Constants.TURRET_ANGLE_MIN,
                Constants.TURRET_ANGLE_MAX,
                Constants.TURRET_SERVO_RIGHT_FRONT_MIN,
                Constants.TURRET_SERVO_RIGHT_FRONT_MAX));
        axon_rr.setPosition(MathFunctions.map(angleInDegrees,
                Constants.TURRET_ANGLE_MIN,
                Constants.TURRET_ANGLE_MAX,
                Constants.TURRET_SERVO_RIGHT_REAR_MIN,
                Constants.TURRET_SERVO_RIGHT_REAR_MAX));
    }

    public double getCurrentAngle() {
        return MathFunctions.opposite_angle(MathFunctions.map(axon_rf.getPosition(),
                Constants.TURRET_SERVO_RIGHT_FRONT_MIN,
                Constants.TURRET_SERVO_RIGHT_FRONT_MAX,
                Constants.TURRET_ANGLE_MIN,
                Constants.TURRET_ANGLE_MAX));
    }

    public void setTargetInit() {
        axon_rf.setPosition(Constants.TURRET_SERVO_RIGHT_FRONT_INIT);
        axon_rr.setPosition(Constants.TURRET_SERVO_RIGHT_REAR_INIT);
    }
    public void setTargetMin() {
        axon_rf.setPosition(Constants.TURRET_SERVO_RIGHT_FRONT_MIN);
        axon_rr.setPosition(Constants.TURRET_SERVO_RIGHT_REAR_MIN);
    }

    public void setTargetMax() {
        axon_rf.setPosition(Constants.TURRET_SERVO_RIGHT_FRONT_MAX);
        axon_rr.setPosition(Constants.TURRET_SERVO_RIGHT_REAR_MAX);
    }

}
