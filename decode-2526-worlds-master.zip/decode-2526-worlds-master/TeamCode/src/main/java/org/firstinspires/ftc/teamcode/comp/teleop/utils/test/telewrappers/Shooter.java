package org.firstinspires.ftc.teamcode.comp.teleop.utils.test.telewrappers;

import static org.firstinspires.ftc.teamcode.globals.Constants.GOAL_POS_RED;
import static org.firstinspires.ftc.teamcode.globals.Constants.GOAL_POS_BLUE;
import static org.firstinspires.ftc.teamcode.globals.Constants.HOOD_MAX;
import static org.firstinspires.ftc.teamcode.globals.Constants.HOOD_MIN;
import static org.firstinspires.ftc.teamcode.globals.Constants.PASS_THROUGH_POINT_RADIUS;
import static org.firstinspires.ftc.teamcode.globals.Constants.PASS_THROUGH_POINT_RADIUS_FAR;
import static org.firstinspires.ftc.teamcode.globals.Constants.SCORE_HEIGHT;
import static org.firstinspires.ftc.teamcode.globals.Constants.SCORE_HEIGHT_FAR;
import static org.firstinspires.ftc.teamcode.globals.Constants.SCORE_ANGLE;
import static org.firstinspires.ftc.teamcode.globals.Constants.SCORE_ANGLE_FAR;
import static org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions.map;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.flywheel.FlywheelPIDF;

@Configurable
public class Shooter {

    private FlywheelPIDF flywheel;
    private Servo hood;
    private DcMotorEx m1;
    private DcMotorEx m2;
    public static double hood_ang_low = Math.toDegrees(HOOD_MIN);
    public static double hood_ang_high = Math.toDegrees(HOOD_MAX);
    public static double radius = 2.83;
    public static double hood_pos_low = 0.47;
    public static double hood_pos_high = 0.63;

    public Shooter(HardwareMap hardwareMap) {
        hood = hardwareMap.get(Servo.class, "hood");
        hood.setDirection(Servo.Direction.REVERSE);

        m1 = hardwareMap.get(DcMotorEx.class, "flywheel");
        m2 = hardwareMap.get(DcMotorEx.class, "flywheel2");

        m1.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
        m2.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

        m1.setDirection(DcMotorSimple.Direction.REVERSE);
        m2.setDirection(DcMotorSimple.Direction.REVERSE);

        flywheel = new FlywheelPIDF(m1, m2);
    }

    /* Flywheel */

    public void setRPM(double rpm) {
        double power = flywheel.controller(rpm, flywheel.getRPM());
        power = Math.max(0, Math.min(1, power));
        flywheel.setPower(power);
    }

    public void setPower(double power) {
        power = Math.max(0, Math.min(1, power));
        flywheel.setPower(power);
    }

    public void stop() {
        flywheel.setPower(0);
    }

    public double getRPM() {
        return flywheel.getRPM();
    }

    public boolean isAtSpeed(double targetRPM) {
        return Math.abs(targetRPM - flywheel.getRPM()) <= 50;
    }

    public void setHoodAngle(double angle) {
        hood.setPosition(map(angle, hood_ang_low, hood_ang_high, hood_pos_low, hood_pos_high));
    }
    public void setHoodPos(double pos) {
        hood.setPosition(pos);
    }

    public static double linVeltoRotVel(double vel) {
        return (vel / radius) * 2 * Math.PI;
    }

    /* =========================
       Shot Calculations
       ========================= */

    public static double[] calculateShotVectorNoVelRed(double b_x, double b_y) {

        double x_dist = GOAL_POS_RED.x + b_x;
        double y_dist = GOAL_POS_RED.y - b_y;

        double grav = 32.174 * 12;

        double x = Math.sqrt(x_dist * x_dist + y_dist * y_dist) - PASS_THROUGH_POINT_RADIUS;
        double y = SCORE_HEIGHT;
        double a = SCORE_ANGLE;

        double hood_angle = Math.atan(2 * y / x - Math.tan(a));

        double flywheel_speed = Math.sqrt(
                grav * x * x /
                        (2 * Math.pow(Math.cos(hood_angle), 2) *
                                (x * Math.tan(hood_angle) - y))
        );

        return new double[]{hood_angle, flywheel_speed};
    }

    public static double[] calculateShotVectorNoVelFarRed(double b_x, double b_y) {

        double x_dist = GOAL_POS_RED.x + b_x;
        double y_dist = GOAL_POS_RED.y - b_y;

        double grav = 32.174 * 12;

        double x = Math.sqrt(x_dist * x_dist + y_dist * y_dist) - PASS_THROUGH_POINT_RADIUS_FAR;
        double y = SCORE_HEIGHT_FAR;
        double a = SCORE_ANGLE_FAR;

        double hood_angle = Math.atan(2 * y / x - Math.tan(a));

        double flywheel_speed = Math.sqrt(
                grav * x * x /
                        (2 * Math.pow(Math.cos(hood_angle), 2) *
                                (x * Math.tan(hood_angle) - y))
        );

        return new double[]{hood_angle, flywheel_speed};
    }

    public static double[] calculateShotVectorNoVelBlue(double b_x, double b_y) {

        double x_dist = GOAL_POS_BLUE.x + b_x;
        double y_dist = GOAL_POS_BLUE.y - b_y;

        double grav = 32.174 * 12;

        double x = Math.sqrt(x_dist * x_dist + y_dist * y_dist) - PASS_THROUGH_POINT_RADIUS;
        double y = SCORE_HEIGHT;
        double a = SCORE_ANGLE;

        double hood_angle = Math.atan(2 * y / x - Math.tan(a));

        double flywheel_speed = Math.sqrt(
                grav * x * x /
                        (2 * Math.pow(Math.cos(hood_angle), 2) *
                                (x * Math.tan(hood_angle) - y))
        );

        return new double[] {hood_angle, flywheel_speed};
    }

    public static double[] calculateShotVectorNoVelFarBlue(double b_x, double b_y) {

        double x_dist = GOAL_POS_BLUE.x + b_x;
        double y_dist = GOAL_POS_BLUE.y - b_y;

        double grav = 32.174 * 12;

        double x = Math.sqrt(x_dist * x_dist + y_dist * y_dist) - PASS_THROUGH_POINT_RADIUS_FAR;
        double y = SCORE_HEIGHT_FAR;
        double a = SCORE_ANGLE_FAR;

        double hood_angle = Math.atan(2 * y / x - Math.tan(a));

        double flywheel_speed = Math.sqrt(
                grav * x * x /
                        (2 * Math.pow(Math.cos(hood_angle), 2) *
                                (x * Math.tan(hood_angle) - y))
        );

        return new double[]{hood_angle, flywheel_speed};
    }
}