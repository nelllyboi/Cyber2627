package org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.test;

import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.globals.Constants;

@Configurable
public class Lift {

    Servo leftLift;
    Servo rightLift;

    boolean engaged = false;
    public static double LIFT_ENGAGE_BASE = 0.4;
    public static double LIFT_DISENGAGE_BASE = 0.16;
    public static double LIFT_BRAKE_BASE = 0.22;
    public static double LIFT_ENGAGE_R = 0;
    public static double LIFT_ENGAGE_L = 0.03;
    public static double LIFT_DISENGAGE_R = 0;
    public static double LIFT_DISENGAGE_L = 0.03;
    public static double LIFT_BRAKE_R = 0;
    public static double LIFT_BRAKE_L = 0.05;

    public Lift() {

    }

    public void init(HardwareMap hardwareMap) {
        leftLift = hardwareMap.get(Servo.class, Constants.LEFTLIFT);
        rightLift = hardwareMap.get(Servo.class, Constants.RIGHTLIFT);

        liftDisengage();
    }

    public void liftEngage() {
        engaged = true;
        rightLift.setPosition(LIFT_ENGAGE_BASE + LIFT_ENGAGE_R);
        leftLift.setPosition(LIFT_ENGAGE_BASE + LIFT_ENGAGE_L);
    }

    public void liftDisengage() {
        engaged = false;
        rightLift.setPosition(LIFT_DISENGAGE_BASE + LIFT_DISENGAGE_R);
        leftLift.setPosition(LIFT_DISENGAGE_BASE + LIFT_DISENGAGE_L);
    }

    public void liftSetToShoot() {
        engaged = true;
        rightLift.setPosition(LIFT_BRAKE_BASE + LIFT_BRAKE_R);
        leftLift.setPosition(LIFT_BRAKE_BASE + LIFT_BRAKE_L);
    }

    public boolean isEngaged() {
        if (engaged) {
            return true;
        } else {
            return false;
        }
    }

}
