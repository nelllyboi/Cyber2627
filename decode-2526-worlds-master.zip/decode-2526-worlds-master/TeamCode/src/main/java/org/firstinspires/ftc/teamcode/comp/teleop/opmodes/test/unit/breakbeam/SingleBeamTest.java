package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.breakbeam;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DigitalChannel;

@TeleOp(name = "laserDigitalExample")
@Disabled
public class SingleBeamTest extends LinearOpMode {

    private DigitalChannel laserInput;
    private DigitalChannel laserInput1;

    // Add your intake motor
    private DcMotor intake;

    // Counter
    private int detectTicks = 0;

    // Threshold
    private static final int TICK_THRESHOLD = 10;

    @Override
    public void runOpMode() {

        laserInput = hardwareMap.get(DigitalChannel.class, "laserDigitalInput");
        laserInput1 = hardwareMap.get(DigitalChannel.class, "laserDigitalInput1");

        intake = hardwareMap.get(DcMotor.class, "intake");

        laserInput.setMode(DigitalChannel.Mode.INPUT);
        laserInput1.setMode(DigitalChannel.Mode.INPUT);

        waitForStart();

        while (opModeIsActive()) {

            boolean stateHigh0 = laserInput.getState();
            boolean stateHigh1 = laserInput1.getState();

            boolean detected = stateHigh0 && stateHigh1;

            // Count ticks if detected
            if (detected) {
                detectTicks++;
            } else {
                detectTicks = 0; // reset if broken
            }

            // Intake logic
            if (detectTicks >= TICK_THRESHOLD) {
                intake.setPower(0); // STOP intake
                telemetry.addLine("Intake STOPPED (confirmed object)");
            } else {
                intake.setPower(1.0); // RUN intake
                telemetry.addLine("Intake RUNNING");
            }

            telemetry.addData("Ticks", detectTicks);
            telemetry.addData("Sensor 0", stateHigh0);
            telemetry.addData("Sensor 1", stateHigh1);
            telemetry.update();
        }
    }
}