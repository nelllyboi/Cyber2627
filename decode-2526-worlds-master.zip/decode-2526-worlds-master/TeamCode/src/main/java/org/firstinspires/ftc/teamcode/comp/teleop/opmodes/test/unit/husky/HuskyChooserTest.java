package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.husky;

import com.qualcomm.hardware.dfrobot.HuskyLens;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.internal.system.Deadline;

import java.util.concurrent.TimeUnit;

@Disabled
@TeleOp
public class HuskyChooserTest extends LinearOpMode {
    private HuskyLens huskyLens;
    private final int READ_PERIOD = 1;

    @Override
    public void runOpMode() {

        huskyLens = hardwareMap.get(HuskyLens.class, "husky");

        Deadline rateLimit = new Deadline(READ_PERIOD, TimeUnit.SECONDS);

        rateLimit.expire();

        if (!huskyLens.knock()) {
            telemetry.addData(">>", "Problem communicating with " + huskyLens.getDeviceName());
        } else {
            telemetry.addData(">>", "Press start to continue");
        }

        huskyLens.selectAlgorithm(HuskyLens.Algorithm.COLOR_RECOGNITION);

        telemetry.update();
        waitForStart();

        while(opModeIsActive()) {
            if (!rateLimit.hasExpired()) {
                continue;
            }
            rateLimit.reset();

            HuskyLens.Block[] blocks = huskyLens.blocks();
            telemetry.addData("Block Count", blocks.length);

            int left = 0;
            int right = 0;

            for (HuskyLens.Block block : blocks) {
                if (block.y < 150) {
                    left++;
                } else if (block.y > 170) {
                    right++;
                }
                telemetry.addData("Block", block.toString());
            }

            if (left > right) {
                telemetry.addData("Direction: ", "right");
            } else {
                telemetry.addData("Direction: ", "left");
            }

            telemetry.update();

        }


    }
}
