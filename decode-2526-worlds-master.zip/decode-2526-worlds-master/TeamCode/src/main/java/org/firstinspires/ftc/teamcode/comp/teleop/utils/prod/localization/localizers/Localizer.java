package org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.localizers;
// IntelliJ API Decompiler stub source generated from a class file
// Implementation of methods is not available



import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut.AirtimeLUT;

import java.util.List;

@com.bylazar.configurables.annotations.Configurable
public class Localizer {


    public static double alpha = 0.1;
    private double count =0;
    private Limelight3A limelight;
    public GoBildaPinpointDriver pinpoint;


    public boolean localized = false;

    public double heading = 0;

    public double x =0;
    public double y=0;

    private double updatedx = 0;

    private double updatedy = 0;
    private double updatedheading = 0;
    private Pose2D goalPose;
    private Pose2D realGoalPose;
    private Pose2D realFieldPose;
    private Pose2D fieldPose;
    private double oldx =0;
    private double oldy=0;

    private Pose2D pose;
    public double distance=0;
    public double oldDistance = 0;
    public double totalDistance = 0;
    private boolean found=false;


    public Localizer(HardwareMap hardwareMap) {

        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "odo");
        pinpoint.resetPosAndIMU(); // zero both odometry and IMU
        pinpoint.setEncoderDirections(GoBildaPinpointDriver.EncoderDirection.REVERSED, GoBildaPinpointDriver.EncoderDirection.REVERSED);
        pinpoint.setOffsets(2.75, -3.75, DistanceUnit.INCH);

        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.pipelineSwitch(0);
        limelight.setPollRateHz(100);
        limelight.start();

    }

    public void setPosition(double s_x, double s_y, double s_t) {
        pinpoint.setPosition(new Pose2D(DistanceUnit.INCH, s_x, s_y, AngleUnit.DEGREES, s_t));
    }
    public boolean still(){
        return Math.abs(pinpoint.getVelX(DistanceUnit.INCH))<4&&Math.abs(pinpoint.getVelY(DistanceUnit.INCH))<4&&Math.abs(pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES))<4;
    }

    public void update(Telemetry telemetry, int targetID, boolean localizing) {

        if(localizing) {
            LLResult result = limelight.getLatestResult();
            telemetry.addData("staleness", result.getStaleness());
            List<LLResultTypes.FiducialResult> fiducials = result.getFiducialResults();
            if (result.isValid()) {
                for (LLResultTypes.FiducialResult fiducial : fiducials) {
                    int id = fiducial.getFiducialId();
                    if (id == targetID) {

                        x = (fiducial.getCameraPoseTargetSpace().getPosition().z);
                        y = (fiducial.getCameraPoseTargetSpace().getPosition().x);
                        heading = -fiducial.getCameraPoseTargetSpace().getOrientation().getPitch();
                        y += 0.1;
                        x -= 0.3;
                        x *= Math.cos(Math.PI / 9);
                        if (!localized && localizing) {
                            pinpoint.setPosition(new Pose2D(DistanceUnit.METER, -x, y, AngleUnit.DEGREES, heading));
                            updatedx=-x;
                            updatedy=y;
                            updatedheading=heading;
                            localized = true;
                            found = true;
                            count += 1;
                        } else {
                            found = true;
                            //x+=.65;
                            //heading+=turetOfset;
                            //pinpoint.getVelX(DistanceUnit.INCH) < 5 && pinpoint.getVelY(DistanceUnit.INCH) < 5 && pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES) < 2 && pinpoint.getPosX(DistanceUnit.INCH) < 70 && Math.abs(pinpoint.getPosY(DistanceUnit.INCH)) < 20
                            if (localizing) {
                                alpha = 0.025 * 10 / Math.max(1, result.getStaleness())*Math.max(Math.min(10, totalDistance/300), 1);
                                updatedx = (-x * alpha + updatedx) / (1 + alpha);
                                updatedy = (y * alpha + updatedy) / (1 + alpha);
                                updatedheading = (heading * alpha + updatedheading) / (1 + alpha);
                                totalDistance=totalDistance*9/10;
                                count += 1;
                                if (count%60==0){
                                pinpoint.setPosition(new Pose2D(DistanceUnit.METER, (-x * alpha + pinpoint.getPosX(DistanceUnit.METER)) / (1 + alpha), (y * alpha + pinpoint.getPosY(DistanceUnit.METER)) / (1 + alpha), AngleUnit.DEGREES, (heading * alpha + pinpoint.getHeading(AngleUnit.DEGREES)) / (1 + alpha)));}
                            }
                        }
                    }
                }
            } else {
                found = false;
            }
        }

        pinpoint.update();
        pose = pinpoint.getPosition();

        x = pose.getX(DistanceUnit.INCH);
        y = pose.getY(DistanceUnit.INCH);
        heading = pinpoint.getHeading(AngleUnit.DEGREES);
        realGoalPose = new Pose2D(DistanceUnit.INCH, x, y, AngleUnit.DEGREES, heading);
//        x+=pinpoint.getVelX(DistanceUnit.INCH);
        y+=pinpoint.getVelY(DistanceUnit.INCH)* AirtimeLUT.get(distance);
        distance = Math.sqrt(x * x + y * y)+pinpoint.getVelX(DistanceUnit.INCH)* AirtimeLUT.get(distance)*1.2;
        totalDistance += Math.abs(Math.sqrt((x-oldx) * (x-oldx) + (y-oldy) * (y-oldy)));

        goalPose = new Pose2D(DistanceUnit.INCH, x, y, AngleUnit.DEGREES, heading);
        double phi = Math.toRadians(52.5);

        double xprime = (goalPose.getX(DistanceUnit.INCH) - 72) * Math.cos(phi) + (goalPose.getY(DistanceUnit.INCH) - 72) * Math.sin(phi);
        double yprime = (goalPose.getX(DistanceUnit.INCH) - 72) * Math.sin(phi) + (goalPose.getY(DistanceUnit.INCH) - 72) * Math.cos(phi);
        double thetaprime = heading - 52.5;
        fieldPose = new Pose2D(DistanceUnit.INCH, xprime, yprime, AngleUnit.DEGREES, thetaprime);

        xprime = 55 + (realGoalPose.getX(DistanceUnit.INCH) - 72) * Math.cos(phi) + (realGoalPose.getY(DistanceUnit.INCH) - 72) * Math.sin(phi);
        yprime = 24 -(realGoalPose.getX(DistanceUnit.INCH) - 72) * Math.sin(phi) + (realGoalPose.getY(DistanceUnit.INCH) - 72) * Math.cos(phi);
        thetaprime = realGoalPose.getHeading(AngleUnit.DEGREES) - 52.5;
        realFieldPose = new Pose2D(DistanceUnit.INCH, xprime, yprime, AngleUnit.DEGREES, thetaprime);
        oldx=x;
        oldy=y;
        telemetry.addData("total distance", totalDistance);
//
//        if (distance<90){
//            x+=pinpoint.getVelX(DistanceUnit.INCH)*distance/90;
//            y+=pinpoint.getVelY(DistanceUnit.INCH)*distance/120;
//        }
//        else{
//            //x+=pinpoint.getVelX(DistanceUnit.INCH)*distance/90;
//            y+=pinpoint.getVelY(DistanceUnit.INCH)*distance/130;
//        }
        telemetry.addData("localizing", localizing);

        telemetry.addData("x:", x);
        telemetry.addData("y:", y);
        telemetry.addData("distance: ", distance);
        telemetry.addData("heading:", heading);
        telemetry.addData("count", count);
        telemetry.addData("xvel", pinpoint.getVelX(DistanceUnit.INCH));
        telemetry.addData("yvel", pinpoint.getVelY(DistanceUnit.INCH));
        telemetry.addData("hvel", pinpoint.getHeadingVelocity(UnnormalizedAngleUnit.DEGREES));
        telemetry.update();
    }

    public Pose2D getGoalPose() {
        return goalPose;
    }

    public Pose2D getFieldPose() { return fieldPose; }

    public Pose2D getRealFieldPose() { return realFieldPose; }

    public Pose2D getRealGoalPose() {
        return realGoalPose;
    }


}