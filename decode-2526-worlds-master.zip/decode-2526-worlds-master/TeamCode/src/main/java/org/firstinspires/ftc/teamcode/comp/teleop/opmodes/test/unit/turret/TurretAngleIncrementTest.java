/* Copyright (c) 2017 FIRST. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided that
 * the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 * of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of FIRST nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
 * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.turret;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.globals.Constants;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;


@TeleOp(name="Test: Turret2", group="Test")
@Disabled
@Config
public class TurretAngleIncrementTest extends LinearOpMode {

    // Declare OpMode members.
    public static double startAngleInDegrees = 0;
    public static double targetAngle = startAngleInDegrees;

    @Override
    public void runOpMode() {
        ElapsedTime runtime = new ElapsedTime();
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());

        TurretServo turret = new TurretServo(hardwareMap);

        telemetry.addData("Status", "Initialized");
        telemetry.update();
        // Wait for the game to start (driver presses START)
        waitForStart();
        runtime.reset();

        // run until the end of the match (driver presses STOP)
        while (opModeIsActive() && !isStopRequested()) {
            double tAngleAfter;

            telemetry.addData("Status", "Run Time: " + runtime);

            // Update targetAngle based on joy stick
            if (gamepad1.right_stick_y != 0) {
                targetAngle += -gamepad1.right_stick_y*5;
            } else if (gamepad1.rightBumperWasPressed()) {
                targetAngle += 5.0;
            } else if (gamepad1.leftBumperWasPressed()) {
                targetAngle -= 5.0;
            }



            if (gamepad1.xWasPressed()) {
                targetAngle = Constants.TURRET_MIN_ANGLE;
            } else if (gamepad1.yWasPressed()) {
                targetAngle = Constants.TURRET_INIT_ANGLE;
            } else if (gamepad1.bWasPressed()) {
                targetAngle = Constants.TURRET_MAX_ANGLE;
            }

            targetAngle = TurretServo.normalizeDegrees(targetAngle);
            tAngleAfter = turret.setTargetAngleInDegrees(targetAngle);

            // Show the elapsed game time and wheel power.
            telemetry.addData("Angle", "Before %.3f, After %.3f", targetAngle, tAngleAfter);
            telemetry.addData("Servo", "Angle = %.3f, Position = %.3f",
                    turret.getTargetAngle(), turret.getServoPosition());
            telemetry.addData("Voltage", "0: %.3f, 1: %.3f",
                    turret.getVoltage0(), turret.getVoltage1());
            telemetry.addData("Norm Pos", "0: %.3f, 1: %.3f",
                    turret.getNormalizedVoltage0(), turret.getNormalizedVoltage1());
            telemetry.addData(">","Use FTC Dashboard to set the angle");
            telemetry.addData(">","Press X to Set to Min");
            telemetry.addData(">","Press Y to Set to Mid/Init");
            telemetry.addData(">","Press B to Set to Max");
            telemetry.update();
        }
    }
}