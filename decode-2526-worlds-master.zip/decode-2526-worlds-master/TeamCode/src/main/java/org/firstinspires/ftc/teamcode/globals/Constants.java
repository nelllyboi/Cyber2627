package org.firstinspires.ftc.teamcode.globals;

//import com.acmerobotics.dashboard.config.Config;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.localization.drivers.GoBildaPinpointDriver;
import org.opencv.core.Point;

@Config
public class Constants {

    /**
     * Constants for Turret Servo
     */

    public static final double TURRET_ANGLE_MIN = -100;
    public static final double TURRET_ANGLE_MAX = 280;

    public static final String TURRET_SERVO_LEFT_FRONT = "turretLeftFront";
    public static final String TURRET_SERVO_RIGHT_REAR = "turretRightBack";
    public static final String TURRET_SERVO_RIGHT_FRONT = "turretRightFront";

    public static final String TURRET_SERVO_ANALOG0 = "axonanalog0";
    public static final String TURRET_SERVO_ANALOG1 = "axonanalog1";
    public static double TURRET_SERVO_RF_PWM_MIN = 500.00;
    public static double TURRET_SERVO_RR_PWM_MIN = 500.00;
    public static double TURRET_SERVO_RF_PWM_MAX = 2500.00;
    public static double TURRET_SERVO_RR_PWM_MAX = 2500.00;

    public static double TURRET_INIT_POS = 0.5;
    public static double TURRET_MIN_POS = 0.05;
    public static double TURRET_MAX_POS = 0.97;
    public static double TURRET_REAR_OFFSET = 0.0;

    public static double TURRET_SERVO_RIGHT_FRONT_INIT = TURRET_INIT_POS;
    public static double TURRET_SERVO_RIGHT_REAR_INIT = TURRET_INIT_POS + TURRET_REAR_OFFSET;
    public static double TURRET_SERVO_RIGHT_FRONT_MIN = TURRET_MIN_POS;
    public static double TURRET_SERVO_RIGHT_REAR_MIN = TURRET_MIN_POS + TURRET_REAR_OFFSET;
    public static double TURRET_SERVO_RIGHT_FRONT_MAX = TURRET_MAX_POS;
    public static double TURRET_SERVO_RIGHT_REAR_MAX = TURRET_MAX_POS + TURRET_REAR_OFFSET;

    public static final double TURRET_MIN_ANGLE = -185;
    public static final double TURRET_MAX_ANGLE = 207;
    public static final double TURRET_INIT_ANGLE = 0;

    /**
     * We are using tank mode. For our bot in tank mode the direction of front and rear motors
     * have to be inverse of each other for both on left and right side.
     */
    public static final DcMotorSimple.Direction LF_DIR = DcMotorSimple.Direction.FORWARD;
    public static final DcMotorSimple.Direction LR_DIR = DcMotorSimple.Direction.REVERSE;
    public static final DcMotorSimple.Direction RF_DIR = DcMotorSimple.Direction.REVERSE;
    public static final DcMotorSimple.Direction RR_DIR = DcMotorSimple.Direction.FORWARD;

    public static final String DT_LEFT_FRONT = "left1";
    public static final String DT_LEFT_REAR = "left2";
    public static final String DT_RIGHT_FRONT = "right1";
    public static final String DT_RIGHT_REAR = "right2";

    /**
     * We are using tank mode. For our bot in tank mode the direction of front and rear motors
     * have to be inverse of each other for both on left and right side.
     */
    public static final DcMotorSimple.Direction DT_LEFT_FRONT_DIRECTION = DcMotorSimple.Direction.FORWARD;
    public static final DcMotorSimple.Direction DT_LEFT_REAR_DIRECTION = DcMotorSimple.Direction.REVERSE;
    public static final DcMotorSimple.Direction DT_RIGHT_FRONT_DIRECTION = DcMotorSimple.Direction.REVERSE;
    public static final DcMotorSimple.Direction DT_RIGHT_REAR_DIRECTION = DcMotorSimple.Direction.FORWARD;

    public static final DcMotor.ZeroPowerBehavior DT_ZERO_POWER_BEHAVIOR = DcMotor.ZeroPowerBehavior.BRAKE;

    public static final DcMotor.RunMode DT_RUNMODE_ENCODER = DcMotor.RunMode.RUN_WITHOUT_ENCODER;

    /**
     * Constants for Intake
     */
    public static final String INTAKE = "intake";
    public static IntakeState intakeState = IntakeState.STOP;
    public enum IntakeState {
        FORWARD,
        STOP,
        BACKWARD;
    }

    /**
     * Constants for BallBlock
     */
    public static final String BALLBLOCK = "ballBlock";
    public enum BallblockState {
        OPEN,
        CLOSE
    }

    public static double BALLBLOCK_OPEN = 0.19;
    public static double BALLBLOCK_CLOSE = 0.38;

    /**
     * Constants for Transfer
     */
    public static final String TRANSFER = "transfer";
    public enum TransferState {
        FORWARD,
        STOP,
        BACKWARD;
    }



    /**
     * Constants for Shooter
     */
    public static final String RIGHTSHOOTERMOTOR = "flywheel";
    public static final String LEFTSHOOTERMOTOR = "flywheel2";
    public static ShooterState shooterState = ShooterState.OFF;
    public enum ShooterState {
        OFF,
        IDLE,
        SPINUP,
        READY
    }

    public enum ShootSequence {
        IDLE,
        INITIATED,
        SPIN_UP,
        SHOOTING,
        SPIN_DOWN,
        Stage4
    }

    public static ShootSequence shootSequence = ShootSequence.IDLE;

    /**
     * Constants for Lift
     */

    public static final String LEFTLIFT = "liftLeft";
    public static final String RIGHTLIFT = "liftRight";

    /**
     * Constants for Odometry
     */
    public static final String ODOMETRY_NAME = "odo";
    public static double ODOMETRY_X_OFFSET = -110;
    public static double ODOMETRY_Y_OFFSET = 110;
    public static final DistanceUnit ODOMETRY_OFFSET_UNIT = DistanceUnit.MM;
    public static final GoBildaPinpointDriver.EncoderDirection ODOMETRY_X_DIRECTION =
            GoBildaPinpointDriver.EncoderDirection.REVERSED;
    public static final GoBildaPinpointDriver.EncoderDirection ODOMETRY_Y_DIRECTION =
            GoBildaPinpointDriver.EncoderDirection.REVERSED;


    /**
     * Constants for Field
     */

    public static Point GOAL_POS_RED = new Point(72, 72);
    public static Point GOAL_POS_BLUE = new Point(72, -72);

    public static double SCORE_HEIGHT_FAR = 48;
    public static double SCORE_ANGLE_FAR = Math.toRadians(-24);
    public static double PASS_THROUGH_POINT_RADIUS_FAR = 9;

    public static double SCORE_HEIGHT = 20;
    public static double SCORE_ANGLE = Math.toRadians(-34);
    public static double PASS_THROUGH_POINT_RADIUS = 5;

    public static double HOOD_MIN = Math.toRadians(29);
    public static double HOOD_MAX = Math.toRadians(51);

    public static double PL_ENGAGE = 0.36;
    public static double PR_ENGAGE = 0.39;
    public static double PL_DISENGAGE = 0.435;
    public static double PR_DISENGAGE = 0.47;
}
