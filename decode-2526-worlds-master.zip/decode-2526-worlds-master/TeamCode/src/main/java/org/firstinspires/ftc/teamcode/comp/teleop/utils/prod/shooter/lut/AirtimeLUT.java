package org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.shooter.lut;

public final class AirtimeLUT {

    // TODO: 3/28/26 replace XS values with distance (units should match what you localize based on)
    // and Y(S) values with the velocity of the flywheel (units should match how you set your velo
    // this might be a little weird since your 0,0 isnt at the goal so it might be worth it to try changing
    //the localization first

    //also you don't need this much data, if you are under a time crunch it may be faster to do 6 data points (4 close 2 far)
    //because you need to collect n^2 amount of data for the hood angle
    private static final double[] XS = {
            60.0, 90.0, 140.0, 160.0
    };

    private static final double[] YS = {
            0.5, 0.9, 1.2, 1.35
    };

    // --- Basic linear interpolation lookup ---
    // from ishaan: yall don't need to mess with this, just MAKE SURE that XS and YS are the same size
    public static double get(double x) {
        // Clamp left
        if (x <= XS[0]) {
            return YS[0];
        }
        // Clamp right
        if (x >= XS[XS.length - 1]) {
            return YS[YS.length - 1];
        }

        // Find interval
        for (int i = 0; i < XS.length - 1; i++) {
            double x0 = XS[i];
            double x1 = XS[i + 1];

            if (x >= x0 && x <= x1) {
                double t = (x - x0) / (x1 - x0);
                return YS[i] + t * (YS[i + 1] - YS[i]);
            }
        }

        // Should never hit this
        return YS[YS.length - 1];
    }
}
