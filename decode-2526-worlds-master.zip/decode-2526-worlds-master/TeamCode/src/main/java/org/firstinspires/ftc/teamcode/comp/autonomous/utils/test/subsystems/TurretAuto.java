package org.firstinspires.ftc.teamcode.comp.autonomous.utils.test.subsystems;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.RobotLog;

import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.MathFunctions;
import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;

public class TurretAuto {
    public TurretServo turretPID;
    private double oldTarget;

    public TurretAuto(HardwareMap hardwareMap) {
        turretPID = new TurretServo(hardwareMap);
    }

    public double retLoop(double dist_x, double dist_y, double theta) {

        double angle = 0;
        double angle_non = MathFunctions.opposite_angle(Math.toDegrees(Math.atan2(72 - dist_x, 72 + dist_y)));
        if (angle_non > 0) {
            if (angle_non > 90) {
                angle = angle_non - 270;
            } else {
                angle = angle_non + 90;
            }
        } else {
            if (angle_non < -90) {
                angle = angle_non + 90;
            } else {
                angle = -angle_non - 90;
            }
        }
        double opposite = angle - theta;
        double goal = 0;
        if (opposite < 0) {
            goal = opposite + 180;
        } else {
            goal = opposite - 180;
        }

        goal = TurretServo.normalizeDegrees(goal);
        goal = -goal;
        double changed = turretPID.setTargetAngleInDegrees(goal);

        RobotLog.vv("AstroBot", "orginal = %.3f, changed = %.3f", goal, changed);
        RobotLog.vv("AstroBot", "position = %.3f", turretPID.getServoPosition());

        return (dist_x);
    }
}
