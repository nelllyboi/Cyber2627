package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.integration.partial.shooting;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.ServoImplEx;

@TeleOp(name="Intake + Ball Block + Transfer - Combined Test")
@Disabled

public class IntakeBallTransTest extends LinearOpMode {

    public DcMotorEx transfer;

    public DcMotorEx intake;
    public ServoImplEx ballBlock;
    public boolean yPressed = false;
    public boolean xPressed = false;
    public boolean aPressed = false;
    public boolean enableBallBlock = false;
    public int intakeForward = 0;
    public int transferForward = 0;
    @Override
    public void runOpMode() {

        intake = hardwareMap.get(DcMotorEx.class, "intake");
        transfer = hardwareMap.get(DcMotorEx.class, "transfer");
        ballBlock = hardwareMap.get(ServoImplEx.class, "ballBlock");

        waitForStart();

        while (opModeIsActive()) {

            if (gamepad1.y) {
                if (!yPressed) {
                    intakeForward++;
                    if (intakeForward == 3) {
                        intakeForward = 0;
                    }
                    yPressed = true;
                }
            } else {
                yPressed = false;
            }

            switch (intakeForward) {
                case 0:
                    intake.setPower(0);
                    break;
                case 1:
                    intake.setPower(1);
                    break;
                case 2:
                    intake.setPower(-1);
            }

            if (gamepad1.x) {
                if (!xPressed) {
                    transferForward++;
                    if (transferForward == 3) {
                        transferForward = 0;
                    }
                    xPressed = true;
                }
            } else {
                xPressed = false;
            }

            switch (transferForward) {
                case 0:
                    transfer.setPower(0);
                    break;
                case 1:
                    transfer.setPower(1);
                    break;
                case 2:
                    transfer.setPower(-1);
            }

            if (gamepad1.a) {
                if (!aPressed) {
                    enableBallBlock = !enableBallBlock;
                    aPressed = true;
                }
            } else {
                aPressed = false;
            }

            if (enableBallBlock) {
                ballBlock.setPosition(0.07);
            } else {
                ballBlock.setPosition(0.65);
            }

        }
    }
}
