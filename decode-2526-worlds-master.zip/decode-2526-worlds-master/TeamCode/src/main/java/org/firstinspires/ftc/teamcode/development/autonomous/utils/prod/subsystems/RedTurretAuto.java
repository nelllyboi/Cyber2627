package org.firstinspires.ftc.teamcode.development.autonomous.utils.prod.subsystems;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.bylazar.configurables.annotations.Configurable;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.RobotLog;

import org.firstinspires.ftc.teamcode.comp.teleop.utils.prod.turret.TurretServo;
import org.firstinspires.ftc.teamcode.development.teleop.utils.subsystems.prod.limelight.RedATE;

@Configurable
public class RedTurretAuto {
    public TurretServo turretPID;
    public static double llOffDegs = 0;
    public static double kP = 0.09;
    public RedATE redATE;
    public boolean enableLimelight = false;
    public double start_x;
    public double start_y;
    private double errorInDegs;
    private double xOff = 72;
    private double yOff = 72;
    public RedTurretAuto(HardwareMap hardwareMap, double start_x, double start_y) {
        turretPID = new TurretServo(hardwareMap);
        redATE = new RedATE(hardwareMap, 1);

        this.start_x = start_x;
        this.start_y = start_y;
    }

    public double retLoop(double x, double y, double theta) {
        Object[] rets = redATE.retLoop();
        if (enableLimelight) {
            if ((boolean) rets[0]) {
                errorInDegs = (double) rets[1] + llOffDegs;
            }
            double angle = turretPID.getTargetAngle() - errorInDegs * kP;
            angle = TurretServo.normalizeDegrees(angle);
            turretPID.setTargetAngleInDegrees(angle);
        } else {
            double dist_x = xOff + x;
            double dist_y = yOff - y;

            double angle = 0;
            double angle_non = Math.toDegrees(Math.atan2(dist_x, dist_y));
            if (angle_non > 0) {
                if (angle_non > 90) {
                    angle = angle_non - 270;
                } else {
                    angle = angle_non + 90;
                }
            } else {
                if (angle_non < -90) {
                    angle = angle_non + 90;
                } else {
                    angle = -angle_non - 90;
                }
            }
            double opposite = angle - theta;
            double goal = 0;
            if (opposite < 0) {
                goal = opposite + 180;
            } else {
                goal = opposite - 180;
            }

            goal = TurretServo.normalizeDegrees(goal);
            goal = -goal;
            double changed = turretPID.setTargetAngleInDegrees(goal);

            RobotLog.vv("AstroBot", "original = %.3f, changed = %.3f", goal, changed);
            RobotLog.vv("AstroBot", "position = %.3f", turretPID.getServoPosition());

            return (changed);
        }
        return (67);
    }

    public class EnableLimelight implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            enableLimelight = true;
            return false;
        }
    }

    public class DisableLimelight implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet) {
            enableLimelight = false;
            return false;
        }
    }

    public void setYOff(double off) {
        yOff = off;
    }
    public void setXOff(double off) {
        xOff = off;
    }
    public void setLlOffDegs(double off) { llOffDegs = off; }

    public Action enableLimelight() { return new EnableLimelight(); }
    public Action disableLimelight() { return new DisableLimelight(); }
}
