package org.firstinspires.ftc.teamcode.comp.teleop.opmodes.test.unit.breakbeam;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DigitalChannel;

@TeleOp
@Disabled
public class DualBeamTest extends LinearOpMode {
    private DigitalChannel laserInput;
    private DigitalChannel laserInput1; // second sensor

    @Override
    public void runOpMode() {
        // Get both sensors from hardware map
        laserInput = hardwareMap.get(DigitalChannel.class, "laserDigitalInput");
        laserInput1 = hardwareMap.get(DigitalChannel.class, "laserDigitalInput1");

        // Set both as inputs
        laserInput.setMode(DigitalChannel.Mode.INPUT);
        laserInput1.setMode(DigitalChannel.Mode.INPUT);

        waitForStart();

        while (opModeIsActive()) {
            // Read both sensor states
            boolean stateHigh0 = laserInput.getState();
            boolean stateHigh1 = laserInput1.getState();

            // Only detect if BOTH are HIGH
            boolean detected = stateHigh0 && stateHigh1;

            if (detected) {
                telemetry.addLine("Both sensors detect object!");
            } else {
                telemetry.addLine("One or both sensors do NOT detect object");
            }

            // Debug info
            telemetry.addData("Sensor 0", stateHigh0);
            telemetry.addData("Sensor 1", stateHigh1);
            telemetry.update();
        }
    }
}
