package org.firstinspires.ftc.teamcode.globals;

public class Globals {
    public static double START_X = 0;
    public static double START_Y = 0;
    public static double START_THETA = 180;
}
